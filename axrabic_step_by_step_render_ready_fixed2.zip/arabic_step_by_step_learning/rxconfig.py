import reflex as rx

config = rx.Config(
    app_name="arabic_step_by_step_learning",
    db_url="sqlite:///reflex.db",
    backend_host="0.0.0.0",
    plugins=[
        rx.plugins.SitemapPlugin(),
        rx.plugins.TailwindV4Plugin(),
    ],
)
