import reflex as rx
import sys
from scripts.generate_arabic_audio import generate_audio

if any(command in sys.argv for command in ("run", "export")):
    generate_audio()

config = rx.Config(
    app_name="arabic_step_by_step_learning",
    api_url="localhost",
    db_url="sqlite:///reflex.db",
    plugins=[
        rx.plugins.SitemapPlugin(),
        rx.plugins.TailwindV4Plugin(),
    ],
)
