import reflex as rx
import asyncio
import inspect
import json
import logging
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from arabic_step_by_step_learning.states.audio_catalog import audio_filename, source_catalog
from arabic_step_by_step_learning.states.education_data import LESSONS
from arabic_step_by_step_learning.states.education_state import EducationState
from arabic_step_by_step_learning.education_checks import check_content
from scripts.generate_arabic_audio import generate_audio
from arabic_step_by_step_learning.states.letter_data import LETTERS
from arabic_step_by_step_learning.states.phrases_data import (
    SENTENCES,
    DIALOGUES,
    eligible_sentences,
    sentence_words,
)


def check_catalog():
    catalog = source_catalog()
    assert audio_filename("hello") == "4f9f2cab.mp3"
    assert audio_filename("أ") == audio_filename("ا\u0654")
    assert len({audio_filename(x) for x in catalog}) == len(catalog)
    for letter in LETTERS:
        assert all(
            x in catalog
            for x in (letter["name"], letter["word"], f"{letter['glyph']}َ")
        )
    for lessons in LESSONS.values():
        for item in lessons:
            assert item["arabic"] in catalog
    assert all(scene[0] in catalog for scene in DIALOGUES)
    assert catalog["بْ"] == "أَبْ" and catalog["مْ"] == "أَمْ"
    assert not eligible_sentences([])
    for sentence in SENTENCES:
        completed = [f"phrases:{i}" for i in sentence["lessons"]]
        assert sentence in eligible_sentences(completed)
        assert sentence not in eligible_sentences(completed[:-1])
        vocabulary = set()
        for item in LESSONS["phrases"]:
            if f"phrases:{item['id']}" in completed:
                vocabulary.update(sentence_words(item["arabic"]))
        assert set(sentence_words(sentence["arabic"])) <= vocabulary
        assert sentence["arabic"] in catalog
    return catalog


class TileHarness(SimpleNamespace):
    @property
    def tile_mode(self):
        return True

    async def get_state(self, state):
        return self.progress

    def _new_round(self, **kwargs):
        self.refreshed = True


async def check_tile_events():
    sentence = SENTENCES[0]
    words = sentence_words(sentence["arabic"])
    progress = SimpleNamespace(
        _available=lambda module: True,
        progress_data={"lessons": ["phrases:phrase-0"]},
    )
    state = TileHarness(
        module="phrases",
        category="family",
        mode="sentence_build",
        target_item=sentence["id"],
        tiles=[{"id": i, "text_en": word} for i, word in enumerate(words)],
        used_tiles=[],
        expected_tiles=words,
        answered=False,
        feedback="",
        score=0,
        attempts=0,
        progress=progress,
        refreshed=False,
    )

    async def check():
        results = []
        async for event in EducationState.check_answer.fn(state):
            results.append(event)
        return results

    assert not await check() and state.feedback == "tiles_incomplete"
    assert not state.answered and state.score == state.attempts == 0
    EducationState.add_tile.fn(state, 0)
    EducationState.add_tile.fn(state, 0)
    assert state.used_tiles == [0]
    EducationState.undo_tile.fn(state)
    assert not state.used_tiles
    state.used_tiles = list(reversed(range(len(words))))
    assert (
        not await check() and state.score == 0 and state.feedback == "try_again"
    )
    state.answered = False
    EducationState.clear_tiles.fn(state)
    state.used_tiles = list(range(len(words)))
    assert await check() and state.score == 1 and state.feedback == "well_done"
    assert not await check() and state.score == 1
    state.answered = False
    progress.progress_data["lessons"] = []
    assert await check() and not state.refreshed and state.score == 2
    state.answered = False
    state.target_item = "unknown-sentence"
    assert not await check() and state.refreshed and state.score == 2
    state.used_tiles = []
    state.tiles = [{"id": 0, "text_en": "نَعَمْ"}, {"id": 1, "text_en": "نَعَمْ"}]
    EducationState.add_tile.fn(state, 0)
    EducationState.add_tile.fn(state, 1)
    assert state.used_tiles == [0, 1]


def check_assets(catalog: dict[str, str]):
    for text in catalog:
        path = ROOT / "assets" / "arabic_audio" / audio_filename(text)
        assert path.is_file() and path.stat().st_size > 0, (
            f"Missing clip: {text}"
        )
        result = subprocess.run(
            [
                "ffprobe",
                "-v",
                "error",
                "-select_streams",
                "a:0",
                "-show_entries",
                "stream=codec_name,channels,bit_rate,duration",
                "-of",
                "json",
                str(path),
            ],
            check=True,
            capture_output=True,
            text=True,
        )
        stream = json.loads(result.stdout)["streams"][0]
        assert stream["codec_name"] == "mp3" and stream["channels"] == 1
        assert (
            int(stream["bit_rate"]) == 64000 and float(stream["duration"]) > 0
        )


if __name__ == "__main__":
    try:
        generate_audio()
        check_content()
        catalog = check_catalog()
        asyncio.run(check_tile_events())
        check_assets(catalog)
        print(
            f"Catalog, tile-event and asset checks passed for {len(catalog)} clips. No device playback testing performed."
        )
    except Exception as e:
        logging.exception(f"Error: {e}")
        raise
