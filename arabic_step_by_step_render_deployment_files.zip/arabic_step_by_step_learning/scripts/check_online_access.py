import reflex as rx
import asyncio
import json
import logging
from pathlib import Path
import sys
from collections.abc import Awaitable, Callable
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from arabic_step_by_step_learning.states.learning_state import LearningState
from arabic_step_by_step_learning.states.education_state import EducationState
from arabic_step_by_step_learning.states.letters_state import LettersState
from arabic_step_by_step_learning.states.education_data import GAME_MODES
from arabic_step_by_step_learning.states.phrases_data import SENTENCES, sentence_words
from arabic_step_by_step_learning.states.translations import MODULES


def snapshot(state: LearningState) -> tuple[str, int, str, str, str]:
    return (
        state.progress_json,
        state.stars,
        json.dumps(state.badges, sort_keys=True),
        state.placement_json,
        state.review_json,
    )


async def check_navigation():
    for language in ("en", "fr"):
        for saved in (
            "{}",
            json.dumps(
                {
                    "lessons": ["letters:0", "writing:1", "numbers:number-0"],
                    "exercises": ["trace:1:isolated"],
                    "answers": ["saved-answer"],
                    "modules": [],
                    "words": [],
                    "daily": ["2026-06-01:0"],
                    "days": [],
                }
            ),
        ):
            root = rx.State(_reflex_internal_init=True)
            state = await root.get_state(LearningState)
            education = await root.get_state(EducationState)
            letters = await root.get_state(LettersState)
            state.language = language
            state.progress_json = saved
            before = snapshot(state)
            assert all(module["available"] for module in state.modules)
            if saved == "{}":
                assert (
                    state.completed_total
                    == state.stars
                    == state.overall_percent
                    == 0
                )
                assert not any(badge["earned"] for badge in state.badges)
                assert not state.progress_data["modules"]
            for row in MODULES:
                module = row[0]
                await LearningState.open_module.fn(state, module)
                assert state.chosen_module == module and state.modal == ""
                assert state.active_tab == (
                    "games" if module == "games" else "learn"
                )
                assert snapshot(state) == before
                if module in GAME_MODES:
                    assert state.education_open and education.module == module
                    await EducationState.set_view.fn(education, "practice")
                    for mode in GAME_MODES[module]:
                        await EducationState.start_mode.fn(education, mode)
                        assert (
                            education.mode == mode
                            and education.view == "practice"
                        )
                        assert education.tiles or education.choices
                        assert not education.answered
                        assert snapshot(state) == before
            for module in state.game_modules:
                await LearningState.choose_game_module.fn(state, module["id"])
                assert (
                    state.game_module == module["id"]
                    and state.active_tab == "games"
                )
                assert state.modal == "" and snapshot(state) == before
            for index in range(28):
                LettersState.select_letter.fn(letters, index)
                for mode in letters.trace_options:
                    LettersState.choose_trace.fn(letters, mode)
                    assert letters.trace_mode == mode and letters.trace_text
                    assert snapshot(state) == before
            for mode in ("find", "listen_game", "match", "memory", "odd"):
                await LettersState.start_game.fn(letters, mode)
                assert letters.game == mode and letters.choices
                assert snapshot(state) == before
            for tab in ("home", "learn", "games", "progress", "settings"):
                LearningState.navigate.fn(state, tab)
                assert state.active_tab == tab and state.modal == ""
                assert snapshot(state) == before
            navigation = (
                state.active_tab,
                state.chosen_module,
                state.game_module,
                state.modal,
            )
            for invalid in ("", "unknown", "words", "dialogues", "LETTERS"):
                assert not state._available(invalid)
                await LearningState.open_module.fn(state, invalid)
                await LearningState.choose_game_module.fn(state, invalid)
                state._record(invalid, "0", lesson=True, exercise="invalid")
                assert navigation == (
                    state.active_tab,
                    state.chosen_module,
                    state.game_module,
                    state.modal,
                )
                assert snapshot(state) == before
            assert state.copy["not_earned"] == (
                "Pas encore obtenu" if language == "fr" else "Not earned yet"
            )


EventRunner = Callable[..., Awaitable[object]]


async def check_sentences(event_runner: EventRunner | None = None) -> bool:
    for sentence in SENTENCES:
        root = rx.State(_reflex_internal_init=True)
        state = await root.get_state(LearningState)
        education = await root.get_state(EducationState)
        state.progress_json = "{}"
        assert state.stars == 0 and not state.progress_data["lessons"]
        education._configure("phrases", practice=True)
        with patch(
            "app.states.education_state.random.choice", return_value=sentence
        ):
            await EducationState.start_mode.fn(education, "sentence_build")
        assert education.target_item == sentence["id"]
        assert education.expected_tiles == sentence_words(sentence["arabic"])
        assert (
            education.prompt_en == sentence["en"]
            and education.prompt_fr == sentence["fr"]
        )
        assert state.progress_json == "{}"
        await EducationState.activity_completed.fn(
            education,
            "phrases",
            education.category,
            "sentence_build",
            sentence["id"],
        )
        assert state.progress_json == "{}" and state.stars == 0
        assert education.tiles and not education.answered
        if event_runner is None:
            continue
        await event_runner(education.check_answer)
        assert (
            education.feedback == "tiles_incomplete"
            and not education.answered
            and education.attempts == 0
            and education.score == 0
            and state.progress_json == "{}"
        )
        remaining = list(range(len(education.tiles)))
        for word in education.expected_tiles:
            index = next(
                i for i in remaining if education.tiles[i]["text_en"] == word
            )
            EducationState.add_tile.fn(education, index)
            remaining.remove(index)
        await event_runner(education.check_answer)
        assert (
            education.feedback == "well_done"
            and education.answered
            and education.attempts == 1
            and education.score == 1
            and not education.sentence_claimed
            and state.progress_json == "{}"
        )
        await EducationState.activity_completed.fn(
            education,
            "phrases",
            education.category,
            "sentence_build",
            "unknown",
        )
        assert state.progress_json == "{}"
        await EducationState.activity_completed.fn(
            education,
            "phrases",
            education.category,
            "sentence_build",
            sentence["id"],
        )
        assert state.stars == 6
        assert state.progress_data["lessons"] == ["games:sentence_build"]
        assert not state.progress_data["modules"]
        saved = snapshot(state)
        await EducationState.activity_completed.fn(
            education,
            "phrases",
            education.category,
            "sentence_build",
            sentence["id"],
        )
        await event_runner(education.check_answer)
        assert (
            education.answered
            and education.feedback == "well_done"
            and education.attempts == 1
            and education.score == 1
            and education.sentence_claimed
        )
        assert snapshot(state) == saved
        await EducationState.next_round.fn(education)
        assert (
            education.tiles
            and not education.used_tiles
            and not education.answered
            and education.feedback == ""
            and snapshot(state) == saved
        )
        education.target_item = "unknown"
        await event_runner(education.check_answer)
        assert (
            education.target_item in {item["id"] for item in SENTENCES}
            and education.tiles
            and not education.used_tiles
            and not education.answered
            and education.feedback == ""
            and education.attempts == 1
            and education.score == 1
        )
        assert snapshot(state) == saved
    return event_runner is not None


async def main(event_runner: EventRunner | None = None) -> bool:
    await check_navigation()
    full_events = await check_sentences(event_runner)
    if full_events:
        print(
            "Online zero-progress access, non-awarding navigation, saved-data preservation, sentence validation and duplicate-reward checks passed with the provided event runner. No browser or physical-device verification performed."
        )
    else:
        print(
            f"Standalone checks passed: zero-progress access, non-awarding navigation, saved-data preservation, and all {len(SENTENCES)} open sentence round setups with non-awarding pre-answer completion. Answer validation and reward/duplicate-reward event assertions were skipped because no event runner was provided; call main(run_event) for those. No browser or physical-device verification performed."
        )
    return full_events


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except Exception as e:
        logging.exception(f"Error: {e}")
        raise
