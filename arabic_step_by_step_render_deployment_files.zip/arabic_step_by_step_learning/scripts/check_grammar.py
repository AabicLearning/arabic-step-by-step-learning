import reflex as rx
import json
import logging
import shutil
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from arabic_step_by_step_learning.education_checks import check_content
from arabic_step_by_step_learning.states.education_data import LESSONS, GAME_MODES
from arabic_step_by_step_learning.states.grammar_data import GRAMMAR_GROUPS, GRAMMAR_QUESTIONS
from arabic_step_by_step_learning.states.learning_state import LearningState
from arabic_step_by_step_learning.states.progress_data import lesson_ids
from arabic_step_by_step_learning.states.translations import COPY, MODULES
from scripts.generate_arabic_audio import generate_audio
from scripts.check_arabic_practice import check_assets, check_catalog
from scripts.check_offline_learning import (
    check_offline_grammar,
    check_player_interactions,
)
from arabic_step_by_step_learning.pwa_assets import generate_pwa_assets


class ProgressHarness:
    progress_json: str = "{}"

    @property
    def progress_data(self) -> dict[str, list[str]]:
        data = json.loads(self.progress_json)
        return {
            key: data.get(key, [])
            for key in (
                "lessons",
                "exercises",
                "answers",
                "modules",
                "words",
                "daily",
                "days",
            )
        }

    def _count(self, module: str) -> int:
        return LearningState._count(self, module)

    def _available(self, module: str) -> bool:
        return LearningState._available(self, module)

    def _save_progress(self, data: dict[str, list[str]]):
        return LearningState._save_progress(self, data)


def check_progress():
    state = ProgressHarness()
    grammar_ids = lesson_ids("grammar")
    assert len(grammar_ids) == len(set(grammar_ids)) == 13
    assert state._available("grammar") and state._count("letters") == 0
    assert state.progress_json == "{}" and state._count("grammar") == 0
    assert not state._available("unknown")
    LearningState._record(state, "unknown", grammar_ids[0], lesson=True)
    assert state.progress_json == "{}"
    for index, item in enumerate(grammar_ids):
        LearningState._record(state, "grammar", item, lesson=True)
        assert state._count("grammar") == index + 1
        assert state.progress_data["modules"].count("grammar") == (
            1 if index == len(grammar_ids) - 1 else 0
        )
        saved = state.progress_json
        LearningState._record(state, "grammar", item, lesson=True)
        assert state.progress_json == saved
    data = state.progress_data
    completed = [key for key in data["lessons"] if key.startswith("grammar:")]
    assert len(completed) == len(set(completed)) == 13
    assert set(completed) == {f"grammar:{item}" for item in grammar_ids}
    assert data["modules"] == ["grammar"]
    assert not data["answers"] and not data["exercises"]
    assert 5 * len(data["lessons"]) + 20 * len(data["modules"]) == 65 + 20
    restored = ProgressHarness()
    restored.progress_json = json.dumps(json.loads(state.progress_json))
    assert restored.progress_data == data == json.loads(state.progress_json)
    assert restored._count("grammar") == 13 and restored._available("grammar")
    assert restored.progress_data["modules"].count("grammar") == 1
    grammar_module = next(row for row in MODULES if row[0] == "grammar")
    assert grammar_module[1:3] == ("module_grammar", "desc_grammar")
    assert COPY[grammar_module[1]] == (
        "Beginner Grammar",
        "Grammaire débutante",
    )
    assert COPY[grammar_module[2]] == (
        "Pronouns, gender agreement and your first Arabic sentences.",
        "Pronoms, accords et premières phrases en arabe.",
    )
    for index in range(2):
        assert COPY[grammar_module[1]][index].strip()
        assert COPY[grammar_module[2]][index].strip()


def check_practice():
    lessons = {item["id"]: item for item in LESSONS["grammar"]}
    assert {item["group"] for item in lessons.values()} == set(GRAMMAR_GROUPS)
    assert GAME_MODES["grammar"] == list(GRAMMAR_QUESTIONS)
    assert set(GRAMMAR_QUESTIONS) == {
        "pronoun_identify",
        "gender_agreement",
        "grammar_order",
    }
    question_ids = set()
    order_lessons = set()
    for mode, questions in GRAMMAR_QUESTIONS.items():
        assert questions
        for question in questions:
            assert question["id"] and question["id"] not in question_ids
            question_ids.add(question["id"])
            assert question["lesson"] in lessons
            lesson = lessons[question["lesson"]]
            assert all(
                question[key].strip()
                for key in (
                    "prompt_en",
                    "prompt_fr",
                    "arabic",
                    "roman",
                    "en",
                    "fr",
                    "correct",
                )
            )
            if mode == "grammar_order":
                assert lesson["group"] == "sentences"
                assert question["lesson"] not in order_lessons
                order_lessons.add(question["lesson"])
                assert not question["options"]
                assert (
                    question["correct"]
                    == question["arabic"]
                    == lesson["arabic"]
                )
                target_tiles = question["correct"].split()
                assert len(target_tiles) in (2, 3)
                assert target_tiles == lesson["arabic"].split()
                assert " ".join(target_tiles) == question["correct"]
                assert " ".join(reversed(target_tiles)) != question["correct"]
            else:
                choices = question["options"]
                assert len(choices) == len(set(choices)) >= 2
                assert all(choice.strip() for choice in choices)
                assert choices.count(question["correct"]) == 1
                assert question["correct"] in question["arabic"].split()
                if mode == "pronoun_identify":
                    assert lesson["group"] == "pronouns"
                    assert question["correct"] == question["arabic"]
                else:
                    assert question["arabic"] == lesson["arabic"]
    assert order_lessons == {
        item["id"] for item in lessons.values() if item["group"] == "sentences"
    }


if __name__ == "__main__":
    try:
        generate_audio()
        check_content()
        check_progress()
        check_practice()
        check_assets(check_catalog())
        from arabic_step_by_step_learning.offline_assets import offline_contents

        data = json.loads(
            offline_contents(ROOT / "assets")["offline-data.json"]
        )
        check_offline_grammar(data)
        generate_pwa_assets()
        node = shutil.which("node")
        if not node:
            raise RuntimeError("Node is required for offline grammar checks.")
        check_player_interactions(node)
        print(
            "Grammar content, real-method zero-progress access/progress saving, unique lesson and module reward records, bilingual source text, practice data/target tiles, catalog/MP3 integrity and offline Grammar coverage checked. Node simulated-DOM lesson, answer, tile and storage checks are included; no real browser or physical-device audio verification."
        )
    except Exception as e:
        logging.exception(f"Error: {e}")
        raise
