import reflex as rx
import argparse
import json
import logging
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from arabic_step_by_step_learning.states.audio_catalog import audio_filename, source_catalog


def generate_audio(force: bool = False):
    """Build static assets before Reflex copies assets; never called by a learner event."""
    output = ROOT / "assets" / "arabic_audio"
    catalog = source_catalog()
    expected = {
        audio_filename(text): source for text, source in catalog.items()
    }
    metadata = output / "catalog.txt"
    try:
        previous = (
            json.loads(metadata.read_text(encoding="utf-8"))
            if metadata.exists()
            else {}
        )
        pending = [
            name
            for name, source in expected.items()
            if force
            or previous.get(name) != source
            or not (output / name).is_file()
            or (output / name).stat().st_size == 0
        ]
        if not pending:
            return
        espeak = shutil.which("espeak-ng")
        ffmpeg = shutil.which("ffmpeg")
        if not espeak or not ffmpeg:
            raise RuntimeError(
                "Install espeak-ng and ffmpeg before building Arabic audio."
            )
        output.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix="arabic-audio-") as directory:
            work = Path(directory)
            for name in pending:
                wav = work / "speech.wav"
                mp3 = work / name
                subprocess.run(
                    [
                        espeak,
                        "-v",
                        "ar",
                        "-s",
                        "135",
                        "-w",
                        str(wav),
                        "--stdin",
                    ],
                    input=expected[name],
                    text=True,
                    check=True,
                    capture_output=True,
                )
                subprocess.run(
                    [
                        ffmpeg,
                        "-nostdin",
                        "-hide_banner",
                        "-loglevel",
                        "error",
                        "-y",
                        "-i",
                        str(wav),
                        "-map_metadata",
                        "-1",
                        "-ac",
                        "1",
                        "-ar",
                        "22050",
                        "-codec:a",
                        "libmp3lame",
                        "-b:a",
                        "64k",
                        "-threads",
                        "1",
                        "-fflags",
                        "+bitexact",
                        str(mp3),
                    ],
                    check=True,
                    capture_output=True,
                )
                if not mp3.is_file() or mp3.stat().st_size == 0:
                    raise RuntimeError(f"Empty generated clip: {name}")
                shutil.copyfile(mp3, output / name)
        metadata.write_text(
            json.dumps(expected, ensure_ascii=False, indent=2, sort_keys=True),
            encoding="utf-8",
        )
        (output / "source_texts.txt").write_text(
            json.dumps(catalog, ensure_ascii=False, indent=2, sort_keys=True),
            encoding="utf-8",
        )
    except Exception as e:
        logging.exception(f"Error: {e}")
        raise


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Build bundled Arabic MP3s with eSpeak NG and ffmpeg."
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Regenerate all clips with the installed tool versions.",
    )
    generate_audio(parser.parse_args().force)
