import reflex as rx

import json
import logging
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from PIL import Image, ImageDraw
from arabic_step_by_step_learning.brand_assets import generate_brand_icons
from arabic_step_by_step_learning.offline_assets import offline_contents
from arabic_step_by_step_learning.offline_player import OFFLINE_SCRIPT
from arabic_step_by_step_learning.pwa_assets import generate_pwa_assets, PWA_SCRIPT
from arabic_step_by_step_learning.states.audio_catalog import audio_filename, source_catalog
from arabic_step_by_step_learning.states.education_data import LESSONS, GAME_MODES
from arabic_step_by_step_learning.states.letter_data import LETTERS
from arabic_step_by_step_learning.states.grammar_data import GRAMMAR_GROUPS, GRAMMAR_QUESTIONS
from arabic_step_by_step_learning.states.progress_data import lesson_ids
from arabic_step_by_step_learning.states.phrases_data import DIALOGUES, SENTENCES
from arabic_step_by_step_learning.states.vocabulary_data import CATEGORIES
from scripts.generate_arabic_audio import generate_audio


def check_offline_grammar(data: dict) -> None:
    assert data["lessons"]["grammar"] == LESSONS["grammar"]
    assert data["grammar_groups"] == GRAMMAR_GROUPS
    assert data["grammar_questions"] == GRAMMAR_QUESTIONS
    assert data["modes"]["grammar"] == GAME_MODES["grammar"]
    assert data["ids"]["grammar"] == lesson_ids("grammar")
    assert set(GAME_MODES["grammar"]) <= set(data["ids"]["games"])
    module = next(item for item in data["modules"] if item["id"] == "grammar")
    assert module["requirement"] == ["", ""]
    texts = [item["arabic"] for item in data["lessons"]["grammar"]]
    for questions in data["grammar_questions"].values():
        texts.extend(item["arabic"] for item in questions)
    catalog = source_catalog()
    for text in texts:
        assert text in catalog
        path = f"/arabic_audio/{audio_filename(text)}"
        assert path in data["audio"]
        assert (ROOT / "assets" / path.lstrip("/")).stat().st_size > 0
    assert data["grammar_questions"]["pronoun_identify"][1]["correct"] == "أنا"
    assert (
        data["grammar_questions"]["gender_agreement"][3]["correct"] == "صغيرةٌ"
    )
    assert data["grammar_questions"]["grammar_order"][-1][
        "correct"
    ].split() == ["هو", "يقرأُ", "كتابًا"]


def check_brand_icons(assets: Path) -> None:
    source_path = assets / "arabic-step-user-logo.jpg"
    assert source_path.is_file()
    with Image.open(source_path) as source:
        source.load()
        image = source.convert("RGB")
        side = min(image.size)
        left, top = (image.width - side) // 2, (image.height - side) // 2
        artwork = (
            image.crop((left, top, left + side, top + side))
            .resize((1024, 1024), Image.Resampling.LANCZOS)
            .convert("RGBA")
        )
    mask = Image.new("L", (1024, 1024), 0)
    ImageDraw.Draw(mask).ellipse((1, 1, 1022, 1022), fill=255)
    artwork.putalpha(mask)
    for name, size in (
        ("app-icon-192.png", 192),
        ("app-icon-512.png", 512),
        ("apple-touch-icon.png", 180),
    ):
        with Image.open(assets / name) as icon:
            icon.load()
            assert icon.format == "PNG" and icon.mode == "RGBA"
            assert icon.size == (size, size)
            expected = artwork.resize((size, size), Image.Resampling.LANCZOS)
            assert icon.tobytes() == expected.tobytes(), (
                f"Wrong source/crop: {name}"
            )
            assert icon.getpixel((0, 0))[3] == 0
            assert icon.getpixel((size // 2, size // 2))[3] == 255
    with Image.open(assets / "favicon.ico") as favicon:
        assert favicon.format == "ICO"
        assert favicon.ico.sizes() == {
            (size, size) for size in (16, 32, 48, 64, 128, 256)
        }
        for size in (16, 32, 48, 64, 128, 256):
            icon = favicon.ico.getimage((size, size)).convert("RGBA")
            assert (
                icon.tobytes()
                == artwork.resize(
                    (size, size), Image.Resampling.LANCZOS
                ).tobytes()
            )
            assert icon.getpixel((0, 0))[3] == 0
    for name in ("home", "onboarding"):
        code = (ROOT / "app" / "components" / f"{name}.py").read_text()
        assert 'src=rx.asset("arabic-step-user-logo.jpg")' in code
        assert 'class_name="size-10 rounded-full object-cover"' in code
    print(
        "Brand integrity checked: exact uploaded source, circular transparent PNGs and all favicon sizes."
    )


def check_player_interactions(node: str) -> None:
    subprocess.run(
        [node, "--check", str(ROOT / "assets" / "offline-player.js")],
        check=True,
        capture_output=True,
        text=True,
    )
    result = subprocess.run(
        [node, str(ROOT / "scripts" / "check_offline_player.txt")],
        check=True,
        capture_output=True,
        text=True,
        timeout=30,
    )
    print(result.stdout.strip())
    worker = subprocess.run(
        [node, str(ROOT / "scripts" / "check_offline_worker.txt")],
        check=True,
        capture_output=True,
        text=True,
        timeout=130,
    )
    print(worker.stdout.strip())


def check_offline_learning() -> None:
    assets = ROOT / "assets"
    generate_audio()
    generate_brand_icons()
    check_brand_icons(assets)
    generate_pwa_assets()
    contents = offline_contents(assets)
    data = json.loads(contents["offline-data.json"])
    assert data["letters"] == LETTERS and len(data["letters"]) == 28
    assert all(module["requirement"] == ["", ""] for module in data["modules"])
    assert not any(key.startswith("req_") for key in data["copy"])
    assert "locked" not in data["copy"] and "unlock_after" not in data["copy"]
    assert "/arabic-step-user-logo.jpg" in contents["offline.html"]
    assert "/arabic-step-user-logo.jpg" in contents["sw.js"]
    assert "arabic-step-uploaded-logo.jpg" not in contents["sw.js"]
    assert data["lessons"] == LESSONS
    check_offline_grammar(data)
    assert data["categories"] == {
        key: list(value) for key, value in CATEGORIES.items()
    }
    assert data["dialogues"] == [list(value) for value in DIALOGUES]
    assert data["sentences"] == SENTENCES
    assert data["modes"] == GAME_MODES
    assert set(GAME_MODES["grammar"]) <= set(data["ids"]["games"])
    assert set(data["audio"]) == {
        f"/arabic_audio/{path.name}"
        for path in (assets / "arabic_audio").glob("*.mp3")
    }
    assert {
        f"/arabic_audio/{audio_filename(text)}" for text in source_catalog()
    } <= set(data["audio"])
    for letter in data["letters"]:
        assert bool(letter["initial"]) == letter["joins"]
        assert bool(letter["medial"]) == letter["joins"]
        assert letter["final"] and letter["isolated"]
    for filename, content in contents.items():
        assert (assets / filename).read_text(encoding="utf-8") == content
    first = {
        path.name: path.stat().st_mtime_ns
        for path in assets.iterdir()
        if path.name in contents
    }
    generate_pwa_assets()
    assert first == {
        path.name: path.stat().st_mtime_ns
        for path in assets.iterdir()
        if path.name in contents
    }
    for forbidden in (
        "https://",
        "_event",
        "WebSocket",
        "google",
        "call_script",
    ):
        assert forbidden not in OFFLINE_SCRIPT
    assert "arabic_steps_progress" in OFFLINE_SCRIPT
    assert (
        "rangeResponse" in contents["sw.js"]
        and "Promise.allSettled" in contents["sw.js"]
    )
    node = shutil.which("node")
    if not node:
        raise RuntimeError(
            "Node is required for offline JavaScript syntax and hashing checks."
        )
    with tempfile.TemporaryDirectory(prefix="offline-check-") as directory:
        for name, script in {
            "player.js": OFFLINE_SCRIPT,
            "worker.js": contents["sw.js"],
            "pwa.js": PWA_SCRIPT,
        }.items():
            path = Path(directory) / name
            path.write_text(script, encoding="utf-8")
            subprocess.run(
                [node, "--check", str(path)],
                check=True,
                capture_output=True,
                text=True,
            )
        start = OFFLINE_SCRIPT.index("function filename(text)")
        end = OFFLINE_SCRIPT.index("function stopAudio", start)
        cases = {
            text: audio_filename(text)
            for text in [*source_catalog(), "😀بَ", "ا\u0654"]
        }
        script = f"{OFFLINE_SCRIPT[start:end]}\nconst cases={json.dumps(cases, ensure_ascii=False)}; for(const [text,expected] of Object.entries(cases)) {{ if(filename(text)!==expected) throw Error('Hash mismatch'); }}"
        path = Path(directory) / "hash.js"
        path.write_text(script, encoding="utf-8")
        subprocess.run(
            [node, str(path)], check=True, capture_output=True, text=True
        )
    print(
        f"Offline source coverage, idempotence, script syntax and NFC UTF-16 hashes checked: {len(LETTERS)} letters, {sum(map(len, LESSONS.values()))} lessons, {len(data['audio'])} bundled clips."
    )
    check_player_interactions(node)
    print(
        "This is not browser cache/playback or physical Android/iPhone verification."
    )


if __name__ == "__main__":
    try:
        check_offline_learning()
    except Exception as e:
        logging.exception(f"Error: {e}")
        raise
