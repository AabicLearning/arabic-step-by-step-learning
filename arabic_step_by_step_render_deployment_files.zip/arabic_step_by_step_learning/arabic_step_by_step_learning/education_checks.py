import reflex as rx
from arabic_step_by_step_learning.states.education_data import (
    LESSONS,
    GAME_MODES,
    EDUCATION_COPY,
    plain_letters,
)
from arabic_step_by_step_learning.states.harakat_data import HARAKAT
from arabic_step_by_step_learning.states.vocabulary_data import CATEGORIES
from arabic_step_by_step_learning.states.phrases_data import DIALOGUES
from arabic_step_by_step_learning.states.education_state import EducationState
from arabic_step_by_step_learning.states.grammar_data import GRAMMAR_QUESTIONS, GRAMMAR_GROUPS
from arabic_step_by_step_learning.states.audio_catalog import source_catalog


def check_content():
    grammar = LESSONS["grammar"]
    assert len(grammar) == 13
    assert {item["group"] for item in grammar} == set(GRAMMAR_GROUPS)
    assert all(item["tip_en"] and item["tip_fr"] for item in grammar)
    examples = {item["arabic"] for item in grammar}
    assert {
        "أنا طالبٌ",
        "أنتَ طالبٌ",
        "أنتِ طالبةٌ",
        "هو صغيرٌ",
        "هي صغيرةٌ",
        "هذا طالبٌ",
        "هذه طالبةٌ",
        "الولدُ صغيرٌ",
        "البنتُ صغيرةٌ",
        "هي تقرأُ كتابًا",
    } <= examples
    assert GAME_MODES["grammar"] == list(GRAMMAR_QUESTIONS)
    catalog = source_catalog()
    ids = {item["id"] for item in grammar}
    question_ids = []
    for mode, questions in GRAMMAR_QUESTIONS.items():
        assert questions
        for question in questions:
            question_ids.append(question["id"])
            assert question["lesson"] in ids
            assert all(
                question[key]
                for key in (
                    "prompt_en",
                    "prompt_fr",
                    "en",
                    "fr",
                    "roman",
                    "arabic",
                )
            )
            assert question["arabic"] in catalog
            if mode == "grammar_order":
                assert question["correct"] == question["arabic"]
                assert len(question["arabic"].split()) in (2, 3)
            else:
                assert (
                    len(set(question["options"]))
                    == len(question["options"])
                    >= 2
                )
                assert question["correct"] in question["options"]
    assert len(set(question_ids)) == len(question_ids)
    assert len(LESSONS["harakat"]) == 4
    assert [x["numeral"] for x in LESSONS["numbers"]] == list("٠١٢٣٤٥٦٧٨٩") + [
        "١٠"
    ]
    assert len(LESSONS["colors"]) == 10
    assert len(LESSONS["phrases"]) == len(DIALOGUES) == 12
    assert set(CATEGORIES) == {"family", "home", "food", "animals", "school"}
    assert [
        len(GAME_MODES[x])
        for x in ["harakat", "numbers", "colors", "vocabulary"]
    ] == [4, 5, 4, 5]
    for key, lessons in LESSONS.items():
        assert lessons and len({x["id"] for x in lessons}) == len(lessons)
        for item in lessons:
            assert all(item[x] for x in ["id", "arabic", "roman", "en", "fr"])
            assert plain_letters(item["arabic"])
    for mark, item in zip(HARAKAT, LESSONS["harakat"]):
        assert item["b"] == f"ب{mark['mark']}"
        assert item["m"] == f"م{mark['mark']}"
    assert all(en and fr for en, fr in EDUCATION_COPY.values())
    for modes in GAME_MODES.values():
        for mode in modes:
            assert mode in EDUCATION_COPY
            assert (
                "ordering_help_short" if mode == "ordering" else f"{mode}_help"
            ) in EDUCATION_COPY
    assert plain_letters("أُمّ") == ["أ", "م"]
    assert plain_letters("سَبُّورَة") == ["س", "ب", "و", "ر", "ة"]


async def check_events(run_event):
    state = EducationState()
    for module, modes in GAME_MODES.items():
        state._configure(module, practice=True)
        for category in CATEGORIES if module == "vocabulary" else ["family"]:
            await run_event(state.choose_category, category)
            for mode in modes:
                await run_event(state.start_mode, mode)
                for target in range(len(state.lessons)):
                    state._new_round(target)
                    await run_event(state.check_answer)
                    assert ~state.answered
                    if state.tile_mode:
                        remaining = list(range(len(state.tiles)))
                        for letter in state.expected_tiles:
                            tile = next(
                                i
                                for i in remaining
                                if state.tiles[i]["text_en"] == letter
                            )
                            await run_event(state.add_tile, tile)
                            remaining.remove(tile)
                    else:
                        await run_event(state.select_answer, state.correct_id)
                    old_score = state.score
                    await run_event(state.check_answer)
                    assert state.answered & (state.score == old_score + 1)
                    assert state.feedback == "well_done"
                    await run_event(state.check_answer)
                    assert state.score == old_score + 1
                    await run_event(state.next_round)
                    assert ~state.answered
                if ~state.tile_mode:
                    await run_event(
                        state.select_answer,
                        (state.correct_id + 1) % len(state.choices),
                    )
                    await run_event(state.check_answer)
                    assert state.feedback == "try_again"
    state._configure("words")
    assert (state.mode == "build_word") & (state.view == "practice")
    state._configure("dialogues")
    assert state.mode == "dialogue"
    state._configure("numbers")
    await run_event(state.move_lesson, -1)
    assert state.selected == 0
    await run_event(state.move_lesson, 100)
    assert state.selected == 10
    await run_event(state.complete_lesson)
    assert state.lesson_feedback & (
        state.last_completion["activity"] == "lesson"
    )
    sequence = state.completion_sequence
    await run_event(state.complete_lesson)
    assert state.completion_sequence == sequence
