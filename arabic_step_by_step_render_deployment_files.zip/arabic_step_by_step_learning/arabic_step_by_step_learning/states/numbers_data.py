import reflex as rx

NUMBER_ROWS: list[tuple[str, str, str, str, str]] = [
    ("٠", "صِفْر", "ṣifr", "zero", "zéro"),
    ("١", "وَاحِد", "wāḥid", "one", "un"),
    ("٢", "اِثْنَان", "ithnān", "two", "deux"),
    ("٣", "ثَلَاثَة", "thalātha", "three", "trois"),
    ("٤", "أَرْبَعَة", "arbaʿa", "four", "quatre"),
    ("٥", "خَمْسَة", "khamsa", "five", "cinq"),
    ("٦", "سِتَّة", "sitta", "six", "six"),
    ("٧", "سَبْعَة", "sabʿa", "seven", "sept"),
    ("٨", "ثَمَانِيَة", "thamāniya", "eight", "huit"),
    ("٩", "تِسْعَة", "tisʿa", "nine", "neuf"),
    ("١٠", "عَشَرَة", "ʿashara", "ten", "dix"),
]
