import reflex as rx

COLOR_ROWS: list[tuple[str, str, str, str, str, str]] = [
    ("red", "أَحْمَر", "aḥmar", "red", "rouge", "bg-[#DC2626]"),
    ("blue", "أَزْرَق", "azraq", "blue", "bleu", "bg-[#2563EB]"),
    ("yellow", "أَصْفَر", "aṣfar", "yellow", "jaune", "bg-[#FACC15]"),
    ("green", "أَخْضَر", "akhḍar", "green", "vert", "bg-[#16A34A]"),
    ("orange", "بُرْتُقَالِيّ", "burtuqālī", "orange", "orange", "bg-[#F97316]"),
    ("purple", "بَنَفْسَجِيّ", "banafsajī", "purple", "violet", "bg-[#9333EA]"),
    ("pink", "وَرْدِيّ", "wardī", "pink", "rose", "bg-[#F472B6]"),
    ("brown", "بُنِّيّ", "bunnī", "brown", "marron", "bg-[#92400E]"),
    ("black", "أَسْوَد", "aswad", "black", "noir", "bg-[#171717]"),
    ("white", "أَبْيَض", "abyaḍ", "white", "blanc", "bg-[#FFFFFF]"),
]
