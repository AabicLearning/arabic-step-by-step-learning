import reflex as rx
from arabic_step_by_step_learning.states.education_data import LESSONS, GAME_MODES
from arabic_step_by_step_learning.states.vocabulary_data import CATEGORIES


def lesson_ids(module: str) -> list[str]:
    if module in ("letters", "writing"):
        return [str(i) for i in range(28)]
    if module == "games":
        return [
            "find",
            "listen_game",
            "match",
            "memory",
            "odd",
            *[mode for modes in GAME_MODES.values() for mode in modes],
        ]
    if module == "vocabulary":
        return [
            item["id"] for category in CATEGORIES for item in LESSONS[category]
        ]
    return [item["id"] for item in LESSONS.get(module, [])]


PROGRESS_COPY: dict[str, tuple[str, str]] = {
    "module_harakat": ("Vowels & Sounds", "Voyelles et sons"),
    "module_writing": ("Writing", "Écriture"),
    "module_vocabulary": ("Basic Words", "Mots de base"),
    "module_games": ("Games", "Jeux"),
    "desc_writing": (
        "Validate each of 28 isolated letters to complete Writing. Also practise connected forms, syllables and words.",
        "Validez les 28 lettres isolées pour terminer Écriture. Pratiquez aussi formes liées, syllabes et mots.",
    ),
    "desc_games": (
        "Letter games, word building and dialogue challenges.",
        "Jeux de lettres, construction de mots et dialogues.",
    ),
    "activities_access": (
        "All online lessons, writing traces and games are available from the start. Progress, stars and badges are earned through completed lessons and practice.",
        "Toutes les leçons, tous les tracés et jeux en ligne sont accessibles dès le départ. Les progrès, étoiles et badges se gagnent en terminant les leçons et en pratiquant.",
    ),
    "lesson_done": (
        "Lesson saved! Each new lesson earns 5 stars, each new module 20. Repeats are welcome, without duplicate bonuses.",
        "Leçon enregistrée ! Chaque nouvelle leçon rapporte 5 étoiles, chaque nouveau module 20. Révisez sans bonus en double.",
    ),
    "future_note": (
        "Explore this module now, with no lessons required. Opening it does not change your saved progress.",
        "Explorez ce module dès maintenant, sans leçon préalable. L’ouvrir ne modifie pas vos progrès enregistrés.",
    ),
    "req_letters3": ("3 Arabic letter lessons", "3 leçons de lettres arabes"),
    "req_letters5": ("5 Arabic letter lessons", "5 leçons de lettres arabes"),
    "req_harakat": (
        "all 4 Vowels & Sounds lessons",
        "les 4 leçons de voyelles et sons",
    ),
    "req_numbers": ("all 11 Numbers lessons", "les 11 leçons de nombres"),
    "req_colors": ("all 10 Colors lessons", "les 10 leçons de couleurs"),
    "req_words": ("10 Basic Words lessons", "10 leçons de mots de base"),
    "completed": ("Completed", "Terminées"),
    "exercises_saved": (
        "Unique correct exercises",
        "Exercices corrects uniques",
    ),
    "learned_words": ("Words learned", "Mots appris"),
    "reward_rules": (
        "+1 per correct answer · +5 per new lesson · +20 per new module. Writing requires a validated trace. Games count one success per mode toward their bar.",
        "+1 par bonne réponse · +5 par nouvelle leçon · +20 par nouveau module. L’écriture exige un tracé validé. Les jeux comptent une réussite par mode dans leur barre.",
    ),
    "progress_desc": (
        "Your saved lessons, writing, games and milestones — real steps, at your pace.",
        "Vos leçons, tracés, jeux et étapes enregistrés — de vrais pas, à votre rythme.",
    ),
    "badges": ("Your badges", "Vos badges"),
    "not_earned": ("Not earned yet", "Pas encore obtenu"),
    "badge_first": ("First Lesson", "Première leçon"),
    "badge_letters": ("Letter Explorer", "Explorateur des lettres"),
    "badge_writing": ("Writing Beginner", "Débutant en écriture"),
    "badge_numbers": ("Number Beginner", "Débutant en nombres"),
    "badge_colors": ("Color Master", "Maître des couleurs"),
    "badge_words": ("Word Explorer", "Explorateur des mots"),
    "badge_first_hint": ("Complete 1 lesson", "Terminez 1 leçon"),
    "badge_letters_hint": (
        "Complete all 28 letter lessons",
        "Terminez les 28 leçons de lettres",
    ),
    "badge_writing_hint": (
        "Validate tracing for 3 different letters",
        "Validez les tracés de 3 lettres différentes",
    ),
    "badge_numbers_hint": (
        "Complete 3 number lessons",
        "Terminez 3 leçons de nombres",
    ),
    "badge_colors_hint": (
        "Complete all 10 color lessons",
        "Terminez les 10 leçons de couleurs",
    ),
    "badge_words_hint": (
        "Learn 10 different vocabulary words",
        "Apprenez 10 mots de vocabulaire différents",
    ),
    "growing": ("Growing Beginner", "Débutant en progrès"),
    "confident": ("Confident Beginner", "Débutant confiant"),
    "sound": ("Pronunciation sound", "Son de prononciation"),
    "sound_on": ("Sound on", "Son activé"),
    "sound_off": ("Sound off", "Son désactivé"),
    "sound_hint": (
        "Plays bundled Arabic MP3 clips; no device Arabic voice is needed. Visual alternatives remain available.",
        "Lit les MP3 arabes intégrés, sans voix arabe de l’appareil. Les alternatives visuelles restent disponibles.",
    ),
    "reset_progress": ("Reset learning progress", "Réinitialiser les progrès"),
    "reset_title": ("Start progress over?", "Recommencer la progression ?"),
    "reset_detail": (
        "This removes saved lessons, exercises, stars, words, daily history, streaks, badges and review schedules in this browser. Your nickname, language and sound preference stay. This cannot be undone.",
        "Cela efface les leçons, exercices, étoiles, mots, historique quotidien, séries, badges et calendriers de révision de ce navigateur. Votre surnom, langue et préférence sonore restent. Cette action est irréversible.",
    ),
    "cancel": ("Cancel", "Annuler"),
    "reset_done": (
        "Progress reset. Your preferences are unchanged.",
        "Progrès réinitialisés. Vos préférences sont conservées.",
    ),
    "storage_error": (
        "Saved progress could not be read. Reset it in Settings to start again.",
        "Impossible de lire les progrès enregistrés. Réinitialisez-les dans les réglages pour recommencer.",
    ),
    "about_desc": (
        "Arabic · Step by Step stores your nickname, interface language, onboarding and sound preferences, completed lesson and exercise IDs, stars, learned vocabulary, daily answers and dates, and spaced-repetition review schedules in this browser’s local storage. Reviews reschedule learned letters and words without awarding stars or new completions. No account, database or cross-device backup. Clearing site data removes it; reset progress preserves preferences. Audio is synthetic, generated at build time with eSpeak NG (GPLv3+ build tool); it is a learning guide, not native-speaker audio. Tracing checks guide coverage, not handwriting quality.",
        "L’arabe, pas à pas conserve votre surnom, langue, accueil, son, identifiants des leçons et exercices terminés, étoiles, vocabulaire appris, réponses quotidiennes et dates, et calendriers de révision espacée dans le stockage local de ce navigateur. Les révisions reprogramment les lettres et mots appris sans étoiles ni nouvelles leçons terminées. Aucun compte, base de données ou sauvegarde entre appareils. Effacer les données du site supprime tout ; réinitialiser les progrès conserve les préférences. L’audio synthétique est généré à la compilation avec eSpeak NG (outil sous GPLv3+) ; c’est un guide, pas un enregistrement natif. Le tracé vérifie le suivi du guide, pas la qualité de l’écriture.",
    ),
    "daily_detail": (
        "2 letters · 1 sound · 1 word · 1 number. Start on your first day, with no lessons required. All online modules are also available from the start. Listen and try again freely. Five correct answers complete today’s routine, saved as you go; each date counts once toward your streak. Choose any lesson or game at your own pace.",
        "2 lettres · 1 son · 1 mot · 1 nombre. Commencez dès le premier jour, sans leçon préalable. Tous les modules en ligne sont également accessibles dès le départ. Écoutez et réessayez librement. Cinq bonnes réponses terminent la routine, sauvegardée à chaque étape ; chaque date compte une fois dans votre série. Choisissez toute leçon ou tout jeu à votre rythme.",
    ),
    "daily_title": (
        "Your five daily activities",
        "Vos cinq activités quotidiennes",
    ),
    "daily_done": (
        "Today is complete! Come back tomorrow.",
        "Aujourd’hui est terminé ! Revenez demain.",
    ),
    "daily_locked": (
        "Daily practice is available from your first day — no completed lessons needed. These five activities explore the foundations; all online lessons and games are open too.",
        "La pratique quotidienne est disponible dès le premier jour — aucune leçon terminée nécessaire. Ces cinq activités présentent les bases ; toutes les leçons et tous les jeux en ligne sont aussi accessibles.",
    ),
    "daily_retry": (
        "Not quite — try again. Only a correct answer advances this activity.",
        "Pas tout à fait — réessayez. Seule une bonne réponse termine cette activité.",
    ),
    "daily_correct": (
        "Correct! Your answer is saved.",
        "Bravo ! Votre réponse est enregistrée.",
    ),
    "daily_button": ("Open daily practice", "Ouvrir la pratique quotidienne"),
    "daily_letter": ("Choose the letter named", "Choisissez la lettre nommée"),
    "daily_sound": (
        "Choose the syllable for this sound",
        "Choisissez la syllabe pour ce son",
    ),
    "daily_word": ("Choose the word meaning", "Choisissez le mot signifiant"),
    "daily_number": (
        "Choose the Arabic numeral for",
        "Choisissez le chiffre arabe pour",
    ),
    "review_title": ("Keep what you’ve learned", "Gardez vos acquis"),
    "review_desc": (
        "A little review at the right time helps letters and words stay familiar. Separate from your five daily activities, without stars or new lesson completions.",
        "Une petite révision au bon moment aide à retenir lettres et mots. Indépendante des cinq activités quotidiennes, sans étoiles ni nouvelles leçons terminées.",
    ),
    "review_due": ("Due for review", "À réviser"),
    "review_open": ("Open review", "Ouvrir la révision"),
    "review_empty": (
        "No learned items yet. Complete a letter or vocabulary lesson, or learn a vocabulary word through practice, and it will be ready to review here.",
        "Aucun élément appris pour le moment. Terminez une leçon de lettres ou de vocabulaire, ou apprenez un mot en pratiquant, pour le retrouver ici.",
    ),
    "review_caught_up": ("You’re all caught up!", "Vous êtes à jour !"),
    "review_caught_up_detail": (
        "Nothing else is due today. Come back for your next review, or keep learning at your own pace.",
        "Plus rien à réviser aujourd’hui. Revenez pour la prochaine révision ou continuez à apprendre à votre rythme.",
    ),
    "review_loading": (
        "Checking your local date…",
        "Vérification de votre date locale…",
    ),
    "review_progress": ("Reviewed this session", "Révisés dans cette session"),
    "review_letter_prompt": (
        "Choose the letter named",
        "Choisissez la lettre nommée",
    ),
    "review_word_prompt": (
        "Choose the Arabic word meaning",
        "Choisissez le mot arabe signifiant",
    ),
    "review_correct": (
        "Well done! This item will return a little later.",
        "Bravo ! Cet élément reviendra un peu plus tard.",
    ),
    "review_incorrect": (
        "Not quite — here’s the correct answer. You’ll see it again tomorrow.",
        "Pas tout à fait — voici la bonne réponse. Vous la reverrez demain.",
    ),
    "review_next_date": ("Next review", "Prochaine révision"),
    "review_continue": ("Continue", "Continuer"),
    "review_finish": ("Back to my learning", "Retour à mon apprentissage"),
}
