import reflex as rx
import random
from typing import TypedDict
from arabic_step_by_step_learning.states.education_data import (
    LESSONS,
    GAME_MODES,
    LessonData,
    plain_letters,
)
from arabic_step_by_step_learning.states.harakat_data import HARAKAT
from arabic_step_by_step_learning.states.phrases_data import (
    DIALOGUES,
    SENTENCES,
    sentence_words,
)
from arabic_step_by_step_learning.states.vocabulary_data import CATEGORIES
from arabic_step_by_step_learning.states.grammar_data import GRAMMAR_GROUPS, GRAMMAR_QUESTIONS


class ActivityChoice(TypedDict):
    id: int
    text_en: str
    text_fr: str
    swatch: str
    arabic: bool


class EducationState(rx.State):
    module: str = "harakat"
    category: str = "family"
    selected: int = 0
    view: str = "lesson"
    mode: str = "vowel_listen"
    round_number: int = 1
    score: int = 0
    attempts: int = 0
    choices: list[ActivityChoice] = []
    correct_id: int = -1
    selected_answer: int = -1
    answered: bool = False
    feedback: str = ""
    prompt_en: str = ""
    prompt_fr: str = ""
    prompt_arabic: bool = False
    prompt_swatch: str = ""
    audio: str = ""
    reveal: bool = False
    target_arabic: str = ""
    target_roman: str = ""
    answer_en: str = ""
    answer_fr: str = ""
    object_count: int = -1
    tiles: list[ActivityChoice] = []
    used_tiles: list[int] = []
    expected_tiles: list[str] = []
    lesson_feedback: bool = False
    target_item: str = ""
    completion_sequence: int = 0
    grammar_claimed: bool = False
    sentence_claimed: bool = False
    last_completion: dict[str, str] = {
        "module": "",
        "category": "",
        "activity": "",
        "item": "",
    }

    @rx.var
    def lessons(self) -> list[LessonData]:
        return LESSONS[
            self.category if self.module == "vocabulary" else self.module
        ]

    @rx.var
    def current(self) -> LessonData:
        return self.lessons[self.selected]

    @rx.var
    def modes(self) -> list[str]:
        return GAME_MODES[self.module]

    @rx.var
    def grammar_groups(self) -> list[str]:
        return GRAMMAR_GROUPS

    @rx.var
    def categories(self) -> list[str]:
        return list(CATEGORIES)

    @rx.var
    def objects(self) -> list[int]:
        return list(range(max(0, self.object_count)))

    @rx.var
    def tile_mode(self) -> bool:
        return self.mode in (
            "build_word",
            "ordering",
            "sentence_build",
            "grammar_order",
        )

    @rx.var
    def built_text(self) -> str:
        separator = (
            " · "
            if self.mode == "ordering"
            else " "
            if self.mode in ("sentence_build", "grammar_order")
            else ""
        )
        return separator.join(self.tiles[i]["text_en"] for i in self.used_tiles)

    def _configure(self, module: str, practice: bool = False):
        aliases = {"words": "vocabulary", "dialogues": "phrases"}
        actual = aliases.get(module, module)
        if actual not in GAME_MODES:
            return
        self.module = actual
        self.selected = 0
        self.lesson_feedback = False
        self.view = "practice" if practice or module in aliases else "lesson"
        self.mode = (
            "build_word"
            if module == "words"
            else "dialogue"
            if module == "dialogues"
            else GAME_MODES[actual][0]
        )
        self.score = 0
        self.attempts = 0
        self.round_number = 1
        self._new_round()

    @rx.event
    def select_lesson(self, index: int):
        if 0 <= index < len(self.lessons):
            self.selected = index
            self.lesson_feedback = False

    @rx.event
    def move_lesson(self, offset: int):
        self.selected = max(
            0, min(len(self.lessons) - 1, self.selected + offset)
        )
        self.lesson_feedback = False

    @rx.event
    def choose_category(self, category: str):
        if category in CATEGORIES:
            self.category = category
            self.selected = 0
            self.lesson_feedback = False
            self.score = 0
            self.attempts = 0
            self.round_number = 1
            self._new_round()

    @rx.event
    async def set_view(self, view: str):
        from arabic_step_by_step_learning.states.learning_state import LearningState

        progress = await self.get_state(LearningState)
        if not progress._available(self.module):
            return
        if view in ("lesson", "practice"):
            self.view = view
            if view == "practice":
                self._new_round(
                    self.selected, progress.progress_data["lessons"]
                )

    @rx.event
    async def start_mode(self, mode: str):
        from arabic_step_by_step_learning.states.learning_state import LearningState

        progress = await self.get_state(LearningState)
        if not progress._available(self.module):
            return
        if mode in self.modes:
            self.mode = mode
            self.view = "practice"
            self.score = 0
            self.attempts = 0
            self.round_number = 1
            self._new_round(completed=progress.progress_data["lessons"])

    def _choice(
        self,
        index: int,
        en: str,
        fr: str = "",
        swatch: str = "",
        arabic: bool = True,
    ) -> ActivityChoice:
        return ActivityChoice(
            id=index, text_en=en, text_fr=fr or en, swatch=swatch, arabic=arabic
        )

    def _new_round(
        self, target_index: int = -1, completed: list[str] | None = None
    ):
        pool = self.lessons
        target = (
            target_index
            if 0 <= target_index < len(pool)
            else random.randrange(len(pool))
        )
        item = pool[target]
        self.target_item = item["id"]
        self.answered = False
        self.grammar_claimed = False
        self.sentence_claimed = False
        self.feedback = ""
        self.selected_answer = -1
        self.reveal = False
        self.prompt_en = ""
        self.prompt_fr = ""
        self.prompt_arabic = False
        self.prompt_swatch = ""
        self.object_count = -1
        self.tiles = []
        self.used_tiles = []
        self.expected_tiles = []
        self.target_arabic = item["arabic"]
        self.target_roman = item["roman"]
        self.audio = item["arabic"]
        self.answer_en = f"{item['arabic']} · {item['roman']} · {item['en']}"
        self.answer_fr = f"{item['arabic']} · {item['roman']} · {item['fr']}"
        ids = random.sample(
            [i for i in range(len(pool)) if i != target], min(3, len(pool) - 1)
        )
        ids.append(target)
        random.shuffle(ids)
        self.correct_id = ids.index(target)
        self.choices = [
            self._choice(i, pool[n]["arabic"]) for i, n in enumerate(ids)
        ]
        mode = self.mode
        if self.module == "grammar":
            self._grammar_round(target_index)
            return
        if mode == "sentence_build" and self.module == "phrases":
            self.choices = []
            self.target_item = ""
            self.audio = ""
            self.target_arabic = ""
            self.answer_en = self.answer_fr = ""
            sentence = random.choice(SENTENCES)
            self.target_item = sentence["id"]
            self.target_arabic = sentence["arabic"]
            self.audio = sentence["arabic"]
            self.prompt_en, self.prompt_fr = sentence["en"], sentence["fr"]
            self.answer_en, self.answer_fr = sentence["en"], sentence["fr"]
            self.expected_tiles = sentence_words(sentence["arabic"])
            shuffled = self.expected_tiles[:]
            random.shuffle(shuffled)
            if shuffled == self.expected_tiles and len(set(shuffled)) > 1:
                shuffled = shuffled[1:] + shuffled[:1]
            self.tiles = [
                self._choice(i, word) for i, word in enumerate(shuffled)
            ]
            return
        if self.module == "harakat":
            consonant = random.choice(["ب", "م"])
            latin = "b" if consonant == "ب" else "m"
            mark = HARAKAT[target]["mark"]
            syllable = f"{consonant}{mark}"
            sound = f"{latin}{HARAKAT[target]['sound']}"
            self.target_arabic = syllable
            self.target_roman = sound
            self.audio = syllable if target != 3 else f"أَ{syllable}"
            self.answer_en = self.answer_fr = (
                f"{syllable} · {sound} · {item['roman']}"
            )
            self.choices = [
                self._choice(i, f"{consonant}{HARAKAT[n]['mark']}")
                for i, n in enumerate(ids)
            ]
            if mode == "sound_match":
                self.prompt_en = self.prompt_fr = sound
            elif mode == "vowel_choice":
                self.prompt_en = self.prompt_fr = syllable
                self.prompt_arabic = True
                self.choices = [
                    self._choice(i, f"◌{HARAKAT[n]['mark']}")
                    for i, n in enumerate(ids)
                ]
            elif mode == "complete_syllable":
                self.prompt_en = self.prompt_fr = f"{consonant} + ◌ = {sound}"
                self.choices = [
                    self._choice(i, f"◌{HARAKAT[n]['mark']}")
                    for i, n in enumerate(ids)
                ]
        elif self.module == "numbers":
            if mode in ("numeral_match", "number_listen", "count_objects"):
                self.choices = [
                    self._choice(i, pool[n]["numeral"])
                    for i, n in enumerate(ids)
                ]
            if mode == "numeral_match":
                self.prompt_en = self.prompt_fr = str(target)
            elif mode == "count_objects":
                self.object_count = target
            elif mode == "numeral_word":
                self.prompt_en = self.prompt_fr = item["numeral"]
                self.prompt_arabic = True
            elif mode == "ordering":
                values = sorted(random.sample(range(11), 5))
                self.expected_tiles = [pool[n]["numeral"] for n in values]
                random.shuffle(values)
                self.tiles = [
                    self._choice(i, pool[n]["numeral"])
                    for i, n in enumerate(values)
                ]
                self.answer_en = self.answer_fr = " · ".join(
                    self.expected_tiles
                )
        elif self.module == "colors":
            if mode == "swatch_word":
                self.prompt_swatch = item["swatch"]
            elif mode in ("word_swatch", "color_listen"):
                self.choices = [
                    self._choice(i, "", swatch=pool[n]["swatch"])
                    for i, n in enumerate(ids)
                ]
                if mode == "word_swatch":
                    self.prompt_en = self.prompt_fr = item["arabic"]
                    self.prompt_arabic = True
            else:
                self.prompt_en, self.prompt_fr = item["en"], item["fr"]
        elif self.module == "vocabulary":
            letters = plain_letters(item["arabic"])
            if mode in ("meaning_word", "build_word"):
                self.prompt_en, self.prompt_fr = item["en"], item["fr"]
            elif mode == "word_meaning":
                self.prompt_en = self.prompt_fr = item["arabic"]
                self.prompt_arabic = True
                self.choices = [
                    self._choice(i, pool[n]["en"], pool[n]["fr"], arabic=False)
                    for i, n in enumerate(ids)
                ]
            if mode == "build_word":
                self.expected_tiles = letters
                shuffled = letters[:]
                random.shuffle(shuffled)
                self.tiles = [
                    self._choice(i, letter) for i, letter in enumerate(shuffled)
                ]
            elif mode == "missing_letter":
                missing = random.randrange(len(letters))
                correct = letters[missing]
                alphabet = list("ابتثجحخدذرزسشصضطظعغفقكلمنهويأةء")
                options = random.sample(
                    [c for c in alphabet if c != correct], 3
                )
                options.append(correct)
                random.shuffle(options)
                self.correct_id = options.index(correct)
                self.choices = [
                    self._choice(i, c) for i, c in enumerate(options)
                ]
                letters[missing] = "□"
                self.prompt_en = self.prompt_fr = "".join(letters)
                self.prompt_arabic = True
        elif self.module == "phrases":
            if mode == "dialogue":
                scene = DIALOGUES[target]
                self.audio = scene[0]
                self.target_arabic = scene[0]
                self.prompt_en, self.prompt_fr = scene[1], scene[2]
                self.target_roman = ""
            else:
                self.prompt_en = self.prompt_fr = item["arabic"]
                self.prompt_arabic = True
                self.choices = [
                    self._choice(i, pool[n]["en"], pool[n]["fr"], arabic=False)
                    for i, n in enumerate(ids)
                ]

    def _grammar_round(self, target_index: int = -1):
        questions = GRAMMAR_QUESTIONS[self.mode]
        relevant = (
            [q for q in questions if q["lesson"] == self.current["id"]]
            if target_index >= 0
            else []
        )
        question = random.choice(relevant or questions)
        self.target_item = question["id"]
        self.target_arabic = question["arabic"]
        self.target_roman = question["roman"]
        self.audio = question["arabic"]
        self.prompt_en, self.prompt_fr = (
            question["prompt_en"],
            question["prompt_fr"],
        )
        self.answer_en = f"{question['roman']} · {question['en']}"
        self.answer_fr = f"{question['roman']} · {question['fr']}"
        self.choices = []
        self.correct_id = -1
        if self.mode == "grammar_order":
            self.expected_tiles = question["arabic"].split()
            shuffled = self.expected_tiles[:]
            random.shuffle(shuffled)
            if shuffled == self.expected_tiles:
                shuffled = shuffled[1:] + shuffled[:1]
            self.tiles = [
                self._choice(i, word) for i, word in enumerate(shuffled)
            ]
        else:
            options = question["options"][:]
            random.shuffle(options)
            self.correct_id = options.index(question["correct"])
            self.choices = [
                self._choice(i, word) for i, word in enumerate(options)
            ]

    @rx.event
    def select_answer(self, choice_id: int):
        if not self.answered and 0 <= choice_id < len(self.choices):
            self.selected_answer = choice_id
            self.feedback = ""

    @rx.event
    def add_tile(self, tile_id: int):
        if (
            not self.answered
            and 0 <= tile_id < len(self.tiles)
            and tile_id not in self.used_tiles
        ):
            self.used_tiles.append(tile_id)
            self.feedback = ""

    @rx.event
    def undo_tile(self):
        if not self.answered and self.used_tiles:
            self.used_tiles.pop()
            self.feedback = ""

    @rx.event
    def clear_tiles(self):
        if not self.answered:
            self.used_tiles = []
            self.feedback = ""

    @rx.event
    async def check_answer(self):
        from arabic_step_by_step_learning.states.learning_state import LearningState

        progress = await self.get_state(LearningState)
        if not progress._available(self.module):
            return
        if self.answered:
            return
        if self.mode == "sentence_build" and not (
            self.module == "phrases"
            and any(
                s["id"] == self.target_item
                and sentence_words(s["arabic"]) == self.expected_tiles
                for s in SENTENCES
            )
        ):
            self._new_round(completed=progress.progress_data["lessons"])
            return
        if self.tile_mode:
            if (
                not self.tiles
                or len(self.used_tiles) != len(self.tiles)
                or len(set(self.used_tiles)) != len(self.used_tiles)
                or any(not 0 <= i < len(self.tiles) for i in self.used_tiles)
            ):
                self.feedback = "tiles_incomplete"
                return
            correct = [
                self.tiles[i]["text_en"] for i in self.used_tiles
            ] == self.expected_tiles
        else:
            if self.selected_answer < 0:
                self.feedback = "choose_answer"
                return
            correct = self.selected_answer == self.correct_id
        self.answered = True
        self.attempts += 1
        self.score += int(correct)
        self.feedback = "well_done" if correct else "try_again"
        if correct:
            yield EducationState.activity_completed(
                self.module, self.category, self.mode, self.target_item
            )

    @rx.event
    async def activity_completed(
        self, module: str, category: str, activity: str, item: str
    ):
        from arabic_step_by_step_learning.states.learning_state import LearningState

        progress = await self.get_state(LearningState)
        if not progress._available(module):
            return
        if activity == "sentence_build" and (
            module != "phrases"
            or self.sentence_claimed
            or not self.answered
            or self.feedback != "well_done"
            or self.mode != activity
            or self.module != module
            or self.target_item != item
            or not any(
                s["id"] == item
                and sentence_words(s["arabic"]) == self.expected_tiles
                for s in SENTENCES
            )
            or len(self.used_tiles) != len(self.tiles)
            or len(set(self.used_tiles)) != len(self.used_tiles)
            or any(not 0 <= i < len(self.tiles) for i in self.used_tiles)
            or [self.tiles[i]["text_en"] for i in self.used_tiles]
            != self.expected_tiles
        ):
            return
        if activity == "sentence_build":
            self.sentence_claimed = True
        if module == "grammar":
            valid_lesson = (
                activity == "lesson"
                and item == self.current["id"]
                and self.module == module
            )
            valid_question = (
                activity in GRAMMAR_QUESTIONS
                and self.module == module
                and self.mode == activity
                and self.target_item == item
                and self.answered
                and self.feedback == "well_done"
                and any(q["id"] == item for q in GRAMMAR_QUESTIONS[activity])
            )
            if not (valid_lesson or valid_question):
                return
            if valid_question:
                if self.grammar_claimed:
                    return
                self.grammar_claimed = True
        self.completion_sequence += 1
        self.last_completion = {
            "module": module,
            "category": category if module == "vocabulary" else "",
            "activity": activity,
            "item": item,
        }
        pool = LESSONS[category if module == "vocabulary" else module]
        entry = next((x for x in pool if x["id"] == item), pool[0])
        exercise_item = (
            "·".join(self.expected_tiles) if activity == "ordering" else item
        )
        progress._record(
            module,
            item,
            lesson=activity == "lesson",
            exercise=f"{module}:{category if module != 'grammar' else ''}:{activity}:{exercise_item}"
            if activity != "lesson"
            else "",
            word=entry["arabic"] if module == "vocabulary" else "",
        )
        if activity != "lesson" and progress._available("games"):
            progress._record("games", activity, lesson=True)

    @rx.event
    def complete_lesson(self):
        if not self.lesson_feedback:
            self.lesson_feedback = True
            yield EducationState.activity_completed(
                self.module, self.category, "lesson", self.current["id"]
            )

    @rx.event
    def reveal_text(self):
        self.reveal = True

    @rx.event
    async def next_round(self):
        from arabic_step_by_step_learning.states.learning_state import LearningState

        progress = await self.get_state(LearningState)
        if self.answered:
            self.round_number += 1
            self._new_round(completed=progress.progress_data["lessons"])
