import reflex as rx
import json
import logging
import unicodedata
from datetime import date, timedelta
from typing import TypedDict

from arabic_step_by_step_learning.states.education_data import LESSONS
from arabic_step_by_step_learning.states.letter_data import LETTERS
from arabic_step_by_step_learning.states.vocabulary_data import CATEGORIES


class ReviewEntry(TypedDict):
    due: str
    interval: int
    streak: int


class ReviewTarget(TypedDict):
    id: str
    category: str
    en: str
    fr: str
    arabic: str


def local_date(value: str) -> date | None:
    try:
        parsed = date.fromisoformat(value)
        return parsed if parsed.isoformat() == value else None
    except (ValueError, TypeError):
        return None


def learned_targets(progress: dict[str, list[str]]) -> list[ReviewTarget]:
    lessons = set(progress.get("lessons", []))
    words = {
        unicodedata.normalize("NFC", word) for word in progress.get("words", [])
    }
    targets: dict[str, ReviewTarget] = {}
    for letter in LETTERS:
        key = f"letters:{letter['id']}"
        if key in lessons:
            targets[key] = ReviewTarget(
                id=key,
                category="letters",
                en=letter["romanization"],
                fr=letter["romanization"],
                arabic=letter["isolated"],
            )
    for category in CATEGORIES:
        for item in LESSONS[category]:
            key = f"vocabulary:{item['id']}"
            if (
                key in lessons
                or unicodedata.normalize("NFC", item["arabic"]) in words
            ):
                targets[key] = ReviewTarget(
                    id=key,
                    category=category,
                    en=item["en"],
                    fr=item["fr"],
                    arabic=item["arabic"],
                )
    return list(targets.values())


def read_schedule(value: str) -> dict[str, ReviewEntry]:
    try:
        raw = json.loads(value)
    except (ValueError, TypeError) as e:
        logging.exception(f"Error: {e}")
        return {}
    if not isinstance(raw, dict):
        return {}
    entries = raw.get("items", raw)
    if not isinstance(entries, dict):
        return {}
    valid_ids = {f"letters:{letter['id']}" for letter in LETTERS}
    valid_ids.update(
        f"vocabulary:{item['id']}"
        for category in CATEGORIES
        for item in LESSONS[category]
    )
    result: dict[str, ReviewEntry] = {}
    for key, entry in entries.items():
        if key not in valid_ids or not isinstance(entry, dict):
            continue
        due = entry.get("due")
        streak = entry.get("streak", 0)
        interval = entry.get("interval", 0)
        if (
            not isinstance(due, str)
            or local_date(due) is None
            or type(streak) is not int
            or not 0 <= streak <= 10000
            or type(interval) is not int
            or not 0 <= interval <= 60
        ):
            continue
        result[key] = ReviewEntry(due=due, interval=interval, streak=streak)
    return result


def next_entry(
    today: date, previous: ReviewEntry | None, correct: bool
) -> ReviewEntry:
    streak = (
        min((previous["streak"] if previous else 0) + 1, 10000)
        if correct
        else 0
    )
    intervals = (3, 7, 14, 30, 60)
    interval = intervals[min(streak - 1, len(intervals) - 1)] if correct else 1
    due = date.fromordinal(
        min(today.toordinal() + interval, date.max.toordinal())
    )
    return ReviewEntry(due=due.isoformat(), interval=interval, streak=streak)
