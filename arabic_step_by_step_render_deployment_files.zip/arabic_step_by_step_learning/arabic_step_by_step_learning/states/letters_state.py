import reflex as rx
import random
from typing import TypedDict
from arabic_step_by_step_learning.states.letter_data import LETTERS, POSITIONS, LetterData


class ChoiceData(TypedDict):
    id: int
    glyph: str
    letter_id: int


class LettersState(rx.State):
    selected: int = 0
    trace_mode: str = "isolated"
    quiz_position: str = "isolated"
    quiz_answer: str = ""
    quiz_round: int = 0
    game: str = "find"
    round_number: int = 1
    score: int = 0
    attempts: int = 0
    target: int = 0
    game_form: str = "final"
    choices: list[ChoiceData] = []
    correct_choice: int = 0
    answered: bool = False
    feedback: str = ""
    reveal: bool = False
    memory_cards: list[ChoiceData] = []
    flipped: list[int] = []
    matched: list[int] = []
    trace_claimed: str = ""

    @rx.event
    async def complete_lesson(self):
        from arabic_step_by_step_learning.states.learning_state import LearningState

        progress = await self.get_state(LearningState)
        progress._record("letters", str(self.selected), lesson=True)

    @rx.event
    async def validate_trace(self, result: dict[str, str | float | bool]):
        from arabic_step_by_step_learning.states.learning_state import LearningState

        progress = await self.get_state(LearningState)
        if not progress._available("writing"):
            return
        if (
            result.get("reference") != self.trace_text
            or result.get("passed") is not True
        ):
            return
        if (
            float(result.get("coverage", 0)) < 0.65
            or float(result.get("precision", 0)) < 0.55
            or float(result.get("length", 0)) < 80
            or result.get("began") is not True
        ):
            return
        key = f"{self.selected}:{self.trace_mode}"
        if self.trace_claimed == key:
            return
        self.trace_claimed = key
        progress._record(
            "writing",
            str(self.selected),
            lesson=self.trace_mode == "isolated",
            exercise=f"trace:{key}",
        )

    @rx.var
    def letters(self) -> list[LetterData]:
        return LETTERS

    @rx.var
    def current(self) -> LetterData:
        return LETTERS[self.selected]

    @rx.var
    def positions(self) -> list[str]:
        return POSITIONS if self.current["joins"] else ["isolated", "final"]

    @rx.var
    def trace_options(self) -> list[str]:
        return [
            *self.positions,
            "syllable_a",
            "syllable_i",
            "syllable_u",
            "short_word",
        ]

    @rx.var
    def trace_text(self) -> str:
        if self.trace_mode == "short_word":
            return self.current["word"]
        marks = {"syllable_a": "َ", "syllable_i": "ِ", "syllable_u": "ُ"}
        if self.trace_mode in marks:
            return f"{self.current['glyph']}{marks[self.trace_mode]}"
        return str(self.current.get(self.trace_mode, self.current["isolated"]))

    @rx.var
    def quiz_glyph(self) -> str:
        return str(self.current[self.quiz_position])

    @rx.var
    def target_letter(self) -> LetterData:
        return LETTERS[self.target]

    @rx.var
    def prompt_glyph(self) -> str:
        return str(self.target_letter[self.game_form])

    @rx.var
    def memory_complete(self) -> bool:
        return len(self.matched) == 8

    def _new_quiz(self):
        self.quiz_answer = ""
        self.quiz_position = random.choice(self.positions)
        self.quiz_round += 1

    @rx.event
    def select_letter(self, index: int):
        if 0 <= index < 28:
            self.selected = index
            self.trace_mode = "isolated"
            self.trace_claimed = ""
            self._new_quiz()

    @rx.event
    def move_letter(self, offset: int):
        self.selected = max(0, min(27, self.selected + offset))
        self.trace_mode = "isolated"
        self.trace_claimed = ""
        self._new_quiz()

    @rx.event
    def choose_trace(self, mode: str):
        if mode in self.trace_options:
            self.trace_mode = mode
            self.trace_claimed = ""

    @rx.event
    async def answer_form(self, position: str):
        if not self.quiz_answer and position in POSITIONS:
            self.quiz_answer = position
            if position == self.quiz_position:
                from arabic_step_by_step_learning.states.learning_state import LearningState

                progress = await self.get_state(LearningState)
                progress._record(
                    "letters",
                    str(self.selected),
                    exercise=f"form:{self.selected}:{position}",
                )

    @rx.event
    def next_quiz(self):
        self._new_quiz()

    def _new_game_round(self):
        self.answered = False
        self.feedback = ""
        self.reveal = False
        self.target = random.randrange(28)
        self.game_form = random.choice(
            ["initial", "medial", "final"]
            if LETTERS[self.target]["joins"]
            else ["final"]
        )
        ids = random.sample([i for i in range(28) if i != self.target], 3)
        ids.append(self.target)
        random.shuffle(ids)
        self.choices = [
            ChoiceData(id=i, glyph=LETTERS[n]["isolated"], letter_id=n)
            for i, n in enumerate(ids)
        ]
        self.correct_choice = ids.index(self.target)
        if self.game == "odd":
            other = random.choice([i for i in range(28) if i != self.target])
            odd_at = random.randrange(4)
            cards: list[ChoiceData] = []
            for i in range(4):
                n = other if i == odd_at else self.target
                forms = (
                    POSITIONS if LETTERS[n]["joins"] else ["isolated", "final"]
                )
                cards.append(
                    ChoiceData(
                        id=i,
                        glyph=str(LETTERS[n][random.choice(forms)]),
                        letter_id=n,
                    )
                )
            self.choices = cards
            self.correct_choice = odd_at
        if self.game == "memory":
            pool = random.sample(range(28), 4)
            board = [*pool, *pool]
            random.shuffle(board)
            self.memory_cards = [
                ChoiceData(id=i, glyph=LETTERS[n]["isolated"], letter_id=n)
                for i, n in enumerate(board)
            ]
            self.flipped = []
            self.matched = []

    @rx.event
    async def start_game(self, mode: str):
        from arabic_step_by_step_learning.states.learning_state import LearningState

        progress = await self.get_state(LearningState)
        if not progress._available("games"):
            return
        if mode in ["find", "listen_game", "match", "memory", "odd"]:
            self.game = mode
            self.score = 0
            self.attempts = 0
            self.round_number = 1
            self._new_game_round()

    @rx.event
    def ensure_game(self):
        if not self.choices:
            self._new_game_round()

    @rx.event
    async def answer_game(self, index: int):
        from arabic_step_by_step_learning.states.learning_state import LearningState

        progress = await self.get_state(LearningState)
        if (
            not progress._available("games")
            or self.answered
            or not self.choices
            or not 0 <= index < 4
        ):
            return
        self.answered = True
        self.attempts += 1
        correct = index == self.correct_choice
        self.score += int(correct)
        self.feedback = "well_done" if correct else "try_again"
        if correct:
            from arabic_step_by_step_learning.states.learning_state import LearningState

            progress = await self.get_state(LearningState)
            progress._record(
                "games",
                self.game,
                lesson=True,
                exercise=f"letter-game:{self.game}:{self.choices[index]['letter_id']}:{self.game_form}",
            )

    @rx.event
    def reveal_name(self):
        self.reveal = True

    @rx.event
    def next_round(self):
        if self.answered or self.memory_complete:
            self.round_number += 1
            self._new_game_round()

    @rx.event
    async def flip_card(self, index: int):
        from arabic_step_by_step_learning.states.learning_state import LearningState

        progress = await self.get_state(LearningState)
        if not progress._available("games"):
            return
        if (
            not 0 <= index < len(self.memory_cards)
            or index in self.matched
            or index in self.flipped
        ):
            return
        if len(self.flipped) == 2:
            self.flipped = []
        self.flipped.append(index)
        self.feedback = ""
        if len(self.flipped) == 2:
            self.attempts += 1
            a, b = self.flipped
            if (
                self.memory_cards[a]["letter_id"]
                == self.memory_cards[b]["letter_id"]
            ):
                self.matched.extend(self.flipped)
                self.flipped = []
                self.score += 1
                self.feedback = (
                    "memory_done" if self.memory_complete else "memory_pair"
                )
                from arabic_step_by_step_learning.states.learning_state import LearningState

                progress = await self.get_state(LearningState)
                progress._record(
                    "games",
                    "memory",
                    lesson=self.memory_complete,
                    exercise=f"memory:{self.memory_cards[a]['letter_id']}",
                )
            else:
                self.feedback = "memory_miss"
