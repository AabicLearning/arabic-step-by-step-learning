import reflex as rx
import unicodedata
from arabic_step_by_step_learning.states.letter_data import LETTERS
from arabic_step_by_step_learning.states.education_data import LESSONS
from arabic_step_by_step_learning.states.phrases_data import DIALOGUES, SENTENCES
from arabic_step_by_step_learning.states.grammar_data import GRAMMAR_QUESTIONS


def audio_filename(text: str) -> str:
    encoded = unicodedata.normalize("NFC", text).encode("utf-16-le")
    value = 0x811C9DC5
    for offset in range(0, len(encoded), 2):
        unit = int.from_bytes(encoded[offset : offset + 2], "little")
        value = ((value ^ unit) * 0x01000193) & 0xFFFFFFFF
    return f"{value:08x}.mp3"


def source_catalog() -> dict[str, str]:
    """Map every playable input's normalized text to its synthesis source."""
    sources: dict[str, str] = {}

    def add(text: str, spoken: str = ""):
        key = unicodedata.normalize("NFC", text)
        source = unicodedata.normalize("NFC", spoken or text)
        if key in sources and sources[key] != source:
            raise ValueError(f"Conflicting synthesis sources for {key}")
        sources[key] = source

    for letter in LETTERS:
        add(letter["name"])
        add(f"{letter['glyph']}َ")
        add(letter["word"])
    for lessons in LESSONS.values():
        for item in lessons:
            add(item["arabic"])
    for item in LESSONS["harakat"]:
        for consonant in ("b", "m"):
            syllable = item[consonant]
            spoken = f"أَ{syllable}" if item["id"] == "sukoon" else syllable
            add(syllable, spoken)
            add(spoken)
    for scene in DIALOGUES:
        add(scene[0])
    for sentence in SENTENCES:
        add(sentence["arabic"])
    for questions in GRAMMAR_QUESTIONS.values():
        for question in questions:
            add(question["arabic"])
    filenames: dict[str, str] = {}
    for text in sources:
        name = audio_filename(text)
        if name in filenames and filenames[name] != text:
            raise ValueError(f"FNV-1a collision: {name}")
        filenames[name] = text
    return dict(sorted(sources.items()))
