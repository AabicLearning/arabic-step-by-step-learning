import reflex as rx
import unicodedata
from typing import TypedDict
from arabic_step_by_step_learning.states.harakat_data import HARAKAT
from arabic_step_by_step_learning.states.numbers_data import NUMBER_ROWS
from arabic_step_by_step_learning.states.colors_data import COLOR_ROWS
from arabic_step_by_step_learning.states.vocabulary_data import VOCABULARY_ROWS, CATEGORIES
from arabic_step_by_step_learning.states.phrases_data import PHRASE_ROWS
from arabic_step_by_step_learning.states.grammar_data import GRAMMAR_ROWS, GRAMMAR_COPY


class LessonData(TypedDict):
    id: str
    arabic: str
    roman: str
    en: str
    fr: str
    numeral: str
    swatch: str
    mark: str
    b: str
    m: str
    b_roman: str
    m_roman: str
    tip_en: str
    tip_fr: str
    group: str


def lesson(
    item_id: str, arabic: str, roman: str, en: str, fr: str, **extra: str
) -> LessonData:
    return LessonData(
        id=item_id,
        arabic=arabic,
        roman=roman,
        en=en,
        fr=fr,
        numeral=extra.get("numeral", ""),
        swatch=extra.get("swatch", ""),
        mark=extra.get("mark", ""),
        b=extra.get("b", ""),
        m=extra.get("m", ""),
        b_roman=extra.get("b_roman", ""),
        m_roman=extra.get("m_roman", ""),
        tip_en=extra.get("tip_en", ""),
        tip_fr=extra.get("tip_fr", ""),
        group=extra.get("group", ""),
    )


LESSONS: dict[str, list[LessonData]] = {
    "grammar": [
        lesson(
            row["id"],
            row["arabic"],
            row["roman"],
            row["en"],
            row["fr"],
            group=row["group"],
            tip_en=row["tip_en"],
            tip_fr=row["tip_fr"],
        )
        for row in GRAMMAR_ROWS
    ],
    "harakat": [
        lesson(
            x["id"],
            x["arabic"],
            x["roman"],
            x["en"],
            x["fr"],
            mark=f"◌{x['mark']}",
            b=f"ب{x['mark']}",
            m=f"م{x['mark']}",
            b_roman=f"b{x['sound']}",
            m_roman=f"m{x['sound']}",
            tip_en=x["tip_en"],
            tip_fr=x["tip_fr"],
        )
        for x in HARAKAT
    ],
    "numbers": [
        lesson(f"number-{i}", ar, roman, en, fr, numeral=numeral)
        for i, (numeral, ar, roman, en, fr) in enumerate(NUMBER_ROWS)
    ],
    "colors": [
        lesson(name, ar, roman, en, fr, swatch=swatch)
        for name, ar, roman, en, fr, swatch in COLOR_ROWS
    ],
    "phrases": [
        lesson(f"phrase-{i}", ar, roman, en, fr)
        for i, (ar, roman, en, fr) in enumerate(PHRASE_ROWS)
    ],
}
for category, rows in VOCABULARY_ROWS.items():
    LESSONS[category] = [
        lesson(f"{category}-{i}", ar, roman, en, fr)
        for i, (ar, roman, en, fr) in enumerate(rows)
    ]

GAME_MODES: dict[str, list[str]] = {
    "grammar": ["pronoun_identify", "gender_agreement", "grammar_order"],
    "harakat": [
        "vowel_listen",
        "sound_match",
        "vowel_choice",
        "complete_syllable",
    ],
    "numbers": [
        "numeral_match",
        "number_listen",
        "count_objects",
        "numeral_word",
        "ordering",
    ],
    "colors": ["swatch_word", "word_swatch", "color_listen", "color_meaning"],
    "vocabulary": [
        "meaning_word",
        "word_meaning",
        "word_listen",
        "build_word",
        "missing_letter",
    ],
    "phrases": ["phrase_meaning", "dialogue", "sentence_build"],
}


def plain_letters(text: str) -> list[str]:
    return [
        c
        for c in unicodedata.normalize("NFC", text)
        if unicodedata.category(c).startswith("L")
    ]


EDUCATION_COPY: dict[str, tuple[str, str]] = {
    "activities_access": (
        "Explore any online activity now, without prerequisites. Only completed lessons and successful practice earn saved progress.",
        "Explorez toute activité en ligne dès maintenant, sans prérequis. Seules les leçons terminées et les réussites rapportent des progrès enregistrés.",
    ),
    "lesson_previous": ("Previous", "Précédent"),
    "lesson_next": ("Next", "Suivant"),
    "lesson_complete": ("Complete this lesson", "Terminer cette leçon"),
    "lesson_done": (
        "Lovely practice! This lesson is complete for this session only; progress is not saved yet.",
        "Belle pratique ! Cette leçon est terminée pour cette session uniquement ; les progrès ne sont pas encore sauvegardés.",
    ),
    "practice_now": ("Practise this module", "Pratiquer ce module"),
    "lesson_view": ("Lessons", "Leçons"),
    "exercise_view": ("Practice", "Pratique"),
    "category": ("Choose a category", "Choisissez une catégorie"),
    "check_answer": ("Check answer", "Vérifier la réponse"),
    "choose_answer": (
        "Choose an answer first.",
        "Choisissez d’abord une réponse.",
    ),
    "tiles_incomplete": (
        "Use every tile before checking.",
        "Utilisez toutes les tuiles avant de vérifier.",
    ),
    "session_score": ("Session score", "Score de la session"),
    "reveal_audio": ("Show text instead", "Afficher le texte"),
    "education_audio_note": (
        "Audio uses Google Translate MP3 online first, then automatically falls back to bundled eSpeak NG Arabic clips if loading fails. The fallback works offline when the app’s clips are available. No device Arabic voice is needed. Synthetic pronunciation is a learning guide, not a native-speaker recording. Romanization is approximate.",
        "L’audio utilise les MP3 Google Traduction en ligne en priorité, puis les extraits arabes eSpeak NG intégrés automatiquement si le chargement échoue. Ce relais fonctionne hors ligne si les extraits de l’application sont disponibles. Aucune voix arabe de l’appareil n’est nécessaire. La prononciation synthétique est un guide, pas un enregistrement natif. La translittération est approximative.",
    ),
    "undo_tile": ("Undo last tile", "Retirer la dernière tuile"),
    "clear_tiles": ("Clear tiles", "Effacer les tuiles"),
    "tile_help": (
        "Tap letters in reading order, starting at the right. Repeated letters have separate tiles. The joined preview uses normal Arabic shaping; vowel marks are omitted in this spelling exercise.",
        "Touchez les lettres dans l’ordre de lecture, en commençant à droite. Les lettres répétées ont des tuiles distinctes. L’aperçu lie les lettres normalement ; cet exercice d’orthographe omet les voyelles.",
    ),
    "ordering_help": (
        "Tap all numerals from smallest to largest. Numbers, including ١٠, are kept as whole tiles.",
        "Touchez tous les nombres du plus petit au plus grand. Les nombres, y compris ١٠, restent des tuiles entières.",
    ),
    "zero_objects": ("No objects: zero", "Aucun objet : zéro"),
    "color_note": (
        "These are masculine color names. Arabic adjectives change with the noun’s gender.",
        "Ces noms de couleurs sont masculins. Les adjectifs arabes s’accordent avec le genre du nom.",
    ),
    "phrase_note": (
        "Modern Standard Arabic. Some phrases specify the speaker or listener’s gender; the translation indicates it.",
        "Arabe standard moderne. Certaines expressions dépendent du genre du locuteur ou de l’interlocuteur ; la traduction le précise.",
    ),
    "vowel_listen": (
        "Listen & choose syllable",
        "Écoute et choisis la syllabe",
    ),
    "sound_match": ("Sound match", "Associe le son"),
    "vowel_choice": ("Choose the vowel mark", "Choisis la voyelle"),
    "complete_syllable": ("Complete the syllable", "Complète la syllabe"),
    "numeral_match": ("Numeral match", "Associe les nombres"),
    "number_listen": ("Listen & choose numeral", "Écoute et choisis le nombre"),
    "count_objects": ("Count objects", "Compte les objets"),
    "numeral_word": ("Numeral to word", "Du nombre au mot"),
    "ordering": ("Number ordering", "Ordre des nombres"),
    "swatch_word": ("Swatch to word", "De la couleur au mot"),
    "word_swatch": ("Word to swatch", "Du mot à la couleur"),
    "color_listen": ("Listen & choose color", "Écoute et choisis la couleur"),
    "color_meaning": ("Color meaning", "Sens des couleurs"),
    "meaning_word": ("Meaning to word", "Du sens au mot"),
    "word_meaning": ("Word to meaning", "Du mot au sens"),
    "word_listen": ("Listen & choose word", "Écoute et choisis le mot"),
    "build_word": ("Build a word", "Construis un mot"),
    "missing_letter": ("Missing letter", "Lettre manquante"),
    "phrase_meaning": ("Phrase meaning", "Sens des expressions"),
    "dialogue": ("Dialogue choices", "Choix de dialogue"),
    "sentence_build": ("Build a sentence", "Construis une phrase"),
    "sentence_build_help": (
        "Build the sentence for this meaning using every word tile. Your first word appears at the right; continue in Arabic reading order. Undo or clear to change your answer.",
        "Construisez la phrase correspondant à ce sens avec toutes les tuiles. Le premier mot apparaît à droite ; continuez dans l’ordre de lecture arabe. Retirez ou effacez pour modifier la réponse.",
    ),
    "sentence_empty": (
        "Sentence practice is available without completed lessons. Restart this activity to load a sentence.",
        "La construction de phrases est accessible sans leçon terminée. Relancez cette activité pour charger une phrase.",
    ),
    "vowel_listen_help": (
        "Listen, then choose the matching ب or م syllable.",
        "Écoutez, puis choisissez la syllabe en ب ou م.",
    ),
    "sound_match_help": (
        "Match the romanized sound to the Arabic syllable.",
        "Associez le son translittéré à la syllabe arabe.",
    ),
    "vowel_choice_help": (
        "Read the syllable and identify its vowel mark.",
        "Lisez la syllabe et identifiez sa voyelle.",
    ),
    "complete_syllable_help": (
        "Add the right mark to the consonant to make the requested sound.",
        "Ajoutez la bonne voyelle à la consonne pour obtenir le son demandé.",
    ),
    "numeral_match_help": (
        "Match the familiar digit to its Arabic numeral.",
        "Associez le chiffre familier au chiffre arabe.",
    ),
    "number_listen_help": (
        "Listen to the Arabic number, then choose its numeral.",
        "Écoutez le nombre arabe, puis choisissez son chiffre.",
    ),
    "count_objects_help": (
        "Count the leaves and choose the numeral. An empty group is zero.",
        "Comptez les feuilles et choisissez le chiffre. Un groupe vide vaut zéro.",
    ),
    "numeral_word_help": (
        "Choose the Arabic word for this numeral.",
        "Choisissez le mot arabe pour ce nombre.",
    ),
    "ordering_help_short": (
        "Put the numbers in increasing order.",
        "Placez les nombres dans l’ordre croissant.",
    ),
    "swatch_word_help": (
        "Choose the Arabic word for this color.",
        "Choisissez le mot arabe pour cette couleur.",
    ),
    "word_swatch_help": (
        "Choose the swatch matching this Arabic word.",
        "Choisissez la couleur correspondant à ce mot arabe.",
    ),
    "color_listen_help": (
        "Listen, then choose the matching swatch.",
        "Écoutez, puis choisissez la couleur.",
    ),
    "color_meaning_help": (
        "Choose the Arabic color word for this meaning.",
        "Choisissez le mot arabe pour cette couleur.",
    ),
    "meaning_word_help": (
        "Choose the Arabic word with this meaning.",
        "Choisissez le mot arabe ayant ce sens.",
    ),
    "word_meaning_help": (
        "Read the Arabic word and choose its meaning.",
        "Lisez le mot arabe et choisissez son sens.",
    ),
    "word_listen_help": (
        "Listen, then choose the Arabic word you heard.",
        "Écoutez, puis choisissez le mot arabe entendu.",
    ),
    "build_word_help": (
        "Build the word for this meaning using every letter tile.",
        "Construisez le mot correspondant à ce sens avec toutes les lettres.",
    ),
    "missing_letter_help": (
        "Complete the word by choosing the missing letter.",
        "Complétez le mot en choisissant la lettre manquante.",
    ),
    "phrase_meaning_help": (
        "Read the phrase and choose its translation.",
        "Lisez l’expression et choisissez sa traduction.",
    ),
    "dialogue_help": (
        "Read the situation and choose the intended reply.",
        "Lisez la situation et choisissez la réponse attendue.",
    ),
}
EDUCATION_COPY.update(
    {f"category_{key}": value for key, value in CATEGORIES.items()}
)
EDUCATION_COPY.update(GRAMMAR_COPY)
