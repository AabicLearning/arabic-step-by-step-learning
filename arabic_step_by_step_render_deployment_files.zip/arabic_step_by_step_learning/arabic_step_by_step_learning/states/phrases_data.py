import reflex as rx
import unicodedata
from typing import TypedDict

PHRASE_ROWS: list[tuple[str, str, str, str]] = [
    (
        "السَّلَامُ عَلَيْكُمْ",
        "as-salāmu ʿalaykum",
        "Peace be upon you / hello",
        "Que la paix soit sur vous / bonjour",
    ),
    (
        "وَعَلَيْكُمُ السَّلَام",
        "wa ʿalaykumu s-salām",
        "And peace be upon you",
        "Et que la paix soit sur vous",
    ),
    ("مَرْحَبًا", "marḥaban", "Hello", "Bonjour"),
    ("شُكْرًا", "shukran", "Thank you", "Merci"),
    ("عَفْوًا", "ʿafwan", "You are welcome", "De rien"),
    ("نَعَمْ", "naʿam", "Yes", "Oui"),
    ("لَا", "lā", "No", "Non"),
    (
        "مِنْ فَضْلِكَ",
        "min faḍlika",
        "Please (to a man)",
        "S’il te plaît (à un homme)",
    ),
    (
        "مَا اسْمُكَ؟",
        "mā ismuka?",
        "What is your name? (to a man)",
        "Comment t’appelles-tu ? (à un homme)",
    ),
    ("اسْمِي ...", "ismī ...", "My name is ...", "Je m’appelle ..."),
    (
        "كَيْفَ حَالُكَ؟",
        "kayfa ḥāluka?",
        "How are you? (to a man)",
        "Comment vas-tu ? (à un homme)",
    ),
    ("أَنَا بِخَيْر", "anā bi-khayr", "I am fine", "Je vais bien"),
]


class SentenceData(TypedDict):
    id: str
    arabic: str
    en: str
    fr: str
    lessons: list[str]


SENTENCES: list[SentenceData] = [
    {
        "id": "peace",
        "arabic": "السَّلَامُ عَلَيْكُمْ",
        "en": "Peace be upon you / hello",
        "fr": "Que la paix soit sur vous / bonjour",
        "lessons": ["phrase-0"],
    },
    {
        "id": "name",
        "arabic": "مَا اسْمُكَ",
        "en": "What is your name? (to a man)",
        "fr": "Comment t’appelles-tu ? (à un homme)",
        "lessons": ["phrase-8"],
    },
    {
        "id": "how",
        "arabic": "كَيْفَ حَالُكَ",
        "en": "How are you? (to a man)",
        "fr": "Comment vas-tu ? (à un homme)",
        "lessons": ["phrase-10"],
    },
    {
        "id": "fine",
        "arabic": "أَنَا بِخَيْر",
        "en": "I am fine",
        "fr": "Je vais bien",
        "lessons": ["phrase-11"],
    },
    {
        "id": "yes-fine",
        "arabic": "نَعَمْ أَنَا بِخَيْر",
        "en": "Yes, I am fine",
        "fr": "Oui, je vais bien",
        "lessons": ["phrase-5", "phrase-11"],
    },
    {
        "id": "hello-name",
        "arabic": "مَرْحَبًا مَا اسْمُكَ",
        "en": "Hello, what is your name? (to a man)",
        "fr": "Bonjour, comment t’appelles-tu ? (à un homme)",
        "lessons": ["phrase-2", "phrase-8"],
    },
]


def sentence_words(text: str) -> list[str]:
    return unicodedata.normalize("NFC", text).replace("؟", "").split()


def eligible_sentences(completed: list[str]) -> list[SentenceData]:
    return [
        s
        for s in SENTENCES
        if all(f"phrases:{i}" in completed for i in s["lessons"])
    ]


# Scene i expects PHRASE_ROWS[i]; the state uses this same index for choices.
DIALOGUES: list[tuple[str, str, str, int]] = [
    (
        "أَهْلًا",
        "You arrive among friends. Begin with the peace greeting.",
        "Vous arrivez parmi des amis. Commencez par la salutation de paix.",
        0,
    ),
    (
        "السَّلَامُ عَلَيْكُمْ",
        "Someone says ‘Peace be upon you’. Reply ‘And peace be upon you’.",
        "On vous dit « Que la paix soit sur vous ». Répondez « Et que la paix soit sur vous ».",
        1,
    ),
    (
        "مَرْحَبًا",
        "A friend says hello. Reply with the same simple hello.",
        "Un ami vous dit bonjour. Répondez avec le même bonjour simple.",
        2,
    ),
    (
        "هَذَا لَكَ",
        "Someone says ‘This is for you’ and gives you a gift. Thank them.",
        "Quelqu’un dit « C’est pour toi » et vous offre un cadeau. Remerciez-le.",
        3,
    ),
    (
        "شُكْرًا",
        "Someone thanks you. Say ‘You are welcome’.",
        "On vous remercie. Répondez « De rien ».",
        4,
    ),
    (
        "هَلْ تُرِيدُ مَاءً؟",
        "Someone asks ‘Do you want water?’ You do. Say yes.",
        "On vous demande « Veux-tu de l’eau ? ». Vous en voulez. Dites oui.",
        5,
    ),
    (
        "هَلْ تُرِيدُ مَاءً؟",
        "Someone asks ‘Do you want water?’ You do not. Say no.",
        "On vous demande « Veux-tu de l’eau ? ». Vous n’en voulez pas. Dites non.",
        6,
    ),
    (
        "مَاذَا تُرِيدُ؟",
        "A man asks ‘What do you want?’ Add ‘please’ to make your request polite.",
        "Un homme demande « Que veux-tu ? ». Ajoutez « s’il te plaît » pour rendre votre demande polie.",
        7,
    ),
    (
        "مَرْحَبًا",
        "You meet a man for the first time. Ask his name.",
        "Vous rencontrez un homme pour la première fois. Demandez-lui son nom.",
        8,
    ),
    (
        "مَا اسْمُكَ؟",
        "Someone asks your name. Choose ‘My name is ...’, then fill in your name.",
        "On vous demande votre nom. Choisissez « Je m’appelle ... », puis complétez avec votre nom.",
        9,
    ),
    (
        "مَرْحَبًا",
        "You greet a male friend. Ask how he is.",
        "Vous saluez un ami. Demandez-lui comment il va.",
        10,
    ),
    (
        "كَيْفَ حَالُكَ؟",
        "Your friend asks how you are. Say ‘I am fine’.",
        "Votre ami demande comment vous allez. Répondez « Je vais bien ».",
        11,
    ),
]
