import reflex as rx
from typing import Any, TypedDict
import json
import logging
from datetime import date, datetime, timedelta, timezone
import random
from uuid import uuid4

from arabic_step_by_step_learning.states.translations import COPY, MODULES
from arabic_step_by_step_learning.states.letter_data import LETTER_COPY
from arabic_step_by_step_learning.states.education_data import EDUCATION_COPY, LESSONS
from arabic_step_by_step_learning.states.letter_data import LETTERS, LetterData
from arabic_step_by_step_learning.states.progress_data import PROGRESS_COPY, lesson_ids
from arabic_step_by_step_learning.states.review_schedule import (
    ReviewEntry,
    ReviewTarget,
    learned_targets,
    local_date,
    read_schedule,
    next_entry,
)


class ModuleData(TypedDict):
    id: str
    title: str
    description: str
    arabic: str
    prerequisite: str
    number: str
    available: bool
    done: int
    total: int
    percent: int


class PlacementData(TypedDict):
    answers: list[str]
    result: str
    next_index: int
    skipped: bool


SUPPORT_INITIAL_DELAY = timedelta(days=15)
SUPPORT_REPEAT_DELAY = timedelta(days=30)


class LearningState(rx.State):
    language: str = rx.LocalStorage("", name="arabic_steps_language", sync=True)
    nickname: str = rx.LocalStorage("", name="arabic_steps_nickname", sync=True)
    setup_done: str = rx.LocalStorage("", name="arabic_steps_setup", sync=True)
    stage: str = "language"
    active_tab: str = "home"
    letters_open: bool = False
    education_open: bool = False
    game_module: str = "letters"
    placement_json: str = rx.LocalStorage(
        "{}", name="arabic_steps_placement", sync=True
    )
    placement_answers: list[str] = ["", "", ""]
    question_index: int = 0
    selected_answer: str = ""
    feedback_key: str = ""
    error_key: str = ""
    notice_key: str = ""
    modal: str = ""
    support_popup_open: bool = False
    chosen_module: str = "letters"
    familiar: bool = False
    progress_json: str = rx.LocalStorage(
        "{}", name="arabic_steps_progress", sync=True
    )
    sound: str = rx.LocalStorage("on", name="arabic_steps_sound", sync=True)
    browser_date: str = ""
    daily_answer: str = ""
    daily_feedback: str = ""
    daily_choices: list[str] = []
    daily_prompt: str = ""
    daily_audio: str = ""
    daily_correct_answer: str = ""
    review_json: str = rx.LocalStorage(
        "{}", name="arabic_steps_review", sync=True
    )
    review_pending: bool = False
    review_queue: list[str] = []
    review_total: int = 0
    review_completed: int = 0
    review_item: str = ""
    review_token: str = ""
    review_prompt_en: str = ""
    review_prompt_fr: str = ""
    review_correct_answer: str = ""
    review_choices: list[str] = []
    review_answer: str = ""
    review_feedback: str = ""
    review_next_date: str = ""

    @rx.var
    def review_targets(self) -> list[ReviewTarget]:
        return learned_targets(self.progress_data)

    @rx.var
    def review_schedule(self) -> dict[str, ReviewEntry]:
        return read_schedule(self.review_json)

    @rx.var
    def review_date_ready(self) -> bool:
        return local_date(self.browser_date) is not None

    @rx.var
    def review_due_ids(self) -> list[str]:
        today = local_date(self.browser_date)
        if today is None:
            return []
        schedule = self.review_schedule
        return [
            item["id"]
            for item in self.review_targets
            if item["id"] not in schedule
            or schedule[item["id"]]["due"] <= today.isoformat()
        ]

    @rx.var
    def review_due_count(self) -> int:
        return len(self.review_due_ids)

    @rx.var
    def review_prompt(self) -> str:
        return (
            self.review_prompt_fr
            if self.language == "fr"
            else self.review_prompt_en
        )

    def _clear_review(self):
        self.review_pending = False
        self.review_queue = []
        self.review_total = 0
        self.review_completed = 0
        self.review_item = ""
        self.review_token = ""
        self.review_prompt_en = ""
        self.review_prompt_fr = ""
        self.review_correct_answer = ""
        self.review_choices = []
        self.review_answer = ""
        self.review_feedback = ""
        self.review_next_date = ""

    def _review_question(self):
        targets = {item["id"]: item for item in self.review_targets}
        due = set(self.review_due_ids)
        self.review_queue = [
            key for key in self.review_queue if key in targets and key in due
        ]
        self.review_item = ""
        self.review_answer = ""
        self.review_feedback = ""
        self.review_next_date = ""
        self.review_choices = []
        self.review_token = str(uuid4())
        if not self.review_queue:
            return
        target = targets[self.review_queue[0]]
        self.review_item = target["id"]
        self.review_prompt_en = target["en"]
        self.review_prompt_fr = target["fr"]
        self.review_correct_answer = target["arabic"]
        pool = (
            [letter["isolated"] for letter in LETTERS]
            if target["category"] == "letters"
            else [item["arabic"] for item in LESSONS[target["category"]]]
        )
        distractors = list(
            dict.fromkeys(
                answer for answer in pool if answer != target["arabic"]
            )
        )
        self.review_choices = [
            target["arabic"],
            *random.sample(distractors, min(3, len(distractors))),
        ]
        random.shuffle(self.review_choices)

    @rx.event
    def open_review(self):
        self._clear_review()
        self.modal = "review"
        self.review_pending = True
        return rx.call_script(
            "(() => { const d = new Date(); return [d.getFullYear(), String(d.getMonth()+1).padStart(2,'0'), String(d.getDate()).padStart(2,'0')].join('-'); })()",
            callback=LearningState.set_browser_date,
        )

    @rx.event
    def answer_review(self, token: str, answer: str):
        today = local_date(self.browser_date)
        if (
            self.modal != "review"
            or self.review_pending
            or today is None
            or token != self.review_token
            or self.review_answer
            or not self.review_item
            or answer not in self.review_choices
            or self.review_item not in self.review_due_ids
        ):
            return
        correct = answer == self.review_correct_answer
        schedule = self.review_schedule
        entry = next_entry(today, schedule.get(self.review_item), correct)
        schedule[self.review_item] = entry
        self.review_json = json.dumps(
            {"version": 1, "items": schedule}, ensure_ascii=False
        )
        self.review_answer = answer
        self.review_feedback = (
            "review_correct" if correct else "review_incorrect"
        )
        self.review_next_date = entry["due"]
        self.review_completed += 1

    @rx.event
    def next_review(self, token: str):
        if (
            self.modal != "review"
            or token != self.review_token
            or not self.review_answer
        ):
            return
        self.review_queue = self.review_queue[1:]
        self._review_question()

    @rx.var
    def progress_data(self) -> dict[str, list[str]]:
        try:
            raw = json.loads(self.progress_json)
            if not isinstance(raw, dict):
                return {
                    key: []
                    for key in (
                        "lessons",
                        "exercises",
                        "answers",
                        "modules",
                        "words",
                        "daily",
                        "days",
                    )
                }
            return {
                key: list(
                    dict.fromkeys(
                        x for x in raw.get(key, []) if isinstance(x, str)
                    )
                )
                if isinstance(raw.get(key, []), list)
                else []
                for key in (
                    "lessons",
                    "exercises",
                    "answers",
                    "modules",
                    "words",
                    "daily",
                    "days",
                )
            }
        except (ValueError, TypeError) as e:
            logging.exception(f"Error: {e}")
            return {
                key: []
                for key in (
                    "lessons",
                    "exercises",
                    "answers",
                    "modules",
                    "words",
                    "daily",
                    "days",
                )
            }

    def _save_progress(self, data: dict[str, list[str]]):
        self.progress_json = json.dumps(data, ensure_ascii=False)

    def _count(self, module: str) -> int:
        completed = set(self.progress_data["lessons"])
        return sum(
            f"{module}:{item}" in completed for item in lesson_ids(module)
        )

    def _available(self, module: str) -> bool:
        return module in {row[0] for row in MODULES}

    def _record(
        self,
        module: str,
        item: str,
        lesson: bool = False,
        exercise: str = "",
        word: str = "",
    ):
        if not self._available(module):
            return
        data = self.progress_data
        if lesson and item in lesson_ids(module):
            key = f"{module}:{item}"
            if key not in data["lessons"]:
                data["lessons"].append(key)
        if exercise:
            if exercise not in data["exercises"]:
                data["exercises"].append(exercise)
            data["answers"].append(str(uuid4()))
        if word and word not in data["words"]:
            data["words"].append(word)
        for module_id in (row[0] for row in MODULES):
            ids = lesson_ids(module_id)
            if (
                ids
                and all(f"{module_id}:{i}" in data["lessons"] for i in ids)
                and module_id not in data["modules"]
            ):
                data["modules"].append(module_id)
        self._save_progress(data)

    @rx.var
    def stars(self) -> int:
        data = self.progress_data
        return (
            len(data["answers"])
            + 5 * len(data["lessons"])
            + 20 * len(data["modules"])
        )

    @rx.var
    def completed_total(self) -> int:
        return sum(self._count(row[0]) for row in MODULES)

    @rx.var
    def overall_percent(self) -> int:
        total = sum(len(lesson_ids(row[0])) for row in MODULES)
        return round(100 * self.completed_total / total) if total else 0

    @rx.var
    def level_name(self) -> str:
        return self.copy[
            "confident"
            if self.overall_percent >= 60
            else "growing"
            if self.completed_total >= 10
            else "beginner"
        ]

    @rx.var
    def streak(self) -> int:
        days = set(self.progress_data["days"])
        try:
            today = (
                date.fromisoformat(self.browser_date)
                if self.browser_date
                else date.today()
            )
            cursor = (
                today
                if today.isoformat() in days
                else today - timedelta(days=1)
            )
            count = 0
            while cursor.isoformat() in days:
                count += 1
                cursor -= timedelta(days=1)
            return count
        except ValueError as e:
            logging.exception(f"Error: {e}")
            return 0

    @rx.var
    def badges(self) -> list[dict[str, str | bool]]:
        checks = [
            ("first", self.completed_total >= 1),
            ("letters", self._count("letters") == 28),
            ("writing", self._count("writing") >= 3),
            ("numbers", self._count("numbers") >= 3),
            ("colors", self._count("colors") == 10),
            ("words", len(self.progress_data["words"]) >= 10),
        ]
        return [
            {
                "title": self.copy[f"badge_{key}"],
                "hint": self.copy[f"badge_{key}_hint"],
                "earned": earned,
            }
            for key, earned in checks
        ]

    @rx.var
    def daily_ready(self) -> bool:
        return True

    @rx.var
    def daily_index(self) -> int:
        return sum(
            f"{self.browser_date}:{i}" in self.progress_data["daily"]
            for i in range(5)
        )

    @rx.var
    def daily_done(self) -> bool:
        return self.browser_date in self.progress_data["days"]

    @rx.event
    def set_browser_date(self, value: str):
        try:
            date.fromisoformat(value)
        except ValueError as e:
            logging.exception(f"Error: {e}")
            return
        self.browser_date = value
        if self.modal == "review" and self.review_pending:
            self.review_pending = False
            self.review_queue = self.review_due_ids
            self.review_total = len(self.review_queue)
            self._review_question()
        self.daily_answer = ""
        self.daily_feedback = ""
        self._daily_question()

    def _daily_question(self):
        if self.daily_index >= 5:
            return
        rng = random.Random(f"{self.browser_date}:{self.daily_index}")
        index = self.daily_index
        if index < 2:
            ids = rng.sample(range(28), 4)
            target = LETTERS[ids[0]]
            self.daily_prompt = (
                f"{self.copy['daily_letter']} {target['romanization']}"
            )
            self.daily_correct_answer = target["isolated"]
            self.daily_audio = target["name"]
            self.daily_choices = [LETTERS[i]["isolated"] for i in ids]
        else:
            module = {2: "harakat", 3: "family", 4: "numbers"}[index]
            pool = LESSONS[module]
            ids = rng.sample(range(len(pool)), 4)
            target = pool[ids[0]]
            if index == 2:
                self.daily_prompt = (
                    f"{self.copy['daily_sound']} {target['b_roman']}"
                )
                self.daily_choices = [pool[i]["b"] for i in ids]
                self.daily_correct_answer = target["b"]
                self.daily_audio = (
                    "أَبْ" if target["id"] == "sukoon" else target["b"]
                )
            elif index == 3:
                self.daily_prompt = f"{self.copy['daily_word']} {target['fr' if self.language == 'fr' else 'en']}"
                self.daily_choices = [pool[i]["arabic"] for i in ids]
                self.daily_correct_answer = target["arabic"]
                self.daily_audio = target["arabic"]
            else:
                self.daily_prompt = f"{self.copy['daily_number']} {ids[0]}"
                self.daily_choices = [pool[i]["numeral"] for i in ids]
                self.daily_correct_answer = target["numeral"]
                self.daily_audio = target["arabic"]
        rng.shuffle(self.daily_choices)

    @rx.event
    def answer_daily(self, answer: str):
        if (
            not self.daily_ready
            or not self.browser_date
            or self.daily_done
            or self.daily_answer
            or answer not in self.daily_choices
        ):
            return
        if answer != self.daily_correct_answer:
            self.daily_feedback = "daily_retry"
            return
        index = self.daily_index
        self.daily_answer = answer
        self.daily_feedback = "daily_correct"
        data = self.progress_data
        key = f"{self.browser_date}:{index}"
        if key not in data["daily"]:
            data["daily"].append(key)
            data["exercises"].append(f"daily:{key}")
            data["answers"].append(f"daily:{key}")
        if index == 3 and self.daily_audio not in data["words"]:
            data["words"].append(self.daily_audio)
        if (
            all(f"{self.browser_date}:{i}" in data["daily"] for i in range(5))
            and self.browser_date not in data["days"]
        ):
            data["days"].append(self.browser_date)
        self._save_progress(data)

    @rx.event
    def next_daily(self):
        if self.daily_answer:
            self.daily_answer = ""
            self.daily_feedback = ""
            self._daily_question()

    @rx.event
    def toggle_sound(self):
        self.sound = "off" if self.sound == "on" else "on"
        if self.sound == "off":
            return rx.call_script("window.arabicLetterTools?.stopAudio()")

    @rx.event
    def request_reset(self):
        self.modal = "reset"

    @rx.event
    async def confirm_reset(self):
        if self.modal != "reset":
            return
        self.progress_json = "{}"
        self.review_json = "{}"
        self._clear_review()
        self.modal = ""
        self.daily_answer = ""
        self.daily_feedback = ""
        self.letters_open = False
        self.education_open = False
        self.game_module = "letters"
        self.notice_key = "reset_done"
        from arabic_step_by_step_learning.states.education_state import EducationState
        from arabic_step_by_step_learning.states.letters_state import LettersState

        education = await self.get_state(EducationState)
        letters = await self.get_state(LettersState)
        education.lesson_feedback = False
        letters.quiz_answer = ""
        letters.trace_claimed = ""

    @rx.var
    def copy(self) -> dict[str, str]:
        index = 1 if self.language == "fr" else 0
        return {
            key: pair[index]
            for key, pair in {
                **COPY,
                **LETTER_COPY,
                **EDUCATION_COPY,
                **PROGRESS_COPY,
            }.items()
        }

    @rx.var
    def modules(self) -> list[ModuleData]:
        text = self.copy
        return [
            ModuleData(
                id=item[0],
                title=text[item[1]],
                description=text[item[2]],
                arabic=item[3],
                prerequisite=text[item[4]] if item[4] else "",
                number=f"{index + 1:02d}",
                available=self._available(item[0]),
                done=self._count(item[0]),
                total=len(lesson_ids(item[0])),
                percent=round(
                    100 * self._count(item[0]) / len(lesson_ids(item[0]))
                ),
            )
            for index, item in enumerate(MODULES)
        ]

    @rx.var
    def game_modules(self) -> list[ModuleData]:
        return [
            module
            for module in self.modules
            if module["id"] not in ("writing", "games")
        ]

    @rx.var
    def placement_data(self) -> PlacementData:
        default = PlacementData(
            answers=[], result="complete", next_index=0, skipped=True
        )
        try:
            raw = json.loads(self.placement_json)
            if not isinstance(raw, dict):
                return default
            answers = raw.get("answers", [])
            result = raw.get("result", "")
            index = raw.get("next_index", 0)
            skipped = raw.get("skipped", False)
            if (
                not isinstance(answers, list)
                or any(
                    a not in ("correct", "incorrect", "unknown")
                    for a in answers
                )
                or result not in ("complete", "familiar")
                or type(index) is not int
                or not 0 <= index < len(LETTERS)
                or type(skipped) is not bool
                or (not skipped and len(answers) != 3)
                or (skipped and (answers or result != "complete" or index != 0))
            ):
                return default
            return PlacementData(
                answers=answers,
                result=result,
                next_index=index,
                skipped=skipped,
            )
        except (ValueError, TypeError) as e:
            logging.exception(f"Error: {e}")
            return default

    @rx.var
    def placement_recognized(self) -> int:
        return self.placement_data["answers"].count("correct")

    @rx.var
    def placement_label(self) -> str:
        return self.copy[
            "familiar_beginner"
            if self.placement_data["result"] == "familiar"
            else "beginner"
        ]

    @rx.var
    def placement_description(self) -> str:
        data = self.placement_data
        if data["skipped"]:
            return self.copy["placement_skipped"]
        key = (
            "placement_familiar"
            if data["result"] == "familiar"
            else "placement_complete"
        )
        return self.copy[key].format(count=self.placement_recognized)

    @rx.var
    def has_letter_progress(self) -> bool:
        return self._count("letters") > 0

    @rx.var
    def letters_all_complete(self) -> bool:
        completed = set(self.progress_data["lessons"])
        return all(f"letters:{letter['id']}" in completed for letter in LETTERS)

    @rx.var
    def recommended_letter(self) -> LetterData:
        start = self.placement_data["next_index"]
        completed = set(self.progress_data["lessons"])
        for offset in range(len(LETTERS)):
            letter = LETTERS[(start + offset) % len(LETTERS)]
            if f"letters:{letter['id']}" not in completed:
                return letter
        return LETTERS[start]

    def _reset_placement(self):
        self.placement_answers = ["", "", ""]
        self.placement_json = "{}"
        self.question_index = 0
        self.selected_answer = ""
        self.feedback_key = ""

    def _save_placement(self, skipped: bool = False):
        answers = [] if skipped else list(self.placement_answers)
        recognized = answers.count("correct")
        test_indices = (0, 1, 23)
        missed = next(
            (
                test_indices[i]
                for i, answer in enumerate(answers)
                if answer != "correct"
            ),
            2,
        )
        self.placement_json = json.dumps(
            PlacementData(
                answers=answers,
                result="familiar" if recognized >= 2 else "complete",
                next_index=0 if skipped else missed,
                skipped=skipped,
            )
        )

    @rx.var
    def current_question(self) -> dict[str, str]:
        questions = [
            {"name": "Alif", "answer": "ا", "a": "ب", "b": "ا", "c": "م"},
            {"name": "Bā’", "answer": "ب", "a": "ت", "b": "ن", "c": "ب"},
            {"name": "Mīm", "answer": "م", "a": "م", "b": "ل", "c": "س"},
        ]
        return questions[min(max(self.question_index, 0), 2)]

    @rx.var
    def selected_module(self) -> ModuleData:
        return next(
            (item for item in self.modules if item["id"] == self.chosen_module),
            self.modules[0],
        )

    def _support_timestamp(self, value: object) -> datetime | None:
        if not isinstance(value, str) or not value:
            return None
        try:
            parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
            if parsed.tzinfo is None:
                return None
            return parsed.astimezone(timezone.utc)
        except ValueError as e:
            logging.exception(f"Error: {e}")
            return None

    def _support_check_script(self):
        return rx.call_script(
            "(() => { try { const key = 'install_date'; const now = new Date(); let installed = localStorage.getItem(key); if (installed === null) { installed = now.toISOString(); localStorage.setItem(key, installed); } return JSON.stringify({install_date: installed, last_support_popup: localStorage.getItem('last_support_popup'), now: now.toISOString()}); } catch (e) { return JSON.stringify({}); } })()",
            callback=LearningState.evaluate_support_popup,
        )

    @rx.event
    def evaluate_support_popup(self, raw_values: str):
        if (
            self.setup_done != "yes"
            or self.language not in ("en", "fr")
            or self.modal != ""
            or self.support_popup_open
        ):
            return
        try:
            values = json.loads(raw_values)
        except (ValueError, TypeError) as e:
            logging.exception(f"Error: {e}")
            return
        if not isinstance(values, dict):
            return
        now = self._support_timestamp(values.get("now"))
        installed = self._support_timestamp(values.get("install_date"))
        if now is None or installed is None or installed > now:
            return
        if now - installed < SUPPORT_INITIAL_DELAY:
            return
        last_raw = values.get("last_support_popup")
        if last_raw is not None:
            last_shown = self._support_timestamp(last_raw)
            if last_shown is None or last_shown > now:
                return
            if now - last_shown < SUPPORT_REPEAT_DELAY:
                return
        self.support_popup_open = True

    @rx.event
    def dismiss_support_popup(self):
        if not self.support_popup_open:
            return
        self.support_popup_open = False
        return rx.call_script(
            "localStorage.setItem('last_support_popup', new Date().toISOString())"
        )

    @rx.event
    def load(self):
        if self.setup_done != "yes":
            self.stage = (
                "welcome" if self.language in ("en", "fr") else "language"
            )
        try:
            raw = json.loads(self.progress_json)
            if not isinstance(raw, dict):
                self.notice_key = "storage_error"
        except (ValueError, TypeError) as e:
            logging.exception(f"Error: {e}")
            self.notice_key = "storage_error"
        return [
            rx.call_script(
                "(() => { const d = new Date(); return [d.getFullYear(), String(d.getMonth()+1).padStart(2,'0'), String(d.getDate()).padStart(2,'0')].join('-'); })()",
                callback=LearningState.set_browser_date,
            ),
            self._support_check_script(),
        ]

    @rx.event
    def choose_language(self, language: str):
        if language in ("en", "fr"):
            self.language = language
            self.notice_key = ""
            self._daily_question()
            if self.setup_done != "yes":
                self.stage = "welcome"
            else:
                return self._support_check_script()

    @rx.event
    def choose_start(self, familiar: bool):
        self.familiar = familiar
        self.error_key = ""
        self.stage = "nickname"

    @rx.event
    def save_nickname(self, form_data: dict[str, Any]):
        name = str(form_data.get("nickname", "")).strip()
        if not name or len(name) > 24:
            self.error_key = "nickname_error"
            return
        self.nickname = name
        self.error_key = ""
        if self.setup_done == "yes":
            self.notice_key = "saved"
        else:
            self._reset_placement()
            self.stage = "check"

    @rx.event
    def go_back(self):
        stages = {
            "welcome": "language",
            "nickname": "welcome",
            "check": "nickname",
            "result": "check",
        }
        if self.stage == "result":
            self._reset_placement()
        self.stage = stages.get(self.stage, "language")
        self.error_key = ""

    @rx.event
    def answer_question(self, answer: str):
        if (
            self.stage != "check"
            or self.selected_answer
            or answer
            not in (
                self.current_question["a"],
                self.current_question["b"],
                self.current_question["c"],
                "unknown",
            )
        ):
            return
        self.selected_answer = answer
        if answer == "unknown":
            self.feedback_key = "unknown_feedback"
        elif answer == self.current_question["answer"]:
            self.feedback_key = "correct"
        else:
            self.feedback_key = "incorrect"
        self.placement_answers[self.question_index] = (
            "correct"
            if self.feedback_key == "correct"
            else "unknown"
            if answer == "unknown"
            else "incorrect"
        )

    @rx.event
    def next_question(self):
        if self.stage != "check" or not self.selected_answer:
            return
        if self.question_index >= 2:
            self._save_placement()
            self.stage = "result"
        else:
            self.question_index += 1
            self.selected_answer = ""
            self.feedback_key = ""

    @rx.event
    def skip_check(self):
        if self.stage != "check":
            return
        self._reset_placement()
        self._save_placement(skipped=True)
        self.stage = "result"

    @rx.event
    def finish_setup(self):
        if self.nickname and self.language in ("en", "fr"):
            self.setup_done = "yes"
            self.active_tab = "home"
            self.modal = ""
            return self._support_check_script()

    @rx.event
    def navigate(self, tab: str):
        if tab in ("home", "learn", "games", "progress", "settings"):
            self.active_tab = tab
            self.letters_open = False
            self.education_open = False
            self.modal = ""
            self.error_key = ""
            self.notice_key = ""

    @rx.event
    async def open_module(self, module_id: str):
        if module_id in [item[0] for item in MODULES]:
            self.chosen_module = module_id
            if module_id == "games":
                self.active_tab = "games"
                self.game_module = "letters"
                self.modal = ""
                return
            self.active_tab = "learn"
            self.letters_open = module_id in ("letters", "writing")
            self.education_open = module_id not in ("letters", "writing")
            self.modal = ""
            if self.education_open:
                from arabic_step_by_step_learning.states.education_state import EducationState

                education = await self.get_state(EducationState)
                education._configure(module_id)

    @rx.event
    async def open_recommended_letter(self):
        from arabic_step_by_step_learning.states.letters_state import LettersState

        letters = await self.get_state(LettersState)
        LettersState.select_letter.fn(letters, self.recommended_letter["id"])
        await self.open_module("letters")
        self.error_key = ""
        self.notice_key = ""

    @rx.event
    async def choose_game_module(self, module_id: str):
        if module_id in (
            "letters",
            "harakat",
            "grammar",
            "numbers",
            "colors",
            "vocabulary",
            "phrases",
        ):
            self.modal = ""
            self.game_module = module_id
            self.active_tab = "games"
            if module_id != "letters":
                from arabic_step_by_step_learning.states.education_state import EducationState

                education = await self.get_state(EducationState)
                education._configure(module_id, practice=True)

    @rx.event
    async def practise_module(self):
        from arabic_step_by_step_learning.states.education_state import EducationState

        education = await self.get_state(EducationState)
        if self._available(self.chosen_module):
            await education.set_view("practice")

    @rx.event
    def back_to_path(self):
        self.education_open = False
        self.letters_open = False
        self.active_tab = "learn"

    @rx.event
    def open_daily(self):
        self.modal = "daily"
        self.daily_answer = ""
        self.daily_feedback = ""
        return rx.call_script(
            "(() => { const d = new Date(); return [d.getFullYear(), String(d.getMonth()+1).padStart(2,'0'), String(d.getDate()).padStart(2,'0')].join('-'); })()",
            callback=LearningState.set_browser_date,
        )

    @rx.event
    def close_modal(self):
        if self.modal == "review":
            self._clear_review()
        self.modal = ""
