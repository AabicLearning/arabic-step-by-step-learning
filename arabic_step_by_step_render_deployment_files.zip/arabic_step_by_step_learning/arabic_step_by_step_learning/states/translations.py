import reflex as rx


COPY: dict[str, tuple[str, str]] = {
    "brand": ("Arabic Step by Step", "Arabic Step by Step"),
    "tagline": (
        "Learn Arabic. Read it. Write it. Speak it.",
        "Learn Arabic. Read it. Write it. Speak it.",
    ),
    "home": ("Home", "Accueil"),
    "learn": ("Learn", "Apprendre"),
    "games": ("Games", "Jeux"),
    "progress": ("Progress", "Progrès"),
    "settings": ("Settings", "Réglages"),
    "language_title": (
        "Every journey begins with a hello.",
        "Chaque voyage commence par un bonjour.",
    ),
    "language_desc": (
        "Discover Arabic at your own pace. First, choose the language you feel at home in.",
        "Découvrez l’arabe à votre rythme. Choisissez d’abord la langue dans laquelle vous vous sentez à l’aise.",
    ),
    "language_label": ("YOUR INTERFACE LANGUAGE", "LANGUE DE L’INTERFACE"),
    "change_later": (
        "You can change this anytime in Settings.",
        "Vous pourrez la modifier à tout moment dans les réglages.",
    ),
    "local_note": (
        "No accounts. No pressure. Just you and your next small step.",
        "Sans compte. Sans pression. Juste vous et votre prochain petit pas.",
    ),
    "welcome_title": (
        "Let’s start where you are.",
        "Commençons là où vous en êtes.",
    ),
    "welcome_desc": (
        "You don’t need to know a single Arabic letter. We’ll take it one small step at a time.",
        "Pas besoin de connaître une seule lettre arabe. Nous avancerons un petit pas à la fois.",
    ),
    "new_title": ("I’m completely new", "Je débute complètement"),
    "new_desc": (
        "A fresh start, from the very first letter.",
        "Un nouveau départ, dès la première lettre.",
    ),
    "familiar_title": (
        "I’ve seen a few letters",
        "Je connais quelques lettres",
    ),
    "familiar_desc": (
        "Let’s gently explore what looks familiar.",
        "Voyons tranquillement ce qui vous est familier.",
    ),
    "nickname_title": ("What should we call you?", "Comment vous appeler ?"),
    "nickname_desc": (
        "A first name or a nickname is perfect. This little learning space is yours.",
        "Un prénom ou un surnom suffit. Ce petit espace d’apprentissage est le vôtre.",
    ),
    "nickname_label": ("Your nickname", "Votre surnom"),
    "nickname_placeholder": ("e.g. Alex", "par ex. Alex"),
    "nickname_error": (
        "Please enter a nickname of 1–24 characters.",
        "Saisissez un surnom de 1 à 24 caractères.",
    ),
    "saved_device": (
        "Your preferences stay in this browser. No account needed.",
        "Vos préférences restent dans ce navigateur. Aucun compte nécessaire.",
    ),
    "continue": ("Continue", "Continuer"),
    "back": ("Back", "Retour"),
    "check_title": (
        "A tiny check, not a test.",
        "Une petite découverte, pas un examen.",
    ),
    "check_desc": (
        "Three gentle questions. It’s perfectly okay to say “I don’t know yet.”",
        "Trois petites questions. Vous pouvez tout à fait répondre « Je ne sais pas encore ».",
    ),
    "find_letter": ("Which one is", "Quelle est la lettre"),
    "unknown": ("I don’t know yet", "Je ne sais pas encore"),
    "correct": (
        "You spotted it! A lovely first step.",
        "Vous l’avez reconnue ! Un joli premier pas.",
    ),
    "incorrect": (
        "No worries. This is a new alphabet — we’ll learn it together.",
        "Pas de souci. C’est un nouvel alphabet : nous l’apprendrons ensemble.",
    ),
    "unknown_feedback": (
        "That’s exactly what we’re here for. Every letter will become familiar.",
        "Nous sommes là pour ça. Chaque lettre vous deviendra familière.",
    ),
    "answer_is": ("Meet", "Voici"),
    "next_question": ("Next question", "Question suivante"),
    "see_start": ("Find my starting point", "Découvrir mon point de départ"),
    "skip_check": (
        "Skip and start from the beginning",
        "Passer et commencer au début",
    ),
    "result_eyebrow": ("YOUR STARTING POINT", "VOTRE POINT DE DÉPART"),
    "beginner": ("Complete Beginner", "Débutant complet"),
    "result_title": ("A beautiful place to begin.", "Un beau point de départ."),
    "result_desc": (
        "We’ll begin with the Arabic alphabet, build your confidence, and take each new step together. This starting level isn’t a grade.",
        "Commençons par l’alphabet arabe, pour prendre confiance et avancer ensemble. Ce niveau de départ n’est pas une note.",
    ),
    "result_note": (
        "This is a gentle starting suggestion, not a grade. Recognizing a letter is not completing a lesson: all online modules are open, while stars and badges are earned through practice.",
        "C’est une suggestion de départ tout en douceur, pas une note. Reconnaître une lettre ne termine pas une leçon : tous les modules en ligne sont accessibles, tandis que les étoiles et badges se gagnent par la pratique.",
    ),
    "familiar_beginner": (
        "Familiar Beginner",
        "Débutant avec quelques repères",
    ),
    "placement_complete": (
        "You recognized {count} of the three letters. Let’s build confidence with shapes and sounds, one letter at a time.",
        "Vous avez reconnu {count} des trois lettres. Prenons confiance avec les formes et les sons, une lettre à la fois.",
    ),
    "placement_familiar": (
        "You recognized {count} of the three letters — some shapes already look familiar! Explore your suggested letter, then practise its sounds and connected forms.",
        "Vous avez reconnu {count} des trois lettres : certaines formes vous sont déjà familières ! Découvrez la lettre suggérée, puis pratiquez ses sons et ses formes liées.",
    ),
    "placement_skipped": (
        "No placement result yet — and that’s perfectly okay. Start with Alif and discover the alphabet at your own pace.",
        "Pas encore de résultat de découverte, et c’est tout à fait normal. Commencez par Alif et découvrez l’alphabet à votre rythme.",
    ),
    "recommended_letter": (
        "Your suggested next letter",
        "Votre prochaine lettre suggérée",
    ),
    "recommended_reason": (
        "Start with the first test letter you didn’t recognize yet, or Tāʾ if all three looked familiar. You can explore any letter in the Letters path.",
        "Commencez par la première lettre non reconnue, ou par Tāʾ si les trois vous étaient familières. Vous pouvez explorer toute lettre dans le parcours des lettres.",
    ),
    "open_recommended": ("Explore", "Découvrir"),
    "letters_review_tag": ("TIME TO REVIEW", "PLACE À LA RÉVISION"),
    "letters_review_title": (
        "Keep your alphabet familiar.",
        "Gardez l’alphabet en mémoire.",
    ),
    "letters_review_desc": (
        "You’ve completed all 28 letter lessons! Revisit shapes, sounds and connected forms at your own pace.",
        "Vous avez terminé les 28 leçons de lettres ! Revoyez les formes, les sons et les formes liées à votre rythme.",
    ),
    "letters_review_letter": (
        "Your letter to review",
        "Votre lettre à réviser",
    ),
    "letters_review_hint": (
        "Return to your original starting letter for review, or choose any letter in the Letters path. Your saved progress stays unchanged.",
        "Revenez à votre lettre de départ pour réviser, ou choisissez une lettre dans le parcours des lettres. Vos progrès enregistrés restent inchangés.",
    ),
    "letters_review_cta": ("Review", "Réviser"),
    "suggestion_short": (
        "A gentle starting suggestion, not a grade. Your lesson progress stays earned through practice.",
        "Une suggestion de départ, pas une note. Votre progression se gagne toujours par la pratique.",
    ),
    "go_home": ("Let’s begin", "C’est parti"),
    "hello": ("Hello", "Bonjour"),
    "welcome_back": ("YOUR ARABIC JOURNEY", "VOTRE VOYAGE EN ARABE"),
    "home_title": (
        "Small steps. Meaningful progress.",
        "De petits pas. De vrais progrès.",
    ),
    "home_desc": (
        "Your new alphabet is waiting. There’s no rush — just a little curiosity.",
        "Votre nouvel alphabet vous attend. Rien ne presse : un peu de curiosité suffit.",
    ),
    "level": ("Your level", "Votre niveau"),
    "total_progress": ("Learning progress", "Progression"),
    "stars": ("Stars earned", "Étoiles gagnées"),
    "streak": ("Day streak", "Jours de suite"),
    "foundations": ("Start with the foundations", "Commençons par les bases"),
    "no_lessons": ("0 lessons completed", "0 leçon terminée"),
    "stars_hint": ("Every small effort counts", "Chaque petit effort compte"),
    "streak_hint": ("A fresh beginning", "Un nouveau départ"),
    "next_step": ("YOUR FIRST STEP", "VOTRE PREMIER PAS"),
    "letters_continue_tag": ("YOUR NEXT STEP", "VOTRE PROCHAIN PAS"),
    "letters_continue_desc": (
        "Keep building on your saved letter lessons. Your next unfinished letter is",
        "Continuez à partir de vos leçons de lettres enregistrées. Votre prochaine lettre à découvrir est",
    ),
    "letters_continue_hint": (
        "This suggestion follows your saved lessons, skipping letters you’ve already completed. Your completed lessons, earned stars and badges stay saved — continue at your own pace.",
        "Cette suggestion suit vos leçons enregistrées, sans reprendre les lettres déjà terminées. Vos leçons terminées, étoiles gagnées et badges restent enregistrés : continuez à votre rythme.",
    ),
    "letters_title": (
        "Make friends with the alphabet.",
        "Faites connaissance avec l’alphabet.",
    ),
    "letters_desc": (
        "28 letters. A new way of reading. Start by getting to know the shapes that make Arabic so beautiful.",
        "28 lettres. Une nouvelle façon de lire. Découvrez les formes qui font toute la beauté de l’arabe.",
    ),
    "explore_letters": ("Explore the alphabet", "Explorer l’alphabet"),
    "letters_count": ("28 letters", "28 lettres"),
    "at_your_pace": ("At your own pace", "À votre rythme"),
    "daily_title": ("A little Arabic, every day", "Un peu d’arabe chaque jour"),
    "daily_desc": (
        "Five quick activities, available from your first day. Preview letters, a sound, a word and a number — no lessons required.",
        "Cinq petites activités dès le premier jour. Découvrez des lettres, un son, un mot et un nombre — aucune leçon préalable nécessaire.",
    ),
    "daily_button": (
        "Discover daily practice",
        "Découvrir la pratique quotidienne",
    ),
    "daily_tag": ("A habit worth growing", "Une habitude à cultiver"),
    "path_title": ("Your learning path", "Votre parcours"),
    "path_desc": (
        "Explore any online module from the start. Each completed lesson and activity builds your earned progress.",
        "Explorez tout module en ligne dès le départ. Chaque leçon et activité terminée enrichit vos progrès.",
    ),
    "eight_modules": ("9 connected modules", "9 modules reliés"),
    "module_grammar": ("Beginner Grammar", "Grammaire débutante"),
    "desc_grammar": (
        "Pronouns, gender agreement and your first Arabic sentences.",
        "Pronoms, accords et premières phrases en arabe.",
    ),
    "available": ("Start here", "Commencez ici"),
    "locked": ("Locked", "Verrouillé"),
    "module_letters": ("Arabic Letters", "Lettres arabes"),
    "module_harakat": ("Short Vowels", "Voyelles courtes"),
    "module_numbers": ("Numbers", "Nombres"),
    "module_colors": ("Colors", "Couleurs"),
    "module_vocabulary": ("Everyday Vocabulary", "Vocabulaire du quotidien"),
    "module_words": ("Word Building", "Construction de mots"),
    "module_phrases": ("Everyday Phrases", "Expressions du quotidien"),
    "module_dialogues": ("Simple Dialogues", "Dialogues simples"),
    "desc_letters": (
        "Meet the shapes and sounds of 28 letters.",
        "Découvrez les formes et les sons de 28 lettres.",
    ),
    "desc_harakat": (
        "Bring letters to life with vowel marks.",
        "Donnez vie aux lettres avec les voyelles.",
    ),
    "desc_numbers": (
        "Count your first steps in Arabic.",
        "Comptez vos premiers pas en arabe.",
    ),
    "desc_colors": (
        "See your world in a new language.",
        "Voyez le monde dans une nouvelle langue.",
    ),
    "desc_vocabulary": (
        "Useful words for the world around you.",
        "Des mots utiles pour votre quotidien.",
    ),
    "desc_words": (
        "Put familiar letters together.",
        "Assemblez les lettres que vous connaissez.",
    ),
    "desc_phrases": (
        "Say a little, connect a lot.",
        "Quelques mots pour créer des liens.",
    ),
    "desc_dialogues": (
        "Your first everyday conversations.",
        "Vos premières conversations du quotidien.",
    ),
    "unlock_after": ("Complete first:", "À terminer d’abord :"),
    "footer": (
        "Made for small steps and curious minds.",
        "Pour les petits pas et les esprits curieux.",
    ),
    "close": ("Close", "Fermer"),
    "coming_title": ("One step at a time.", "Une étape à la fois."),
    "future_note": (
        "This learning module is part of the upcoming path. Its activities aren’t available yet. Your foundations come first.",
        "Ce module fait partie de la suite du parcours. Ses activités ne sont pas encore disponibles. Les bases passent d’abord.",
    ),
    "alphabet_intro": (
        "Meet your new alphabet",
        "Découvrez votre nouvel alphabet",
    ),
    "alphabet_detail": (
        "Arabic is read from right to left. Its 28 letters can change shape depending on their position in a word. The upcoming letter path will guide you through sounds, forms, and writing.",
        "L’arabe se lit de droite à gauche. Ses 28 lettres peuvent changer de forme selon leur place dans un mot. Le parcours des lettres vous guidera dans les sons, les formes et l’écriture.",
    ),
    "preview_label": ("A FIRST LOOK", "UN PREMIER APERÇU"),
    "lesson_pending": (
        "The alphabet overview is ready to explore. Interactive letter lessons will arrive with the next learning module release.",
        "L’aperçu de l’alphabet est prêt à explorer. Les leçons interactives arriveront avec la prochaine étape du parcours.",
    ),
    "return_path": ("Back to my path", "Revenir au parcours"),
    "daily_detail": (
        "Five daily activities are available from your first day, alongside all online lessons and games. Only completed activities earn progress.",
        "Cinq activités quotidiennes sont accessibles dès le premier jour, avec toutes les leçons et tous les jeux en ligne. Seules les activités terminées rapportent des progrès.",
    ),
    "daily_empty": (
        "Your daily routine is taking shape",
        "Votre routine prend forme",
    ),
    "games_title": ("A playful way to grow.", "Apprendre en s’amusant."),
    "games_desc": (
        "Explore every letter game, word challenge and sentence activity from the start. Successful practice earns progress; opening a game does not.",
        "Explorez tous les jeux de lettres, défis de mots et activités de phrases dès le départ. Les réussites rapportent des progrès ; ouvrir un jeu n’en rapporte pas.",
    ),
    "games_pending": ("Games are on their way", "Les jeux arrivent bientôt"),
    "view_path": ("Explore your learning path", "Explorer votre parcours"),
    "progress_title": ("Every beginning matters.", "Chaque début compte."),
    "progress_desc": (
        "This is your starting point. Your completed lessons, stars, and practice streak will appear here as learning activities become available.",
        "Voici votre point de départ. Vos leçons terminées, étoiles et jours de pratique apparaîtront ici quand les activités seront disponibles.",
    ),
    "progress_empty": ("Your story starts here", "Votre histoire commence ici"),
    "progress_empty_desc": (
        "No lessons completed yet. There’s no finish line to race toward — just the next small step.",
        "Aucune leçon terminée pour l’instant. Pas de course à l’arrivée : seulement le prochain petit pas.",
    ),
    "settings_title": ("Make yourself at home.", "Sentez-vous chez vous."),
    "settings_desc": (
        "A few simple preferences for your learning space.",
        "Quelques préférences pour votre espace d’apprentissage.",
    ),
    "profile": ("Your learning profile", "Votre profil d’apprentissage"),
    "save": ("Save nickname", "Enregistrer le surnom"),
    "saved": (
        "Nickname saved in this browser.",
        "Surnom enregistré dans ce navigateur.",
    ),
    "interface_language": ("Interface language", "Langue de l’interface"),
    "about_title": (
        "A private, simple beginning",
        "Un début simple et personnel",
    ),
    "about_desc": (
        "Your nickname, language, and onboarding completion are remembered locally in this browser. No account or database. Clearing your browser’s site data removes these preferences.",
        "Votre surnom, votre langue et la fin de l’accueil sont mémorisés localement dans ce navigateur. Sans compte ni base de données. Effacer les données du site supprime ces préférences.",
    ),
    "step": ("Step", "Étape"),
    "of": ("of", "sur"),
    "question": ("Question", "Question"),
    "greeting_meaning": ("Hello / Welcome", "Bonjour / Bienvenue"),
    "right_to_left": (
        "A new alphabet. A new perspective.",
        "Un nouvel alphabet. Une nouvelle perspective.",
    ),
    "setup": ("A gentle beginning", "Un début tout en douceur"),
    "learn_title": (
        "A path built around small steps.",
        "Un parcours fait de petits pas.",
    ),
    "learn_desc": (
        "Begin with letters, then let each foundation lead you further.",
        "Commencez par les lettres, puis avancez sur des bases solides.",
    ),
}

MODULES: list[tuple[str, str, str, str, str]] = [
    ("letters", "module_letters", "desc_letters", "ا ب ت", ""),
    ("harakat", "module_harakat", "desc_harakat", "َ ِ ُ", "req_letters3"),
    ("grammar", "module_grammar", "desc_grammar", "أنا · هي", "req_letters3"),
    ("writing", "module_writing", "desc_writing", "قلم", "req_letters3"),
    ("numbers", "module_numbers", "desc_numbers", "١ ٢ ٣", "req_harakat"),
    ("colors", "module_colors", "desc_colors", "ألوان", "req_numbers"),
    (
        "vocabulary",
        "module_vocabulary",
        "desc_vocabulary",
        "كلمات",
        "req_colors",
    ),
    ("phrases", "module_phrases", "desc_phrases", "مرحبًا", "req_words"),
    ("games", "module_games", "desc_games", "لعب", "req_letters5"),
]
