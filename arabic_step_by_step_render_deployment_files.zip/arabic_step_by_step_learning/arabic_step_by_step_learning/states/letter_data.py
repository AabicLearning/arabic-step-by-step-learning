import reflex as rx
import unicodedata
from typing import TypedDict


class LetterData(TypedDict):
    id: int
    glyph: str
    name: str
    romanization: str
    tip_en: str
    tip_fr: str
    word: str
    word_en: str
    word_fr: str
    joins: bool
    isolated: str
    initial: str
    medial: str
    final: str


# Educational content, not generated sample data. Unicode presentation forms
# keep each contextual shape visible even outside a surrounding word.
LETTER_ROWS: list[tuple[str, str, str, str, str, str, str, str]] = [
    (
        "ا",
        "أَلِف",
        "Alif",
        "A long ‘aa’, as in father. Alif can also carry hamza (أ / إ), a brief throat stop.",
        "Un « aa » long, comme le a de papa prolongé. Alif peut aussi porter hamza (أ / إ), un bref arrêt dans la gorge.",
        "أَرْنَب",
        "rabbit",
        "lapin",
    ),
    (
        "ب",
        "بَاء",
        "Bāʾ",
        "‘b’ as in boat; the lips meet, then open.",
        "Le « b » de bateau ; les lèvres se ferment puis s’ouvrent.",
        "بَاب",
        "door",
        "porte",
    ),
    (
        "ت",
        "تَاء",
        "Tāʾ",
        "A light ‘t’ as in tea; touch the upper teeth with the tongue.",
        "Un « t » léger comme dans tasse ; la langue touche les dents du haut.",
        "تُفَّاح",
        "apples",
        "pommes",
    ),
    (
        "ث",
        "ثَاء",
        "Thāʾ",
        "Unvoiced ‘th’ as in thin, not the ‘th’ in this. Let air pass between tongue and teeth.",
        "Pas d’équivalent exact en français : le « th » anglais de thin, sans voix, langue entre les dents.",
        "ثَعْلَب",
        "fox",
        "renard",
    ),
    (
        "ج",
        "جِيم",
        "Jīm",
        "‘j’ as in jam in Modern Standard Arabic. Regional pronunciations vary.",
        "« dj » comme dans djinn en arabe standard. La prononciation varie selon les régions.",
        "جَمَل",
        "camel",
        "chameau",
    ),
    (
        "ح",
        "حَاء",
        "Ḥāʾ",
        "A breathy, unvoiced sound from deep in the throat, stronger than English h. Do not strain.",
        "Un souffle sourd venant du fond de la gorge, plus profond que le h anglais. Ne forcez pas.",
        "حُوت",
        "whale",
        "baleine",
    ),
    (
        "خ",
        "خَاء",
        "Khāʾ",
        "‘kh’, like the ch in Scottish loch; let air rasp gently at the back of the mouth.",
        "« kh », comme la jota espagnole ; un léger frottement de l’air au fond de la bouche.",
        "خُبْز",
        "bread",
        "pain",
    ),
    (
        "د",
        "دَال",
        "Dāl",
        "‘d’ as in door, with the tongue near the upper teeth.",
        "Le « d » de dent, langue près des dents du haut.",
        "دُبّ",
        "bear",
        "ours",
    ),
    (
        "ذ",
        "ذَال",
        "Dhāl",
        "Voiced ‘th’ as in this. Use the same tongue position as thāʾ, adding voice.",
        "Le « th » anglais de this, avec la voix ; même position de langue que ث.",
        "ذَهَب",
        "gold",
        "or",
    ),
    (
        "ر",
        "رَاء",
        "Rāʾ",
        "A tapped or lightly rolled r, with the tongue tip, unlike the English r.",
        "Un r battu ou légèrement roulé avec la pointe de la langue, différent du r français.",
        "رُمَّان",
        "pomegranate",
        "grenade",
    ),
    (
        "ز",
        "زَاي",
        "Zāy",
        "‘z’ as in zoo; a voiced buzzing sound.",
        "Le « z » de zéro ; un son sonore qui vibre.",
        "زَهْرَة",
        "flower",
        "fleur",
    ),
    (
        "س",
        "سِين",
        "Sīn",
        "A light ‘s’ as in sun; keep it distinct from the heavier ṣād.",
        "Le « s » léger de soleil ; à distinguer du ص plus emphatique.",
        "سَمَك",
        "fish",
        "poisson",
    ),
    (
        "ش",
        "شِين",
        "Shīn",
        "‘sh’ as in shoe, with air flowing gently.",
        "Le « ch » de chat, avec un souffle doux.",
        "شَمْس",
        "sun",
        "soleil",
    ),
    (
        "ص",
        "صَاد",
        "Ṣād",
        "An emphatic, darker s. Raise the back of the tongue slightly while making s.",
        "Un s emphatique, plus sombre. Relevez légèrement l’arrière de la langue en disant s.",
        "صَابُون",
        "soap",
        "savon",
    ),
    (
        "ض",
        "ضَاد",
        "Ḍād",
        "An emphatic, darker d. Keep it distinct from plain dāl.",
        "Un d emphatique, plus sombre ; à distinguer du د ordinaire.",
        "ضِفْدَع",
        "frog",
        "grenouille",
    ),
    (
        "ط",
        "طَاء",
        "Ṭāʾ",
        "An emphatic, darker t, with the back of the tongue raised slightly.",
        "Un t emphatique, plus sombre, l’arrière de la langue légèrement relevé.",
        "طَائِر",
        "bird",
        "oiseau",
    ),
    (
        "ظ",
        "ظَاء",
        "Ẓāʾ",
        "An emphatic version of the voiced th in this; tongue near the teeth, with a darker resonance.",
        "Une version emphatique du « th » anglais de this : langue près des dents, résonance plus sombre.",
        "ظِلّ",
        "shade",
        "ombre",
    ),
    (
        "ع",
        "عَيْن",
        "ʿAyn",
        "A voiced sound made deep in the throat. There is no English equivalent; listen and imitate gently.",
        "Un son sonore produit au fond de la gorge, sans équivalent français. Écoutez et imitez doucement.",
        "عَيْن",
        "eye",
        "œil",
    ),
    (
        "غ",
        "غَيْن",
        "Ghayn",
        "A voiced ‘gh’ from the back of the mouth, somewhat like a French r.",
        "Un « gh » sonore au fond de la bouche, proche d’un r français grasseyé.",
        "غَيْم",
        "clouds",
        "nuages",
    ),
    (
        "ف",
        "فَاء",
        "Fāʾ",
        "‘f’ as in fish; upper teeth touch the lower lip.",
        "Le « f » de fleur ; les dents du haut touchent la lèvre inférieure.",
        "فِيل",
        "elephant",
        "éléphant",
    ),
    (
        "ق",
        "قَاف",
        "Qāf",
        "A deep q sound, farther back than k, near the uvula. Standard Arabic keeps it distinct from kāf.",
        "Un q profond, plus en arrière que k, près de la luette. En arabe standard, il se distingue du ك.",
        "قَمَر",
        "moon",
        "lune",
    ),
    (
        "ك",
        "كَاف",
        "Kāf",
        "‘k’ as in kite; lighter and farther forward than qāf.",
        "Le « k » de kilo, plus léger et plus en avant que ق.",
        "كِتَاب",
        "book",
        "livre",
    ),
    (
        "ل",
        "لَام",
        "Lām",
        "‘l’ as in leaf; the tongue tip meets the ridge behind the upper teeth.",
        "Le « l » de lune ; la pointe de la langue touche derrière les dents du haut.",
        "لَيْمُون",
        "lemons",
        "citrons",
    ),
    (
        "م",
        "مِيم",
        "Mīm",
        "‘m’ as in moon, with both lips closed.",
        "Le « m » de maman, les deux lèvres fermées.",
        "مَاء",
        "water",
        "eau",
    ),
    (
        "ن",
        "نُون",
        "Nūn",
        "‘n’ as in nest, with the tongue behind the upper teeth.",
        "Le « n » de nid, langue derrière les dents du haut.",
        "نَجْم",
        "star",
        "étoile",
    ),
    (
        "ه",
        "هَاء",
        "Hāʾ",
        "A light breathy ‘h’ as in hello, not the deeper ḥāʾ (ح). Medial heh can look like a small loop.",
        "Un h soufflé léger comme dans le hello anglais, et non le ح profond. Au milieu, ه peut former une petite boucle.",
        "هِلَال",
        "crescent",
        "croissant de lune",
    ),
    (
        "و",
        "وَاو",
        "Wāw",
        "‘w’ as in water, or a long ‘oo’ as in moon when used as a vowel.",
        "Le « ou » semi-consonne de oui, ou un « ou » long lorsqu’il sert de voyelle.",
        "وَرْد",
        "roses",
        "roses",
    ),
    (
        "ي",
        "يَاء",
        "Yāʾ",
        "‘y’ as in yes, or a long ‘ee’ as in see when used as a vowel.",
        "Le « y » de yeux, ou un « i » long lorsqu’il sert de voyelle.",
        "يَد",
        "hand",
        "main",
    ),
]


def _build_letters() -> list[LetterData]:
    result: list[LetterData] = []
    for index, row in enumerate(LETTER_ROWS):
        glyph, name, romanization, tip_en, tip_fr, word, word_en, word_fr = row
        joins = glyph not in "ادذرزو"
        unicode_name = unicodedata.name(glyph)
        result.append(
            LetterData(
                id=index,
                glyph=glyph,
                name=name,
                romanization=romanization,
                tip_en=tip_en,
                tip_fr=tip_fr,
                word=word,
                word_en=word_en,
                word_fr=word_fr,
                joins=joins,
                isolated=unicodedata.lookup(f"{unicode_name} ISOLATED FORM"),
                initial=unicodedata.lookup(f"{unicode_name} INITIAL FORM")
                if joins
                else "",
                medial=unicodedata.lookup(f"{unicode_name} MEDIAL FORM")
                if joins
                else "",
                final=unicodedata.lookup(f"{unicode_name} FINAL FORM"),
            )
        )
    return result


LETTERS: list[LetterData] = _build_letters()
POSITIONS: list[str] = ["isolated", "initial", "medial", "final"]

LETTER_COPY: dict[str, tuple[str, str]] = {
    "letter_path": ("Meet all 28 letters", "Découvrez les 28 lettres"),
    "letter_path_desc": (
        "Read from right to left. Choose any letter, explore its forms, then write and play.",
        "Lisez de droite à gauche. Choisissez une lettre, explorez ses formes, puis écrivez et jouez.",
    ),
    "letter": ("Letter", "Lettre"),
    "previous": ("Previous letter", "Lettre précédente"),
    "next_letter": ("Next letter", "Lettre suivante"),
    "listen": ("Listen", "Écouter"),
    "listen_word": ("Listen to the word", "Écouter le mot"),
    "listen_sound": ("Listen to the sound", "Écouter le son"),
    "audio_note": (
        "Google Translate MP3 online first; if loading fails, a bundled Arabic MP3 plays automatically, including offline when the app’s clips are available. No device Arabic voice is needed. Synthetic pronunciation is a guide, not a native-speaker recording; bundled consonants use a short a.",
        "MP3 Google Traduction en ligne en priorité ; si le chargement échoue, un MP3 arabe intégré prend automatiquement le relais, même hors ligne si les extraits de l’application sont disponibles. Aucune voix arabe de l’appareil n’est nécessaire. La voix synthétique est un guide, pas un enregistrement natif ; les consonnes intégrées utilisent un a bref.",
    ),
    "audio_unavailable": (
        "This audio clip is unavailable. Check your connection and tap again, or use a visual activity.",
        "Cet extrait audio est indisponible. Vérifiez votre connexion et touchez à nouveau, ou utilisez une activité visuelle.",
    ),
    "audio_error": (
        "Audio could not play or was blocked. Tap again; check your connection if it still fails.",
        "Lecture impossible ou bloquée. Touchez à nouveau ; vérifiez votre connexion si le problème persiste.",
    ),
    "audio_muted": (
        "Sound is switched off in your preferences.",
        "Le son est désactivé dans vos préférences.",
    ),
    "pronunciation": ("A pronunciation hint", "Un conseil de prononciation"),
    "example_word": ("A word to remember", "Un mot à retenir"),
    "forms": (
        "One letter, different positions",
        "Une lettre, plusieurs positions",
    ),
    "isolated": ("Isolated", "Isolée"),
    "initial": ("Initial", "Initiale"),
    "medial": ("Medial", "Médiane"),
    "final": ("Final", "Finale"),
    "unavailable": ("Not available", "Non disponible"),
    "joins_both": (
        "Joins the preceding letter on the right and the following letter on the left, when those letters allow it.",
        "Se lie à la lettre précédente à droite et à la suivante à gauche, si ces lettres le permettent.",
    ),
    "joins_right": (
        "Joins only the preceding letter on the right. It never joins the next letter on the left: no initial or medial joining form. Its final form is valid.",
        "Se lie uniquement à la lettre précédente à droite. Jamais à la suivante à gauche : pas de forme liée initiale ou médiane. Sa forme finale est valide.",
    ),
    "form_note": (
        "These are connected shapes, not separate letters. A letter at the start of a word may stay isolated if it cannot join. Neighbouring letters determine the joins.",
        "Ce sont des formes liées, pas des lettres différentes. En début de mot, une lettre peut rester isolée si elle ne se lie pas. Les lettres voisines déterminent les liaisons.",
    ),
    "form_quiz": (
        "Where does this shape belong?",
        "Quelle est la position de cette forme ?",
    ),
    "form_quiz_desc": (
        "Identify the displayed contextual form. Choose one position.",
        "Identifiez la forme contextuelle affichée. Choisissez une position.",
    ),
    "well_done": (
        "You found it! Every little discovery counts.",
        "Bien trouvé ! Chaque petite découverte compte.",
    ),
    "try_again": (
        "A useful discovery. Look at the answer, then try another round.",
        "Une découverte utile. Regardez la réponse, puis essayez une autre manche.",
    ),
    "answer": ("The answer is", "La réponse est"),
    "another": ("Another round", "Une autre manche"),
    "trace": (
        "Write it, one gentle stroke at a time",
        "Écrivez, un trait à la fois",
    ),
    "trace_mode": (
        "Choose a writing reference",
        "Choisissez un modèle d’écriture",
    ),
    "syllable_a": ("Short a", "a bref"),
    "syllable_i": ("Short i", "i bref"),
    "syllable_u": ("Short u", "ou bref"),
    "short_word": ("Short word", "Mot court"),
    "trace_help": (
        "Use a finger, mouse or pen. Start near the green ring and follow the dots, generally right to left. Lift to add dots and vowel marks. The cue is a practice guide, not a prescribed calligraphic stroke order.",
        "Utilisez le doigt, la souris ou un stylet. Partez près du cercle vert et suivez les points, généralement de droite à gauche. Levez pour ajouter points et voyelles. Ce repère aide à pratiquer, sans imposer un ordre calligraphique.",
    ),
    "trace_honest": (
        "Not handwriting recognition: this checks contact with at least 65% of the dotted guide, mostly on-guide strokes (55%), a visited start area and enough movement. It cannot judge letter correctness or calligraphy.",
        "Pas de reconnaissance d’écriture : nous vérifions le contact avec au moins 65 % du guide, des traits surtout sur le guide (55 %), un départ près du repère et assez de mouvement. Ce contrôle ne juge ni la lettre ni la calligraphie.",
    ),
    "trace_ready": (
        "Follow the dotted reference, then check your tracing.",
        "Suivez le modèle pointillé, puis vérifiez votre tracé.",
    ),
    "trace_good": (
        "Lovely practice! You covered the guide. Try it once more, slowly.",
        "Belle pratique ! Vous avez suivi le guide. Réessayez doucement.",
    ),
    "trace_retry": (
        "Keep going gently. Follow more of the dotted guide, including its dots and marks.",
        "Continuez doucement. Suivez davantage le guide, y compris les points et les marques.",
    ),
    "coverage": ("Guide covered", "Guide parcouru"),
    "check_trace": ("Check tracing", "Vérifier le tracé"),
    "reset_trace": ("Clear / retry", "Effacer / réessayer"),
    "start_marker": ("Start guide • ←", "Repère de départ • ←"),
    "trace_loading": ("Preparing the writing guide…", "Préparation du modèle…"),
    "trace_error": (
        "The writing guide could not load. Retry when the Arabic font is available.",
        "Le modèle n’a pas pu se charger. Réessayez quand la police arabe est disponible.",
    ),
    "play_letters": ("Play with letters", "Jouer avec les lettres"),
    "letter_games_desc": (
        "Five small games, unlimited practice. Scores are for this session, not a grade.",
        "Cinq petits jeux, une pratique sans limite. Les scores de cette session ne sont pas une note.",
    ),
    "find": ("Find the Letter", "Trouve la lettre"),
    "listen_game": ("Listen and Choose", "Écoute et choisis"),
    "match": ("Letter Match", "Associe les lettres"),
    "memory": ("Memory", "Mémoire"),
    "odd": ("Odd One Out", "L’intrus"),
    "find_help": (
        "Choose the letter with this name.",
        "Choisissez la lettre qui porte ce nom.",
    ),
    "listen_game_help": (
        "Play the letter name, then choose its glyph. Need help? Reveal its name. Audio unavailable? Try a visual game.",
        "Écoutez le nom de la lettre, puis choisissez son signe. Besoin d’aide ? Révélez son nom. Sans audio, essayez un jeu visuel.",
    ),
    "match_help": (
        "Match this connected form to its isolated letter.",
        "Associez cette forme liée à sa lettre isolée.",
    ),
    "memory_help": (
        "Find four pairs of identical letters. Two unmatched cards stay visible until your next choice.",
        "Retrouvez quatre paires de lettres identiques. Deux cartes différentes restent visibles jusqu’à votre prochain choix.",
    ),
    "odd_help": (
        "Three cards have the same letter; one has a different letter. Find the different one, even when forms change.",
        "Trois cartes portent la même lettre ; une porte une autre lettre. Trouvez l’intrus, même si les formes changent.",
    ),
    "score": ("Score", "Score"),
    "round": ("Round", "Manche"),
    "attempts": ("Attempts", "Essais"),
    "pairs": ("Pairs", "Paires"),
    "reveal_name": ("Reveal name", "Révéler le nom"),
    "memory_pair": (
        "A pair! Your eyes are getting familiar with these shapes.",
        "Une paire ! Votre regard s’habitue à ces formes.",
    ),
    "memory_miss": (
        "Not a pair yet. Remember their places and choose another card.",
        "Pas encore une paire. Retenez leurs places et choisissez une autre carte.",
    ),
    "memory_done": (
        "All four pairs found. Beautiful practice! Start a fresh board.",
        "Les quatre paires sont trouvées. Belle pratique ! Lancez un nouveau plateau.",
    ),
    "new_board": ("New board", "Nouveau plateau"),
    "restart_game": ("Restart score", "Recommencer le score"),
    "hidden_card": ("Hidden letter", "Lettre cachée"),
    "choose_game": ("Choose a game", "Choisissez un jeu"),
}
