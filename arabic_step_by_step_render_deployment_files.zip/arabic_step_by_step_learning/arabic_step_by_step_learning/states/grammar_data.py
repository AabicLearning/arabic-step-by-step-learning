import reflex as rx
from typing import TypedDict


GRAMMAR_GROUPS: list[str] = ["pronouns", "agreement", "sentences"]


def grammar_row(
    item_id: str,
    group: str,
    arabic: str,
    roman: str,
    en: str,
    fr: str,
    tip_en: str,
    tip_fr: str,
) -> dict[str, str]:
    return dict(
        id=item_id,
        group=group,
        arabic=arabic,
        roman=roman,
        en=en,
        fr=fr,
        tip_en=tip_en,
        tip_fr=tip_fr,
    )


GRAMMAR_ROWS: list[dict[str, str]] = [
    grammar_row(
        "pronoun-ana",
        "pronouns",
        "أنا طالبٌ",
        "anā ṭālibun",
        "I am a student (male speaker).",
        "Je suis étudiant (locuteur masculin).",
        "أنا (anā) means I, whether the speaker is male or female. The noun or adjective that follows reflects the speaker: أنا طالبٌ for a male student, أنا طالبةٌ for a female student. Do not change أنا itself. There is no separate am in this present-tense sentence.",
        "أنا (anā) signifie je, quel que soit le genre du locuteur. Le nom ou l’adjectif qui suit s’accorde avec la personne : أنا طالبٌ pour un étudiant, أنا طالبةٌ pour une étudiante. أنا ne change pas. Il n’y a pas de verbe suis séparé dans cette phrase au présent.",
    ),
    grammar_row(
        "pronoun-anta",
        "pronouns",
        "أنتَ طالبٌ",
        "anta ṭālibun",
        "You are a student (one male listener).",
        "Tu es étudiant (un interlocuteur masculin).",
        "أنتَ (anta) addresses one male listener. The final fatḥa gives the sound a. Choose this form for the listener’s gender, not the speaker’s: a woman speaking to a man still uses أنتَ. طالبٌ describes that male listener.",
        "أنتَ (anta) s’adresse à un seul interlocuteur masculin. La fatḥa finale donne le son a. Le genre est celui de l’interlocuteur, pas du locuteur : une femme parlant à un homme emploie aussi أنتَ. طالبٌ décrit cet interlocuteur masculin.",
    ),
    grammar_row(
        "pronoun-anti",
        "pronouns",
        "أنتِ طالبةٌ",
        "anti ṭālibatun",
        "You are a student (one female listener).",
        "Tu es étudiante (une interlocutrice).",
        "أنتِ (anti) addresses one female listener; the final kasra gives i. Its unvowelled spelling is the same as أنتَ, so the vowel matters. A man speaking to a woman uses أنتِ. طالبةٌ is the feminine form of طالبٌ.",
        "أنتِ (anti) s’adresse à une seule interlocutrice ; la kasra finale donne i. Sans voyelles, son écriture est la même que أنتَ : la voyelle est donc importante. Un homme parlant à une femme emploie أنتِ. طالبةٌ est le féminin de طالبٌ.",
    ),
    grammar_row(
        "pronoun-huwa",
        "pronouns",
        "هو صغيرٌ",
        "huwa ṣaghīrun",
        "He is small / young.",
        "Il est petit / jeune.",
        "هو (huwa) means he, referring to someone rather than addressing them. It can also refer to a grammatically masculine thing: Arabic nouns have grammatical gender. صغيرٌ is masculine singular, agreeing with the subject.",
        "هو (huwa) signifie il : on parle de quelqu’un, sans s’adresser à lui. Il peut aussi reprendre une chose de genre grammatical masculin : les noms arabes ont un genre. صغيرٌ est au masculin singulier et s’accorde avec le sujet.",
    ),
    grammar_row(
        "pronoun-hiya",
        "pronouns",
        "هي صغيرةٌ",
        "hiya ṣaghīratun",
        "She is small / young.",
        "Elle est petite / jeune.",
        "هي (hiya) means she and can also refer to a grammatically feminine thing. صغيرةٌ is the feminine singular of صغيرٌ. Compare هو صغيرٌ and هي صغيرةٌ: both the pronoun and the describing word match the subject.",
        "هي (hiya) signifie elle et peut aussi reprendre une chose de genre grammatical féminin. صغيرةٌ est le féminin singulier de صغيرٌ. Comparez هو صغيرٌ et هي صغيرةٌ : le pronom et le mot descriptif s’accordent avec le sujet.",
    ),
    grammar_row(
        "demonstrative-m",
        "agreement",
        "هذا طالبٌ",
        "hādhā ṭālibun",
        "This is a male student.",
        "C’est un étudiant.",
        "هذا (hādhā) means this for a masculine singular person or noun. Here طالبٌ is an indefinite predicate: This is a student. Compare هذه طالبةٌ for a female student. Although هذا contains a long ā sound, its usual spelling does not show a full alif after ه.",
        "هذا (hādhā) signifie ceci pour une personne ou un nom masculin singulier. Ici طالبٌ est un attribut indéfini : C’est un étudiant. Comparez هذه طالبةٌ pour une étudiante. Le son ā de هذا est long, bien que l’orthographe habituelle n’ait pas d’alif complet après ه.",
    ),
    grammar_row(
        "demonstrative-f",
        "agreement",
        "هذه طالبةٌ",
        "hādhihi ṭālibatun",
        "This is a female student.",
        "C’est une étudiante.",
        "هذه (hādhihi) is this for a feminine singular person or noun. طالبٌ becomes طالبةٌ with tāʾ marbūṭa (ة), a common feminine ending, but not every feminine noun ends in ة. Learn each noun’s gender. With case endings pronounced, ة here sounds like t: ṭālibatun; at a pause it is usually ṭāliba.",
        "هذه (hādhihi) signifie ceci au féminin singulier. طالبٌ devient طالبةٌ avec une tāʾ marbūṭa (ة), une terminaison féminine fréquente ; tous les noms féminins ne finissent pourtant pas par ة. Apprenez le genre de chaque nom. Avec la désinence prononcée, ة se lit t ici : ṭālibatun ; à la pause, on dit généralement ṭāliba.",
    ),
    grammar_row(
        "adjective-m",
        "agreement",
        "الولدُ صغيرٌ",
        "al-waladu ṣaghīrun",
        "The boy is small / young.",
        "Le garçon est petit / jeune.",
        "The describing word agrees in gender and number: الولدُ is masculine singular, so use صغيرٌ. This is a complete sentence: the boy is small. The subject has ال (the), but the predicate is indefinite. Contrast the noun phrase الولدُ الصغيرُ (the small boy), where the adjective also has ال.",
        "Le mot descriptif s’accorde en genre et en nombre : الولدُ est masculin singulier, donc on emploie صغيرٌ. C’est une phrase complète : le garçon est petit. Le sujet porte ال (le), mais l’attribut est indéfini. Comparez le groupe nominal الولدُ الصغيرُ (le petit garçon), où l’adjectif porte aussi ال.",
    ),
    grammar_row(
        "adjective-f",
        "agreement",
        "البنتُ صغيرةٌ",
        "al-bintu ṣaghīratun",
        "The girl is small / young.",
        "La fille est petite / jeune.",
        "البنتُ is feminine even though بنت does not end in ة. Its predicate is therefore صغيرةٌ, not صغيرٌ. In these singular examples, a masculine adjective often gains ة for its feminine form. This is not a universal rule for all adjectives, including some color words.",
        "البنتُ est féminin, bien que بنت ne finisse pas par ة. Son attribut est donc صغيرةٌ, et non صغيرٌ. Dans ces exemples au singulier, un adjectif masculin prend souvent ة au féminin. Ce n’est pas une règle universelle pour tous les adjectifs, notamment certaines couleurs.",
    ),
    grammar_row(
        "nominal-i",
        "sentences",
        "أنا طالبةٌ",
        "anā ṭālibatun",
        "I am a student (female speaker).",
        "Je suis étudiante (locutrice).",
        "A basic present-tense nominal sentence has a subject and a predicate, without an Arabic word for am, is or are: أنا + طالبةٌ. The pronoun أنا is the same for all speakers; the predicate here identifies a female student. This no-copula pattern describes the present, not every tense.",
        "Une phrase nominale simple au présent contient un sujet et un attribut, sans mot arabe pour suis, est ou sont : أنا + طالبةٌ. أنا reste identique pour tous les locuteurs ; ici, l’attribut désigne une étudiante. Cette construction sans copule décrit le présent, pas tous les temps.",
    ),
    grammar_row(
        "nominal-she",
        "sentences",
        "هي طالبةٌ",
        "hiya ṭālibatun",
        "She is a student.",
        "Elle est étudiante.",
        "هي is the subject and طالبةٌ tells us what she is. Do not insert a verb meaning is. In carefully vowelled MSA, an indefinite nominal predicate often has nominative tanwīn ـٌ (-un). Transliteration here includes case endings; recordings may simplify them at pauses.",
        "هي est le sujet et طالبةٌ indique ce qu’elle est. N’ajoutez pas de verbe signifiant est. En arabe standard soigneusement vocalisé, un attribut nominal indéfini porte souvent le tanwīn du nominatif ـٌ (-un). La translittération inclut les désinences ; les enregistrements peuvent les simplifier à la pause.",
    ),
    grammar_row(
        "svo-she-reads",
        "sentences",
        "هي تقرأُ كتابًا",
        "hiya taqraʾu kitāban",
        "She reads a book.",
        "Elle lit un livre.",
        "This sentence has subject–verb–object order: هي (she), تقرأُ (reads), كتابًا (a book). The verb agrees with the feminine singular subject. The direct object has accusative tanwīn ـً (-an). Arabic also allows verb-first sentences; this exercise practises subject-first order, not the only possible Arabic order.",
        "Cette phrase suit l’ordre sujet–verbe–objet : هي (elle), تقرأُ (lit), كتابًا (un livre). Le verbe s’accorde avec le sujet féminin singulier. Le complément d’objet direct porte le tanwīn de l’accusatif ـً (-an). L’arabe permet aussi les phrases commençant par le verbe ; cet exercice travaille l’ordre sujet d’abord, sans prétendre que c’est le seul ordre possible.",
    ),
    grammar_row(
        "svo-he-reads",
        "sentences",
        "هو يقرأُ كتابًا",
        "huwa yaqraʾu kitāban",
        "He reads a book.",
        "Il lit un livre.",
        "Compare هو يقرأُ كتابًا with هي تقرأُ كتابًا. In these third-person singular forms, the verb begins with يـ for he and تـ for she. كتابًا remains the object in both. The تـ prefix can have other meanings with other subjects; do not treat it as always meaning she.",
        "Comparez هو يقرأُ كتابًا et هي تقرأُ كتابًا. Dans ces formes de troisième personne du singulier, le verbe commence par يـ pour il et تـ pour elle. كتابًا reste le complément d’objet dans les deux phrases. Le préfixe تـ peut avoir d’autres sens avec d’autres sujets ; il ne signifie pas toujours elle.",
    ),
]


class GrammarQuestion(TypedDict):
    id: str
    lesson: str
    prompt_en: str
    prompt_fr: str
    arabic: str
    roman: str
    en: str
    fr: str
    options: list[str]
    correct: str


def question(
    item_id: str,
    lesson: str,
    prompt_en: str,
    prompt_fr: str,
    arabic: str,
    roman: str,
    en: str,
    fr: str,
    options: list[str],
    correct: str,
) -> GrammarQuestion:
    return GrammarQuestion(
        id=item_id,
        lesson=lesson,
        prompt_en=prompt_en,
        prompt_fr=prompt_fr,
        arabic=arabic,
        roman=roman,
        en=en,
        fr=fr,
        options=options,
        correct=correct,
    )


GRAMMAR_QUESTIONS: dict[str, list[GrammarQuestion]] = {
    "pronoun_identify": [
        question(
            "identify-i-m",
            "pronoun-ana",
            "A male speaker says ‘I’. Which pronoun?",
            "Un homme dit « je ». Quel pronom ?",
            "أنا",
            "anā",
            "I — any speaker’s gender.",
            "Je — quel que soit le genre du locuteur.",
            ["أنا", "أنتَ", "هو", "هي"],
            "أنا",
        ),
        question(
            "identify-i-f",
            "pronoun-ana",
            "A female speaker says ‘I’. Which pronoun?",
            "Une femme dit « je ». Quel pronom ?",
            "أنا",
            "anā",
            "I — the pronoun does not change for a female speaker.",
            "Je — le pronom ne change pas pour une locutrice.",
            ["أنا", "أنتِ", "هو", "هي"],
            "أنا",
        ),
        question(
            "identify-you-m",
            "pronoun-anta",
            "A woman addresses one man as ‘you’. Choose the pronoun.",
            "Une femme s’adresse à un homme en disant « tu ». Choisissez le pronom.",
            "أنتَ",
            "anta",
            "You — one male listener, regardless of speaker.",
            "Tu — un interlocuteur masculin, quel que soit le locuteur.",
            ["أنتَ", "أنتِ", "أنا", "هو"],
            "أنتَ",
        ),
        question(
            "identify-you-f",
            "pronoun-anti",
            "A man addresses one woman as ‘you’. Choose the pronoun.",
            "Un homme s’adresse à une femme en disant « tu ». Choisissez le pronom.",
            "أنتِ",
            "anti",
            "You — one female listener, regardless of speaker.",
            "Tu — une interlocutrice, quel que soit le locuteur.",
            ["أنتَ", "أنتِ", "أنا", "هي"],
            "أنتِ",
        ),
        question(
            "identify-he",
            "pronoun-huwa",
            "You are talking about a boy: ‘he’. Which pronoun?",
            "Vous parlez d’un garçon : « il ». Quel pronom ?",
            "هو",
            "huwa",
            "He — talking about him, not addressing him.",
            "Il — on parle de lui, sans s’adresser à lui.",
            ["هو", "هي", "أنتَ", "أنا"],
            "هو",
        ),
        question(
            "identify-she",
            "pronoun-hiya",
            "You are talking about a girl: ‘she’. Which pronoun?",
            "Vous parlez d’une fille : « elle ». Quel pronom ?",
            "هي",
            "hiya",
            "She — talking about her, not addressing her.",
            "Elle — on parle d’elle, sans s’adresser à elle.",
            ["هو", "هي", "أنتِ", "أنا"],
            "هي",
        ),
    ],
    "gender_agreement": [
        question(
            "agree-this-m",
            "demonstrative-m",
            "Complete ‘This is a male student’: □ طالبٌ",
            "Complétez « C’est un étudiant » : □ طالبٌ",
            "هذا طالبٌ",
            "hādhā ṭālibun",
            "هذا matches masculine طالبٌ.",
            "هذا s’accorde avec طالبٌ, masculin.",
            ["هذا", "هذه"],
            "هذا",
        ),
        question(
            "agree-this-f",
            "demonstrative-f",
            "Complete ‘This is a female student’: □ طالبةٌ",
            "Complétez « C’est une étudiante » : □ طالبةٌ",
            "هذه طالبةٌ",
            "hādhihi ṭālibatun",
            "هذه matches feminine طالبةٌ.",
            "هذه s’accorde avec طالبةٌ, féminin.",
            ["هذا", "هذه"],
            "هذه",
        ),
        question(
            "agree-boy",
            "adjective-m",
            "Complete ‘The boy is small’: الولدُ □",
            "Complétez « Le garçon est petit » : الولدُ □",
            "الولدُ صغيرٌ",
            "al-waladu ṣaghīrun",
            "صغيرٌ matches the masculine singular subject.",
            "صغيرٌ s’accorde avec le sujet masculin singulier.",
            ["صغيرٌ", "صغيرةٌ"],
            "صغيرٌ",
        ),
        question(
            "agree-girl",
            "adjective-f",
            "Complete ‘The girl is small’: البنتُ □",
            "Complétez « La fille est petite » : البنتُ □",
            "البنتُ صغيرةٌ",
            "al-bintu ṣaghīratun",
            "صغيرةٌ matches بنت, which is feminine without ة.",
            "صغيرةٌ s’accorde avec بنت, féminin sans ة.",
            ["صغيرٌ", "صغيرةٌ"],
            "صغيرةٌ",
        ),
        question(
            "agree-you-f",
            "pronoun-anti",
            "Address a female student: أنتِ □",
            "Parlez à une étudiante : أنتِ □",
            "أنتِ طالبةٌ",
            "anti ṭālibatun",
            "طالبةٌ agrees with a female listener.",
            "طالبةٌ s’accorde avec l’interlocutrice.",
            ["طالبٌ", "طالبةٌ"],
            "طالبةٌ",
        ),
        question(
            "agree-read-f",
            "svo-she-reads",
            "Complete ‘She reads a book’: هي □ كتابًا",
            "Complétez « Elle lit un livre » : هي □ كتابًا",
            "هي تقرأُ كتابًا",
            "hiya taqraʾu kitāban",
            "تقرأُ agrees with هي; يقرأُ is used with هو here.",
            "تقرأُ s’accorde avec هي ; ici يقرأُ s’emploie avec هو.",
            ["يقرأُ", "تقرأُ"],
            "تقرأُ",
        ),
    ],
    "grammar_order": [
        question(
            f"order-{row['id']}",
            row["id"],
            row["en"],
            row["fr"],
            row["arabic"],
            row["roman"],
            row["en"],
            row["fr"],
            [],
            row["arabic"],
        )
        for row in GRAMMAR_ROWS
        if row["group"] == "sentences"
    ],
}

GRAMMAR_COPY: dict[str, tuple[str, str]] = {
    "grammar_pronouns": (
        "1 · Pronouns: speaker & listener",
        "1 · Pronoms : locuteur et interlocuteur",
    ),
    "grammar_agreement": (
        "2 · Masculine & feminine agreement",
        "2 · Accord masculin et féminin",
    ),
    "grammar_sentences": (
        "3 · Nominal sentences & subject–verb–object",
        "3 · Phrases nominales et sujet–verbe–objet",
    ),
    "grammar_rule": (
        "The rule · Modern Standard Arabic",
        "La règle · Arabe standard moderne",
    ),
    "pronoun_identify": ("Identify the pronoun", "Identifie le pronom"),
    "pronoun_identify_help": (
        "Read who is speaking, being addressed or being described. Choose the pronoun; pay attention to the listener’s gender.",
        "Repérez qui parle, à qui on s’adresse ou de qui on parle. Choisissez le pronom ; attention au genre de l’interlocuteur.",
    ),
    "gender_agreement": ("Choose the agreement", "Choisis l’accord"),
    "gender_agreement_help": (
        "Fill the gap with the form that matches the subject or noun. A noun’s grammatical gender matters, not just its ending.",
        "Complétez avec la forme qui s’accorde avec le sujet ou le nom. Le genre grammatical compte, pas seulement la terminaison.",
    ),
    "grammar_order": ("Arrange a simple sentence", "Ordonne une phrase simple"),
    "grammar_order_help": (
        "Build the sentence for this meaning, subject first. Use every word; do not add an ‘is’ verb to a present-tense nominal sentence.",
        "Construisez la phrase correspondant au sens, sujet d’abord. Utilisez tous les mots ; n’ajoutez pas de verbe « être » à une phrase nominale au présent.",
    ),
    "grammar_order_tiles": (
        "Tap words in Arabic reading order: subject, then predicate; or subject, verb, object. The first word appears on the right. Verb-first Arabic is possible, but this activity specifically asks for subject-first order.",
        "Touchez les mots dans l’ordre de lecture arabe : sujet puis attribut, ou sujet, verbe, objet. Le premier mot apparaît à droite. L’arabe permet le verbe d’abord, mais cette activité demande précisément le sujet d’abord.",
    ),
}
