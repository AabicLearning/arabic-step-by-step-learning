import reflex as rx
from arabic_step_by_step_learning.states.letter_data import LETTERS, POSITIONS, LETTER_COPY
from arabic_step_by_step_learning.states.letters_state import LettersState
from arabic_step_by_step_learning.states.learning_state import LearningState


def check_letter_content():
    assert len(LETTERS) == 28
    assert len({item["glyph"] for item in LETTERS}) == 28
    for item in LETTERS:
        assert all(
            item[key]
            for key in [
                "name",
                "romanization",
                "tip_en",
                "tip_fr",
                "word",
                "word_en",
                "word_fr",
                "isolated",
                "final",
            ]
        )
        assert item["joins"] == (item["glyph"] not in "ادذرزو")
        assert bool(item["initial"]) == item["joins"]
        assert bool(item["medial"]) == item["joins"]
    assert all(en and fr for en, fr in LETTER_COPY.values())


def check_letter_events():
    state = LettersState()
    for i in range(28):
        state.select_letter(i)
        assert state.current["id"] == i
        assert state.positions.contains(state.quiz_position)
        for mode in state.trace_options:
            state.choose_trace(mode)
            assert state.trace_text
        state.answer_form(state.quiz_position)
        assert state.quiz_answer == state.quiz_position
        state.next_quiz()
        assert ~state.quiz_answer
    state.select_letter(0)
    state.choose_trace("medial")
    assert state.trace_mode == "isolated"
    for game in ["find", "listen_game", "match", "odd"]:
        state.start_game(game)
        for _ in range(12):
            assert len(state.choices) == 4
            state.answer_game(state.correct_choice)
            old_score = state.score
            state.answer_game(state.correct_choice)
            assert state.score == old_score
            state.next_round()
        assert (state.score == 12) & (state.attempts == 12)
    state.start_game("memory")
    for letter_id in {card["letter_id"] for card in state.memory_cards}:
        ids = [
            card["id"]
            for card in state.memory_cards
            if card["letter_id"] == letter_id
        ]
        state.flip_card(ids[0])
        state.flip_card(ids[1])
    assert state.memory_complete & (state.score == 4)
    state.next_round()
    assert ~state.matched & ~state.flipped
    learning = LearningState()
    learning.open_module("letters")
    assert (
        (learning.active_tab == "learn")
        & learning.letters_open
        & ~learning.modal
    )
    learning.navigate("home")
    assert ~learning.letters_open


if __name__ == "__main__":
    check_letter_content()
    check_letter_events()
    print(
        "Letter content, exercises, game rounds and navigation checks passed."
    )
