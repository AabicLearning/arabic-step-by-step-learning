import reflex as rx

from scripts.generate_arabic_audio import generate_audio
from arabic_step_by_step_learning.brand_assets import generate_brand_icons
from arabic_step_by_step_learning.pwa_assets import generate_pwa_assets
from arabic_step_by_step_learning.components.home import home_shell
from arabic_step_by_step_learning.components.onboarding import onboarding
from arabic_step_by_step_learning.states.learning_state import LearningState


generate_audio()
generate_brand_icons()
generate_pwa_assets()


def index() -> rx.Component:
    return rx.el.div(
        rx.cond(
            LearningState.is_hydrated,
            rx.cond(
                LearningState.setup_done == "yes", home_shell(), onboarding()
            ),
            rx.el.div(
                rx.icon(
                    "book-open",
                    class_name="size-8 animate-pulse text-[#397F78]",
                ),
                rx.el.div(
                    class_name="mt-6 h-3 w-40 animate-pulse rounded-full bg-[#D6E3D9]"
                ),
                class_name="flex min-h-dvh flex-col items-center justify-center bg-[#F7F5EF]",
            ),
        ),
        class_name="font-['Inter'] text-[#192B3A] selection:bg-[#397F78]/20",
    )


app = rx.App(
    theme=rx.theme(appearance="light"),
    head_components=[
        rx.el.meta(name="referrer", content="no-referrer"),
        rx.el.meta(name="theme-color", content="#397F78"),
        rx.el.meta(name="apple-mobile-web-app-capable", content="yes"),
        rx.el.meta(
            name="apple-mobile-web-app-status-bar-style", content="default"
        ),
        rx.el.meta(
            name="apple-mobile-web-app-title", content="Arabic Step by Step"
        ),
        rx.el.link(rel="manifest", href="/manifest.webmanifest"),
        rx.script(src="/pwa.js"),
        rx.el.link(rel="preconnect", href="https://fonts.googleapis.com"),
        rx.el.link(
            rel="preconnect",
            href="https://fonts.gstatic.com",
            cross_origin="",
        ),
        rx.el.link(
            href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Noto+Naskh+Arabic:wght@400;500;600&display=swap",
            rel="stylesheet",
        ),
        rx.el.link(
            rel="icon",
            type="image/x-icon",
            href=rx.asset("favicon.ico"),
        ),
        rx.el.link(
            rel="apple-touch-icon",
            sizes="180x180",
            href=rx.asset("apple-touch-icon.png"),
        ),
    ],
)
app.add_page(
    index, route="/", title="Arabic · Step by Step", on_load=LearningState.load
)
