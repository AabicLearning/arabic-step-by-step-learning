import reflex as rx
import asyncio
import itertools
import json
from unittest.mock import patch, AsyncMock

from arabic_step_by_step_learning.states.learning_state import LearningState
from arabic_step_by_step_learning.states.letters_state import LettersState


def check_placement():
    for outcomes in itertools.product(
        ("correct", "incorrect", "unknown"), repeat=3
    ):
        state = LearningState()
        state.language = "en"
        state.nickname = "Alex"
        original_progress = state.progress_json
        LearningState.save_nickname.fn(state, {"nickname": "Alex"})
        for outcome in outcomes:
            question = state.current_question
            answer = (
                question["answer"]
                if outcome == "correct"
                else "unknown"
                if outcome == "unknown"
                else next(
                    question[key]
                    for key in ("a", "b", "c")
                    if question[key] != question["answer"]
                )
            )
            LearningState.answer_question.fn(state, answer)
            LearningState.answer_question.fn(state, "unknown")
            LearningState.next_question.fn(state)
        count = outcomes.count("correct")
        expected_index = next(
            (
                index
                for index, outcome in zip((0, 1, 23), outcomes)
                if outcome != "correct"
            ),
            2,
        )
        assert state.stage == "result"
        assert state.placement_answers == list(outcomes)
        assert state.placement_data["result"] == (
            "familiar" if count >= 2 else "complete"
        )
        assert state.recommended_letter["id"] == expected_index
        assert (state.progress_json == original_progress) & (state.stars == 0)
        assert state._available("games") and state._available("harakat")
        refreshed = LearningState()
        refreshed.placement_json = state.placement_json
        for language in ("en", "fr"):
            refreshed.language = language
            assert refreshed.placement_recognized == count
            assert refreshed.recommended_letter["id"] == expected_index
            assert refreshed.placement_label and refreshed.placement_description
        LearningState.go_back.fn(state)
        assert (state.stage == "check") & (
            state.placement_answers == ["", "", ""]
        )
        LearningState.answer_question.fn(
            state, state.current_question["answer"]
        )
        LearningState.next_question.fn(state)
        LearningState.skip_check.fn(state)
        assert state.placement_data["skipped"]
        assert state.placement_answers == ["", "", ""]
        assert state.recommended_letter["id"] == 0
        assert state.progress_json == original_progress
    legacy = LearningState()
    assert legacy.recommended_letter["id"] == 0
    for invalid in (
        "null",
        "[]",
        json.dumps({"result": "familiar", "answers": [], "next_index": 99}),
    ):
        legacy.placement_json = invalid
        assert legacy.recommended_letter["id"] == 0


async def check_recommended_navigation():
    state = LearningState()
    letters = LettersState()
    state.placement_answers = ["correct", "correct", "unknown"]
    state._save_placement()
    original_progress = state.progress_json
    with patch.object(
        LearningState, "get_state", new=AsyncMock(return_value=letters)
    ):
        await LearningState.open_recommended_letter.fn(state)
    assert letters.selected == 23
    assert (state.active_tab == "learn") & state.letters_open
    assert ~state.education_open & (state.chosen_module == "letters")
    assert (state.progress_json == original_progress) & (state.stars == 0)
    LearningState.back_to_path.fn(state)
    assert ~state.letters_open & (state.active_tab == "learn")
    LearningState.navigate.fn(state, "home")
    assert state.active_tab == "home"


if __name__ == "__main__":
    check_placement()
    asyncio.run(check_recommended_navigation())
    print(
        "Placement outcomes, storage fallback, skip/restart and lesson navigation checks passed."
    )
