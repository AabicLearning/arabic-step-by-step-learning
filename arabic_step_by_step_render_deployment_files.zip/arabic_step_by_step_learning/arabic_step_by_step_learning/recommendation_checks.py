import reflex as rx
import asyncio
import json

from arabic_step_by_step_learning.states.learning_state import LearningState
from arabic_step_by_step_learning.states.letters_state import LettersState
from arabic_step_by_step_learning.states.letter_data import LETTERS


def check_copy(state: LearningState, count: int):
    for language in ("en", "fr"):
        LearningState.choose_language.fn(state, language)
        text = state.copy
        if count == 0:
            assert text["next_step"] == (
                "VOTRE PREMIER PAS" if language == "fr" else "YOUR FIRST STEP"
            )
            assert state.placement_description
            assert (
                "départ" in text["suggestion_short"]
                if language == "fr"
                else "starting suggestion" in text["suggestion_short"]
            )
        elif count < len(LETTERS):
            assert text["letters_continue_tag"] == (
                "VOTRE PROCHAIN PAS" if language == "fr" else "YOUR NEXT STEP"
            )
            description = f"{text['letters_continue_desc']} {state.recommended_letter['romanization']}."
            hint = text["letters_continue_hint"]
            assert state.recommended_letter["romanization"] in description
            assert (
                "enregistrées" in description
                if language == "fr"
                else "saved" in description
            )
            assert (
                "étoiles" in hint
                if language == "fr"
                else "earned stars" in hint
            )
            assert (
                "badges" in hint
                and "unlocks" not in hint
                and "déblocages" not in hint
            )
            for forbidden in (
                "YOUR FIRST STEP",
                "starting suggestion",
                "placement",
                "PREMIER PAS",
                "suggestion de départ",
                "Commencez",
            ):
                assert (
                    forbidden
                    not in f"{text['letters_continue_tag']} {description} {hint}"
                )
        else:
            for key in (
                "letters_review_tag",
                "letters_review_title",
                "letters_review_desc",
                "letters_review_letter",
                "letters_review_hint",
                "letters_review_cta",
            ):
                assert text[key]
            assert "28" in text["letters_review_desc"]
            assert text["letters_review_cta"] == (
                "Réviser" if language == "fr" else "Review"
            )


async def check_recommendations():
    # Each scenario owns an in-memory state tree, never a learner's stored data.
    for start in (0, 2, 23, 27):
        root = rx.State(_reflex_internal_init=True)
        state = await root.get_state(LearningState)
        letters = await root.get_state(LettersState)
        assert await letters.get_state(LearningState) is state
        state.placement_json = json.dumps(
            {
                "answers": ["correct", "correct", "correct"],
                "result": "familiar",
                "next_index": start,
                "skipped": False,
            }
        )
        placement = state.placement_json
        order = [
            (start + offset) % len(LETTERS) for offset in range(len(LETTERS))
        ]
        for count in range(len(LETTERS) + 1):
            expected = LETTERS[order[count] if count < len(LETTERS) else start][
                "id"
            ]
            assert state.recommended_letter["id"] == expected
            assert state.has_letter_progress == (count > 0)
            assert state.letters_all_complete == (count == len(LETTERS))
            assert state._count("letters") == count
            check_copy(state, count)
            progress = state.progress_json
            stars = state.stars
            availability = [module["available"] for module in state.modules]
            assert all(availability)
            for language in ("en", "fr"):
                LearningState.choose_language.fn(state, language)
                LearningState.navigate.fn(state, "home")
                await LearningState.open_recommended_letter.fn(state)
                assert letters.selected == expected
                assert letters.current == state.recommended_letter
                assert state.active_tab == "learn" and state.letters_open
                assert (
                    not state.education_open
                    and state.chosen_module == "letters"
                )
                assert state.modal == ""
                assert state.progress_json == progress and state.stars == stars
                assert [
                    module["available"] for module in state.modules
                ] == availability
                assert state.placement_json == placement
            refreshed = LearningState()
            refreshed.placement_json = placement
            refreshed.progress_json = progress
            assert refreshed.recommended_letter["id"] == expected
            assert refreshed.has_letter_progress == state.has_letter_progress
            assert refreshed.letters_all_complete == state.letters_all_complete
            if count < len(LETTERS):
                await LettersState.complete_lesson.fn(letters)
                assert (
                    f"letters:{str(expected)}" in state.progress_data["lessons"]
                )
                assert state._count("letters") == count + 1
                saved = state.progress_json
                await LettersState.complete_lesson.fn(letters)
                assert state.progress_json == saved
            else:
                await LettersState.complete_lesson.fn(letters)
                assert state.progress_json == progress and state.stars == stars
            assert state.placement_json == placement

    state = LearningState()
    assert not state.has_letter_progress and not state.letters_all_complete
    check_copy(state, 0)
    assert state.placement_description == state.copy["placement_skipped"]
    state._record("letters", "1", lesson=True)
    assert state.has_letter_progress
    check_copy(state, 1)
    state.progress_json = json.dumps(
        {
            "lessons": ["letters:0", "letters:0", "writing:1", "letters:99"],
            "exercises": ["letters:1"],
            "modules": ["letters"],
        }
    )
    assert state.recommended_letter["id"] == 1
    assert state.has_letter_progress and not state.letters_all_complete
    assert state._count("letters") == 1
    state.placement_json = "null"
    assert state.recommended_letter["id"] == 1
    state.progress_json = json.dumps({"lessons": "invalid"})
    assert state.recommended_letter["id"] == 0
    assert not state.has_letter_progress and not state.letters_all_complete
    state.progress_json = json.dumps(
        {"lessons": ["writing:1", "letters:99"], "exercises": ["letters:1"]}
    )
    assert not state.has_letter_progress


if __name__ == "__main__":
    asyncio.run(check_recommendations())
    print(
        "Recommendation advancement, wraparound, review, persistence and navigation checks passed."
    )
