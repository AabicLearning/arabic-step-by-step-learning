import reflex as rx

import logging
from pathlib import Path

from PIL import Image, ImageDraw


def generate_brand_icons() -> None:
    assets_dir = Path(__file__).resolve().parent.parent / "assets"
    source_path = assets_dir / "arabic-step-user-logo.jpg"
    favicon_path = assets_dir / "favicon.ico"
    apple_icon_path = assets_dir / "apple-touch-icon.png"
    try:
        if not source_path.is_file():
            return
        with Image.open(source_path) as source:
            image = source.convert("RGB")
            side = min(image.size)
            left = (image.width - side) // 2
            top = (image.height - side) // 2
            artwork = image.crop((left, top, left + side, top + side))
            artwork = artwork.resize(
                (1024, 1024), Image.Resampling.LANCZOS
            ).convert("RGBA")

        mask = Image.new("L", (1024, 1024), 0)
        ImageDraw.Draw(mask).ellipse((1, 1, 1022, 1022), fill=255)
        artwork.putalpha(mask)

        for icon_size in (192, 512):
            app_icon = artwork.resize(
                (icon_size, icon_size), Image.Resampling.LANCZOS
            )
            app_icon.save(
                assets_dir / f"app-icon-{icon_size}.png",
                format="PNG",
                optimize=True,
            )

        apple_icon = artwork.resize((180, 180), Image.Resampling.LANCZOS)
        apple_icon.save(apple_icon_path, format="PNG", optimize=True)
        artwork.save(
            favicon_path,
            format="ICO",
            sizes=[
                (16, 16),
                (32, 32),
                (48, 48),
                (64, 64),
                (128, 128),
                (256, 256),
            ],
        )
    except (OSError, ValueError) as e:
        logging.exception(f"Error: {e}")
        return
