import reflex as rx

from arabic_step_by_step_learning.states.learning_state import LearningState as S, ModuleData
from arabic_step_by_step_learning.components.onboarding import language_choices, nickname_form
from arabic_step_by_step_learning.components.pwa import installation_settings
from arabic_step_by_step_learning.components.letters import letter_path, letter_games
from arabic_step_by_step_learning.components.letter_browser import browser_tools
from arabic_step_by_step_learning.components.progress import (
    progress_view,
    daily_dialog,
    reset_dialog,
    personalization_settings,
    review_card,
    review_dialog,
)
from arabic_step_by_step_learning.components.education import (
    education_path,
    education_games,
    game_module_selector,
)


NAV: list[dict[str, str]] = [
    {"key": "home", "icon": "house"},
    {"key": "learn", "icon": "book-open"},
    {"key": "games", "icon": "shapes"},
    {"key": "progress", "icon": "chart-no-axes-column-increasing"},
    {"key": "settings", "icon": "settings-2"},
]


def nav_item(item: dict[str, str]) -> rx.Component:
    return rx.el.button(
        rx.icon(item["icon"], class_name="size-5 shrink-0"),
        rx.el.span(
            S.copy[item["key"]], class_name="text-[10px] sm:text-xs md:text-sm"
        ),
        on_click=S.navigate(item["key"]),
        aria_current=rx.cond(S.active_tab == item["key"], "page", "false"),
        class_name=rx.cond(
            S.active_tab == item["key"],
            "flex flex-1 flex-col items-center justify-center gap-1.5 rounded-xl bg-[#EAF1ED] px-1 py-2 font-semibold text-[#397F78] transition-colors md:flex-none md:flex-row md:gap-2 md:px-4 md:py-2.5",
            "flex flex-1 flex-col items-center justify-center gap-1.5 rounded-xl bg-transparent px-1 py-2 font-medium text-[#68767B] hover:bg-[#EAF1ED]/60 hover:text-[#397F78] transition-colors md:flex-none md:flex-row md:gap-2 md:px-4 md:py-2.5",
        ),
    )


def header() -> rx.Component:
    return rx.el.header(
        rx.el.div(
            rx.el.button(
                rx.image(
                    src=rx.asset("arabic-step-user-logo.jpg"),
                    alt="Arabic Step by Step logo",
                    class_name="size-10 rounded-full object-cover",
                ),
                rx.el.div(
                    rx.el.p(
                        S.copy["brand"],
                        class_name="text-sm font-semibold tracking-tight text-[#192B3A] lg:text-base",
                    ),
                    rx.el.p(
                        S.copy["tagline"],
                        class_name="mt-0.5 hidden text-[10px] text-[#68767B] lg:block",
                    ),
                ),
                on_click=S.navigate("home"),
                class_name="flex items-center gap-3 text-left",
            ),
            rx.el.nav(
                rx.foreach(NAV, nav_item),
                aria_label=S.copy["view_path"],
                class_name="hidden items-center gap-1 md:flex",
            ),
            rx.el.button(
                rx.el.span(
                    rx.cond(S.language == "fr", "FR", "EN"),
                    class_name="mr-3 hidden text-xs font-medium text-[#68767B] lg:block",
                ),
                rx.el.div(
                    rx.icon("user-round", class_name="size-5 text-[#397F78]"),
                    class_name="flex size-10 items-center justify-center rounded-full bg-[#EAF1ED]",
                ),
                on_click=S.navigate("settings"),
                aria_label=S.copy["settings"],
                class_name="flex items-center",
            ),
            class_name="mx-auto flex w-full max-w-[1440px] items-center justify-between gap-3 px-5 py-5 sm:px-8 lg:px-12",
        ),
        class_name="shrink-0 border-b border-[#E0E2D9] bg-[#F7F5EF]",
    )


def page_heading(eyebrow: str, title: str, description: str) -> rx.Component:
    return rx.el.div(
        rx.el.p(
            S.copy[eyebrow],
            class_name="mb-3 text-[11px] font-semibold uppercase tracking-[0.18em] text-[#397F78]",
        ),
        rx.el.h1(
            S.copy[title],
            class_name="text-3xl font-semibold leading-tight tracking-[-0.035em] text-[#192B3A] sm:text-4xl",
        ),
        rx.el.p(
            S.copy[description],
            class_name="mt-3 max-w-2xl text-sm leading-7 text-[#68767B]",
        ),
        class_name="mb-8",
    )


def metric(label: str, value: str, hint: str, icon: str) -> rx.Component:
    return rx.el.div(
        rx.el.div(
            rx.el.span(
                S.copy[label], class_name="text-xs font-medium text-[#68767B]"
            ),
            rx.icon(icon, class_name="size-4 text-[#397F78]"),
            class_name="flex items-center justify-between gap-2",
        ),
        rx.el.p(
            value,
            class_name="mt-3 text-xl font-semibold tracking-tight text-[#192B3A] sm:text-2xl",
        ),
        rx.el.p(
            S.copy[hint], class_name="mt-2 text-[11px] leading-5 text-[#68767B]"
        ),
        class_name="w-full rounded-2xl border border-[#E0E2D9] bg-white/70 p-4 sm:p-5",
    )


def metrics() -> rx.Component:
    return rx.el.div(
        metric("level", S.level_name, "foundations", "sprout"),
        metric(
            "total_progress",
            f"{S.overall_percent}%",
            "completed",
            "chart-no-axes-combined",
        ),
        metric("stars", S.stars.to_string(), "stars_hint", "star"),
        metric("streak", S.streak.to_string(), "streak_hint", "flame"),
        class_name="mb-8 grid w-full grid-cols-2 gap-3 lg:grid-cols-4 lg:gap-4",
    )


def first_step() -> rx.Component:
    return rx.el.section(
        rx.el.div(
            rx.el.p(
                rx.cond(
                    S.letters_all_complete,
                    S.copy["letters_review_tag"],
                    rx.cond(
                        S.has_letter_progress,
                        S.copy["letters_continue_tag"],
                        S.copy["next_step"],
                    ),
                ),
                class_name="text-[10px] font-semibold tracking-[0.18em] text-[#A4C9BF]",
            ),
            rx.el.h2(
                rx.cond(
                    S.letters_all_complete,
                    S.copy["letters_review_title"],
                    S.copy["letters_title"],
                ),
                class_name="mt-4 max-w-md text-2xl leading-snug font-semibold tracking-tight text-[#F7F5EF] sm:text-3xl",
            ),
            rx.el.p(
                rx.cond(
                    S.letters_all_complete,
                    S.copy["letters_review_desc"],
                    rx.cond(
                        S.has_letter_progress,
                        f"{S.copy['letters_continue_desc']} {S.recommended_letter['romanization']}.",
                        S.placement_description,
                    ),
                ),
                class_name="mt-4 max-w-md text-sm leading-7 text-[#C4D0D1]",
            ),
            rx.el.div(
                rx.el.p(
                    rx.cond(
                        S.letters_all_complete,
                        S.copy["letters_review_letter"],
                        S.copy["recommended_letter"],
                    ),
                    class_name="text-xs font-medium text-[#A4C9BF]",
                ),
                rx.el.div(
                    rx.el.span(
                        S.recommended_letter["glyph"],
                        dir="rtl",
                        lang="ar",
                        class_name="font-['Noto_Naskh_Arabic'] text-5xl leading-normal text-[#A4C9BF]",
                    ),
                    rx.el.span(
                        S.recommended_letter["romanization"],
                        class_name="text-xl font-semibold text-[#F7F5EF]",
                    ),
                    class_name="mt-2 flex items-center gap-4",
                ),
                rx.cond(
                    (~S.has_letter_progress) & (~S.placement_data["skipped"]),
                    rx.el.p(
                        S.placement_label,
                        class_name="mt-2 text-xs font-medium text-[#A4C9BF]",
                    ),
                ),
                rx.el.p(
                    rx.cond(
                        S.letters_all_complete,
                        S.copy["letters_review_hint"],
                        rx.cond(
                            S.has_letter_progress,
                            S.copy["letters_continue_hint"],
                            S.copy["suggestion_short"],
                        ),
                    ),
                    class_name="mt-3 max-w-md text-xs leading-6 text-[#C4D0D1]",
                ),
                class_name="mt-5 border-t border-[#A4C9BF]/20 pt-5",
            ),
            rx.el.div(
                rx.el.span(
                    rx.icon("book-open", class_name="size-3.5"),
                    S.copy["letters_count"],
                    class_name="flex items-center gap-2",
                ),
                rx.el.span(
                    rx.icon("leaf", class_name="size-3.5"),
                    S.copy["at_your_pace"],
                    class_name="flex items-center gap-2",
                ),
                class_name="mt-5 flex flex-wrap gap-5 text-xs text-[#C4D0D1]",
            ),
            rx.el.button(
                rx.cond(
                    S.letters_all_complete,
                    f"{S.copy['letters_review_cta']} {S.recommended_letter['romanization']}",
                    f"{S.copy['open_recommended']} {S.recommended_letter['romanization']}",
                ),
                rx.icon("arrow-right", class_name="size-4"),
                on_click=S.open_recommended_letter,
                class_name="mt-7 flex w-fit items-center gap-3 rounded-xl bg-[#F7F5EF] px-5 py-3.5 text-sm font-semibold text-[#192B3A] hover:bg-[#EAF1ED] transition-colors",
            ),
            class_name="relative z-10 flex-1",
        ),
        rx.el.div(
            rx.el.p(
                "أ ب ت",
                dir="rtl",
                lang="ar",
                class_name="font-['Noto_Naskh_Arabic'] text-[72px] leading-relaxed text-[#A4C9BF] sm:text-[90px]",
            ),
            rx.el.div(class_name="mx-auto mt-2 h-px w-16 bg-[#A4C9BF]/30"),
            rx.el.p(
                "اَلْعَرَبِيَّة",
                dir="rtl",
                lang="ar",
                class_name="mt-3 font-['Noto_Naskh_Arabic'] text-2xl text-[#C4D0D1]",
            ),
            class_name="hidden w-48 shrink-0 flex-col justify-center text-center sm:flex xl:w-52",
        ),
        class_name="flex h-full items-center gap-4 overflow-hidden rounded-3xl bg-[#192B3A] p-6 sm:p-8",
    )


def daily_card() -> rx.Component:
    return rx.el.section(
        rx.el.div(
            rx.icon("sun", class_name="size-6 text-[#397F78]"),
            rx.el.span(
                S.copy["daily_tag"],
                class_name="text-[10px] font-medium text-[#397F78]",
            ),
            class_name="flex items-center justify-between gap-2",
        ),
        rx.el.h2(
            S.copy["daily_title"],
            class_name="mt-5 text-xl font-semibold tracking-tight text-[#192B3A]",
        ),
        rx.el.p(
            S.copy["daily_desc"],
            class_name="mt-3 text-sm leading-7 text-[#68767B]",
        ),
        rx.el.div(
            rx.foreach(
                ["scan-eye", "scan-eye", "ear", "message-circle", "hash"],
                lambda icon: rx.el.div(
                    rx.icon(icon, class_name="size-4 text-[#397F78]"),
                    class_name="flex size-10 items-center justify-center rounded-full border border-[#397F78]/20 bg-[#F7F5EF]",
                ),
            ),
            class_name="my-6 flex gap-2",
        ),
        rx.el.button(
            S.copy["daily_button"],
            rx.icon("arrow-up-right", class_name="size-4"),
            on_click=S.open_daily,
            class_name="mt-auto flex w-full items-center justify-between gap-2 border-t border-[#397F78]/20 pt-5 text-sm font-semibold text-[#397F78] hover:text-[#192B3A]",
        ),
        class_name="flex h-full flex-col rounded-3xl border border-[#D6E3D9] bg-[#EAF1ED] p-6 sm:p-7",
    )


def module_card(module: ModuleData) -> rx.Component:
    return rx.el.button(
        rx.el.div(
            rx.el.span(
                module["number"],
                class_name="text-[10px] font-medium tracking-wider text-[#84908E]",
            ),
            rx.el.span(
                rx.icon("sparkles", class_name="size-3"),
                rx.cond(
                    module["id"] == "letters",
                    S.copy["available"],
                    rx.cond(
                        module["id"] == "games",
                        S.copy["games"],
                        S.copy["lesson_view"],
                    ),
                ),
                class_name="flex w-fit items-center gap-1 rounded-full bg-[#EAF1ED] px-2.5 py-1 text-[10px] font-semibold text-[#397F78]",
            ),
            class_name="flex items-center justify-between",
        ),
        rx.el.p(
            module["arabic"],
            dir="rtl",
            lang="ar",
            class_name="my-3 min-h-14 text-center font-['Noto_Naskh_Arabic'] text-4xl leading-relaxed text-[#397F78]",
        ),
        rx.el.h3(
            module["title"], class_name="text-sm font-semibold text-[#192B3A]"
        ),
        rx.el.p(
            module["description"],
            class_name="mt-2 min-h-10 text-xs leading-5 text-[#68767B]",
        ),
        rx.el.div(
            rx.el.progress(
                value=module["done"],
                max=module["total"],
                aria_label=module["title"],
                class_name="mt-4 h-1 w-full overflow-hidden rounded-full bg-[#E3E9E1] accent-[#397F78] [&::-webkit-progress-bar]:bg-[#E3E9E1] [&::-webkit-progress-value]:bg-[#397F78] [&::-moz-progress-bar]:bg-[#397F78]",
            ),
            rx.el.div(
                rx.el.span(
                    f"{module['done']} / {module['total']} · {module['percent']}%",
                    class_name="text-[10px] text-[#68767B]",
                ),
                rx.icon("arrow-right", class_name="size-4 text-[#397F78]"),
                class_name="mt-2 flex items-center justify-between",
            ),
        ),
        on_click=S.open_module(module["id"]),
        class_name="group w-full rounded-2xl border border-[#A9C6BA] bg-white p-5 text-left transition-colors hover:border-[#397F78] hover:bg-[#FAFCF9] focus-visible:outline-2 focus-visible:outline-[#397F78]",
    )


def learning_path() -> rx.Component:
    return rx.el.section(
        rx.el.div(
            rx.el.div(
                rx.el.h2(
                    S.copy["path_title"],
                    class_name="text-xl font-semibold tracking-tight text-[#192B3A]",
                ),
                rx.el.p(
                    S.copy["path_desc"],
                    class_name="mt-2 text-xs leading-6 text-[#68767B]",
                ),
            ),
            rx.el.span(
                S.copy["eight_modules"],
                class_name="hidden shrink-0 text-xs text-[#68767B] sm:block",
            ),
            class_name="mb-5 flex items-center justify-between gap-4",
        ),
        rx.el.div(
            rx.foreach(S.modules, module_card),
            class_name="grid grid-cols-1 gap-4 min-[400px]:grid-cols-2 xl:grid-cols-4",
        ),
        class_name="mt-9",
    )


def dashboard_home() -> rx.Component:
    return rx.el.div(
        rx.el.div(
            rx.el.div(
                rx.el.p(
                    S.copy["welcome_back"],
                    class_name="mb-3 text-[10px] font-semibold tracking-[0.18em] text-[#397F78]",
                ),
                rx.el.h1(
                    f"{S.copy['hello']}, {S.nickname}.",
                    class_name="text-3xl font-semibold tracking-[-0.035em] text-[#192B3A] sm:text-4xl",
                ),
                rx.el.p(
                    S.copy["home_desc"],
                    class_name="mt-3 text-sm leading-7 text-[#68767B]",
                ),
            ),
            rx.el.div(
                rx.el.p(
                    "مرحبًا",
                    dir="rtl",
                    lang="ar",
                    class_name="font-['Noto_Naskh_Arabic'] text-5xl leading-normal text-[#397F78]",
                ),
                rx.el.p(
                    S.copy["greeting_meaning"],
                    class_name="mt-1 text-[10px] uppercase tracking-wider text-[#84908E]",
                ),
                class_name="hidden shrink-0 text-center lg:block",
            ),
            class_name="mb-8 flex items-center justify-between gap-5",
        ),
        metrics(),
        rx.el.div(
            first_step(),
            daily_card(),
            class_name="grid grid-cols-1 gap-5 lg:grid-cols-[1.8fr_1fr]",
        ),
        review_card(),
        learning_path(),
    )


def settings_view() -> rx.Component:
    return rx.el.div(
        page_heading("settings", "settings_title", "settings_desc"),
        rx.el.div(
            rx.el.section(
                rx.el.div(
                    rx.icon("user-round", class_name="size-5 text-[#397F78]"),
                    rx.el.h2(
                        S.copy["profile"],
                        class_name="text-base font-semibold text-[#192B3A]",
                    ),
                    class_name="mb-6 flex items-center gap-3",
                ),
                nickname_form(True),
                class_name="rounded-3xl border border-[#E0E2D9] bg-white/70 p-6 sm:p-8",
            ),
            rx.el.section(
                rx.el.div(
                    rx.icon("languages", class_name="size-5 text-[#397F78]"),
                    rx.el.h2(
                        S.copy["interface_language"],
                        class_name="text-base font-semibold text-[#192B3A]",
                    ),
                    class_name="mb-6 flex items-center gap-3",
                ),
                language_choices(),
                rx.el.p(
                    S.copy["change_later"],
                    class_name="mt-5 text-xs leading-6 text-[#68767B]",
                ),
                class_name="rounded-3xl border border-[#E0E2D9] bg-white/70 p-6 sm:p-8",
            ),
            class_name="grid grid-cols-1 items-start gap-5 lg:grid-cols-2",
        ),
        personalization_settings(),
        installation_settings(),
        rx.el.a(
            "Support Us ☕ ادعمنا",
            href="https://ko-fi.com/arabiclearning",
            target="_blank",
            rel="noopener noreferrer",
            class_name="mt-5 flex min-h-14 w-full items-center justify-center rounded-2xl bg-[#F59E0B] px-6 py-4 text-center text-base font-semibold text-[#192B3A] transition-colors hover:bg-[#FBBF24] focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#192B3A]",
        ),
        rx.el.p(
            "Your support helps us add more Arabic lessons for kids",
            class_name="mt-2 text-center text-xs leading-5 text-[#84908E]",
        ),
        rx.el.section(
            rx.icon(
                "shield-check", class_name="size-6 shrink-0 text-[#397F78]"
            ),
            rx.el.div(
                rx.el.h2(
                    S.copy["about_title"],
                    class_name="text-base font-semibold text-[#192B3A]",
                ),
                rx.el.p(
                    S.copy["about_desc"],
                    class_name="mt-2 max-w-3xl text-sm leading-7 text-[#68767B]",
                ),
            ),
            class_name="mt-5 flex gap-4 rounded-3xl border border-[#D6E3D9] bg-[#EAF1ED] p-6 sm:p-8",
        ),
    )


def module_details() -> rx.Component:
    return rx.el.div(
        rx.el.div(
            rx.icon("book-open", class_name="size-6 text-[#397F78]"),
            class_name="mb-5 flex size-12 items-center justify-center rounded-xl bg-[#EAF1ED]",
        ),
        rx.el.h2(
            S.selected_module["title"],
            id="modal-title",
            class_name="pr-8 text-2xl font-semibold tracking-tight text-[#192B3A]",
        ),
        rx.el.p(
            S.selected_module["description"],
            class_name="mt-3 text-sm leading-7 text-[#68767B]",
        ),
        rx.el.p(
            S.copy["activities_access"],
            class_name="mt-5 rounded-xl bg-[#EAF1ED] p-4 text-sm font-medium text-[#397F78]",
        ),
        rx.el.p(
            S.copy["future_note"],
            class_name="mt-5 text-sm leading-7 text-[#68767B]",
        ),
    )


def preview_dialog() -> rx.Component:
    return rx.cond(
        S.modal != "",
        rx.el.div(
            rx.el.button(
                on_click=S.close_modal,
                aria_label=S.copy["close"],
                tab_index=-1,
                class_name="absolute inset-0 h-full w-full cursor-default bg-[#192B3A]/40",
            ),
            rx.el.section(
                rx.el.button(
                    rx.icon("x", class_name="size-5"),
                    on_click=S.close_modal,
                    aria_label=S.copy["close"],
                    class_name="absolute right-5 top-5 rounded-full bg-[#F7F5EF] p-2 text-[#68767B] hover:text-[#192B3A]",
                ),
                rx.match(
                    S.modal,
                    ("daily", daily_dialog()),
                    ("reset", reset_dialog()),
                    ("review", review_dialog()),
                    module_details(),
                ),
                rx.cond(
                    S.modal != "review",
                    rx.el.button(
                        S.copy["return_path"],
                        rx.icon("arrow-right", class_name="size-4"),
                        on_click=[S.close_modal, S.navigate("learn")],
                        class_name="mt-6 flex w-full items-center justify-center gap-3 rounded-xl bg-[#397F78] px-4 py-3.5 text-sm font-semibold text-white hover:bg-[#2E6862]",
                    ),
                ),
                role="dialog",
                aria_modal=True,
                aria_labelledby="modal-title",
                class_name="relative z-10 max-h-[85dvh] w-full max-w-xl overflow-y-auto rounded-3xl border border-[#E0E2D9] bg-white p-6 sm:p-8",
            ),
            class_name="fixed inset-0 z-50 flex items-center justify-center p-4",
        ),
    )


def support_dialog() -> rx.Component:
    return rx.cond(
        S.support_popup_open,
        rx.el.div(
            rx.el.div(
                class_name="absolute inset-0 bg-[#192B3A]/55",
            ),
            rx.el.section(
                rx.el.div(
                    rx.icon(
                        "heart-handshake",
                        class_name="size-6 text-[#397F78]",
                    ),
                    class_name="mb-5 flex size-12 items-center justify-center rounded-2xl bg-[#EAF1ED]",
                ),
                rx.el.h2(
                    rx.cond(
                        S.language == "fr",
                        "Aidez-nous à continuer 🌙",
                        "Help us continue 🌙",
                    ),
                    id="support-dialog-title",
                    class_name="text-2xl font-semibold leading-tight tracking-tight text-[#192B3A] sm:text-3xl",
                ),
                rx.el.p(
                    rx.cond(
                        S.language == "fr",
                        "Vous utilisez l'app depuis 15 jours, Alhamdoulilah! Pour nous aider à continuer le développement, vous pouvez nous soutenir à partir de 2€ minimum, plus si vous pouvez. Merci pour votre aide!",
                        "You've been using the app for 15 days, Alhamdulilah! To help us continue developing, you can support us from just 2€ minimum, more if you can. Thank you for your help!",
                    ),
                    id="support-dialog-description",
                    class_name="mt-4 text-sm leading-7 text-[#68767B] sm:text-base",
                ),
                rx.el.div(
                    rx.el.a(
                        rx.cond(
                            S.language == "fr",
                            "Soutenir à partir de 2€ ☕",
                            "Support from 2€ ☕",
                        ),
                        href="https://ko-fi.com/arabiclearning",
                        target="_blank",
                        rel="noopener noreferrer",
                        on_click=S.dismiss_support_popup,
                        class_name="flex min-h-12 w-full items-center justify-center rounded-xl bg-[#397F78] px-4 py-3 text-center text-sm font-semibold text-white transition-colors hover:bg-[#2E6862] focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#397F78]",
                    ),
                    rx.el.button(
                        rx.cond(
                            S.language == "fr",
                            "Plus tard",
                            "Later",
                        ),
                        on_click=S.dismiss_support_popup,
                        class_name="flex min-h-12 w-full items-center justify-center rounded-xl border border-[#DCDDD4] bg-transparent px-4 py-3 text-sm font-semibold text-[#68767B] transition-colors hover:bg-[#F7F5EF] hover:text-[#192B3A] focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#397F78]",
                    ),
                    class_name="mt-7 flex flex-col gap-3 sm:flex-row-reverse",
                ),
                role="dialog",
                aria_modal=True,
                aria_labelledby="support-dialog-title",
                aria_describedby="support-dialog-description",
                class_name="relative z-10 max-h-[85dvh] w-full max-w-lg overflow-y-auto rounded-3xl border border-[#E0E2D9] bg-[#F7F5EF] p-6 sm:p-8",
            ),
            class_name="fixed inset-0 z-[60] flex items-center justify-center overflow-y-auto p-4 sm:p-6",
        ),
    )


def home_shell() -> rx.Component:
    return rx.el.div(
        header(),
        rx.el.main(
            rx.el.div(
                rx.cond(
                    S.notice_key == "storage_error",
                    rx.el.p(
                        S.copy["storage_error"],
                        role="alert",
                        class_name="mb-5 rounded-xl bg-red-100 p-4 text-sm text-red-600",
                    ),
                ),
                rx.match(
                    S.active_tab,
                    ("home", dashboard_home()),
                    (
                        "learn",
                        rx.cond(
                            S.letters_open,
                            letter_path(),
                            rx.cond(
                                S.education_open,
                                education_path(),
                                rx.el.div(
                                    page_heading(
                                        "learn", "learn_title", "learn_desc"
                                    ),
                                    rx.el.p(
                                        S.copy["activities_access"],
                                        class_name="mb-6 rounded-xl bg-[#EAF1ED] p-4 text-sm leading-7 text-[#397F78]",
                                    ),
                                    first_step(),
                                    learning_path(),
                                ),
                            ),
                        ),
                    ),
                    (
                        "games",
                        rx.el.div(
                            game_module_selector(),
                            rx.cond(
                                S.game_module == "letters",
                                letter_games(),
                                education_games(),
                            ),
                        ),
                    ),
                    (
                        "progress",
                        rx.el.div(
                            page_heading(
                                "progress", "progress_title", "progress_desc"
                            ),
                            metrics(),
                            progress_view(),
                        ),
                    ),
                    ("settings", settings_view()),
                    dashboard_home(),
                ),
                rx.el.footer(
                    rx.el.div(class_name="h-px flex-1 bg-[#E0E2D9]"),
                    rx.el.span(
                        S.copy["footer"],
                        class_name="text-center text-[10px] text-[#84908E]",
                    ),
                    rx.el.div(class_name="h-px flex-1 bg-[#E0E2D9]"),
                    class_name="mt-12 flex items-center gap-5 pb-2",
                ),
                class_name="mx-auto w-full max-w-[1440px] px-5 py-7 sm:px-8 sm:py-9 lg:px-12",
            ),
            class_name="min-h-0 w-full min-w-0 flex-1 overflow-y-auto pb-24 md:pb-0",
        ),
        rx.el.nav(
            rx.foreach(NAV, nav_item),
            aria_label=S.copy["view_path"],
            class_name="fixed inset-x-0 bottom-0 z-30 flex items-center gap-1 border-t border-[#E0E2D9] bg-[#F7F5EF] px-3 pt-2 pb-[max(0.75rem,env(safe-area-inset-bottom))] md:hidden",
        ),
        preview_dialog(),
        support_dialog(),
        browser_tools(),
        class_name="flex h-dvh w-full flex-col overflow-hidden bg-[#F7F5EF] text-[#192B3A]",
    )
