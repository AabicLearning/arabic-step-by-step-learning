import reflex as rx

from arabic_step_by_step_learning.states.learning_state import LearningState as S


def language_choices() -> rx.Component:
    return rx.el.div(
        rx.el.button(
            rx.el.span("English", class_name="font-semibold"),
            rx.el.span("EN", class_name="text-xs text-[#397F78]"),
            on_click=S.choose_language("en"),
            class_name=rx.cond(
                S.language == "en",
                "flex w-full items-center justify-between rounded-2xl border-2 border-[#397F78] bg-[#EAF1ED] px-5 py-4 text-[#192B3A] transition-colors",
                "flex w-full items-center justify-between rounded-2xl border border-[#DCDDD4] bg-white px-5 py-4 text-[#192B3A] hover:border-[#397F78] transition-colors",
            ),
        ),
        rx.el.button(
            rx.el.span("Français", class_name="font-semibold"),
            rx.el.span("FR", class_name="text-xs text-[#397F78]"),
            on_click=S.choose_language("fr"),
            class_name=rx.cond(
                S.language == "fr",
                "flex w-full items-center justify-between rounded-2xl border-2 border-[#397F78] bg-[#EAF1ED] px-5 py-4 text-[#192B3A] transition-colors",
                "flex w-full items-center justify-between rounded-2xl border border-[#DCDDD4] bg-white px-5 py-4 text-[#192B3A] hover:border-[#397F78] transition-colors",
            ),
        ),
        class_name="grid grid-cols-2 gap-3",
    )


def nickname_form(settings: bool = False) -> rx.Component:
    return rx.el.form(
        rx.el.label(
            S.copy["nickname_label"],
            html_for="nickname",
            class_name="mb-2 block text-sm font-semibold text-[#192B3A]",
        ),
        rx.el.input(
            id="nickname",
            name="nickname",
            default_value=S.nickname,
            key=S.nickname,
            placeholder=S.copy["nickname_placeholder"],
            max_length=24,
            required=True,
            auto_complete="given-name",
            class_name="w-full rounded-2xl border border-[#DCDDD4] bg-white px-4 py-3.5 text-[#192B3A] placeholder:text-[#7F898D] focus:outline-hidden focus:ring-2 focus:ring-[#397F78]/30 focus:border-[#397F78]",
        ),
        rx.cond(
            S.error_key != "",
            rx.el.p(
                S.copy[S.error_key],
                role="alert",
                class_name="mt-3 text-sm text-red-600",
            ),
        ),
        rx.cond(
            S.notice_key != "",
            rx.el.p(
                S.copy[S.notice_key],
                role="status",
                class_name="mt-3 text-sm text-[#397F78]",
            ),
        ),
        rx.el.button(
            rx.cond(settings, S.copy["save"], S.copy["continue"]),
            rx.icon("arrow-right", class_name="size-4"),
            type="submit",
            class_name="mt-5 flex w-full items-center justify-center gap-3 rounded-2xl bg-[#397F78] px-5 py-4 text-sm font-semibold text-white hover:bg-[#2E6862] transition-colors focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#397F78]",
        ),
        on_submit=S.save_nickname,
    )


def welcome_choice(
    title: str, description: str, icon: str, familiar: bool
) -> rx.Component:
    return rx.el.button(
        rx.el.div(
            rx.icon(icon, class_name="size-5 text-[#397F78]"),
            class_name="flex size-11 shrink-0 items-center justify-center rounded-xl bg-[#EAF1ED]",
        ),
        rx.el.div(
            rx.el.p(S.copy[title], class_name="font-semibold text-[#192B3A]"),
            rx.el.p(
                S.copy[description],
                class_name="mt-1 text-sm leading-relaxed text-[#68767B]",
            ),
            class_name="flex-1 text-left",
        ),
        rx.icon("chevron-right", class_name="size-5 shrink-0 text-[#397F78]"),
        on_click=S.choose_start(familiar),
        class_name="flex w-full items-center gap-4 rounded-2xl border border-[#DCDDD4] bg-white p-5 hover:border-[#397F78] hover:bg-[#F3F7F3] transition-colors",
    )


def check_answer(letter: str) -> rx.Component:
    return rx.el.button(
        letter,
        disabled=S.selected_answer != "",
        on_click=S.answer_question(letter),
        class_name=rx.cond(
            (S.selected_answer != "")
            & (letter == S.current_question["answer"]),
            "min-h-28 rounded-2xl border-2 border-[#397F78] bg-[#EAF1ED] font-['Noto_Naskh_Arabic'] text-5xl text-[#397F78]",
            "min-h-28 rounded-2xl border border-[#DCDDD4] bg-white font-['Noto_Naskh_Arabic'] text-5xl text-[#192B3A] hover:border-[#397F78] disabled:hover:border-[#DCDDD4] transition-colors",
        ),
        dir="rtl",
    )


def placement_check() -> rx.Component:
    return rx.el.div(
        rx.el.div(
            rx.el.span(
                f"{S.copy['question']} {S.question_index + 1} {S.copy['of']} 3",
                class_name="text-xs font-semibold uppercase tracking-wider text-[#397F78]",
            ),
            rx.el.div(
                rx.foreach(
                    [0, 1, 2],
                    lambda i: rx.el.div(
                        class_name=rx.cond(
                            i <= S.question_index,
                            "h-1.5 w-9 rounded-full bg-[#397F78]",
                            "h-1.5 w-9 rounded-full bg-[#DCDDD4]",
                        )
                    ),
                ),
                class_name="flex gap-1.5",
            ),
            class_name="mb-7 flex items-center justify-between",
        ),
        rx.el.h2(
            S.copy["check_title"],
            class_name="text-3xl font-semibold tracking-tight text-[#192B3A]",
        ),
        rx.el.p(
            S.copy["check_desc"],
            class_name="mt-3 text-sm leading-7 text-[#68767B]",
        ),
        rx.el.p(
            f"{S.copy['find_letter']} {S.current_question['name']} ?",
            class_name="mb-5 mt-8 text-lg font-semibold text-[#192B3A]",
        ),
        rx.el.div(
            check_answer(S.current_question["a"]),
            check_answer(S.current_question["b"]),
            check_answer(S.current_question["c"]),
            class_name="grid grid-cols-3 gap-3",
        ),
        rx.cond(
            S.selected_answer == "",
            rx.el.div(
                rx.el.button(
                    S.copy["unknown"],
                    on_click=S.answer_question("unknown"),
                    class_name="mt-4 w-full rounded-2xl border border-[#DCDDD4] bg-transparent px-4 py-3 text-sm font-medium text-[#68767B] hover:bg-white",
                ),
                rx.el.button(
                    S.copy["skip_check"],
                    on_click=S.skip_check,
                    class_name="mt-5 w-full text-xs text-[#68767B] underline underline-offset-4 hover:text-[#397F78]",
                ),
            ),
            rx.el.div(
                rx.el.div(
                    rx.icon(
                        "sprout", class_name="size-5 shrink-0 text-[#397F78]"
                    ),
                    rx.el.div(
                        rx.el.p(
                            S.copy[S.feedback_key],
                            class_name="text-sm leading-6 text-[#192B3A]",
                        ),
                        rx.el.p(
                            S.copy["answer_is"],
                            " ",
                            S.current_question["name"],
                            " · ",
                            rx.el.span(
                                S.current_question["answer"],
                                dir="rtl",
                                class_name="font-['Noto_Naskh_Arabic'] text-2xl text-[#397F78]",
                            ),
                            class_name="mt-2 text-sm text-[#68767B]",
                        ),
                    ),
                    role="status",
                    class_name="mt-5 flex gap-3 rounded-2xl bg-[#EAF1ED] p-4",
                ),
                rx.el.button(
                    rx.cond(
                        S.question_index == 2,
                        S.copy["see_start"],
                        S.copy["next_question"],
                    ),
                    rx.icon("arrow-right", class_name="size-4"),
                    on_click=S.next_question,
                    class_name="mt-5 flex w-full items-center justify-center gap-2 rounded-2xl bg-[#397F78] px-4 py-4 text-sm font-semibold text-white hover:bg-[#2E6862]",
                ),
            ),
        ),
    )


def result() -> rx.Component:
    return rx.el.div(
        rx.el.div(
            rx.icon("sprout", class_name="size-8 text-[#397F78]"),
            class_name="mb-6 flex size-16 items-center justify-center rounded-full bg-[#EAF1ED]",
        ),
        rx.el.p(
            S.copy["result_eyebrow"],
            class_name="text-xs font-semibold tracking-[0.16em] text-[#397F78]",
        ),
        rx.el.h2(
            S.copy["result_title"],
            class_name="mt-3 text-3xl font-semibold tracking-tight text-[#192B3A]",
        ),
        rx.el.div(
            S.placement_label,
            class_name="mt-5 w-fit rounded-full border border-[#397F78]/25 bg-[#EAF1ED] px-4 py-2 text-sm font-semibold text-[#397F78]",
        ),
        rx.el.p(
            S.placement_description,
            class_name="mt-5 text-sm leading-7 text-[#68767B]",
        ),
        rx.el.div(
            rx.el.p(
                S.copy["recommended_letter"],
                class_name="text-xs font-semibold text-[#397F78]",
            ),
            rx.el.div(
                rx.el.span(
                    S.recommended_letter["glyph"],
                    dir="rtl",
                    lang="ar",
                    class_name="font-['Noto_Naskh_Arabic'] text-5xl text-[#397F78]",
                ),
                rx.el.span(
                    S.recommended_letter["romanization"],
                    class_name="text-lg font-semibold text-[#192B3A]",
                ),
                class_name="mt-3 flex items-center gap-4",
            ),
            rx.cond(
                ~S.placement_data["skipped"],
                rx.el.p(
                    S.copy["recommended_reason"],
                    class_name="mt-3 text-xs leading-6 text-[#68767B]",
                ),
            ),
            class_name="mt-5 rounded-2xl border border-[#D6E3D9] bg-[#EAF1ED] p-5",
        ),
        rx.el.p(
            S.copy["result_note"],
            class_name="mt-4 border-l-2 border-[#397F78]/30 pl-4 text-xs leading-6 text-[#68767B]",
        ),
        rx.el.button(
            S.copy["go_home"],
            rx.icon("arrow-right", class_name="size-4"),
            on_click=S.finish_setup,
            class_name="mt-7 flex w-full items-center justify-center gap-3 rounded-2xl bg-[#397F78] py-4 text-sm font-semibold text-white hover:bg-[#2E6862]",
        ),
    )


def onboarding() -> rx.Component:
    return rx.el.div(
        rx.el.header(
            rx.el.div(
                rx.image(
                    src=rx.asset("arabic-step-user-logo.jpg"),
                    alt="Arabic Step by Step logo",
                    class_name="size-10 rounded-full object-cover",
                ),
                rx.el.span(
                    S.copy["brand"],
                    class_name="text-base font-semibold tracking-tight text-[#192B3A]",
                ),
                class_name="flex items-center gap-3",
            ),
            rx.el.span(
                S.copy["setup"],
                class_name="hidden text-xs text-[#68767B] sm:block",
            ),
            class_name="mx-auto flex w-full max-w-7xl items-center justify-between px-6 py-7 lg:px-12",
        ),
        rx.el.main(
            rx.el.div(
                rx.el.p(
                    "أهلًا",
                    dir="rtl",
                    lang="ar",
                    class_name="font-['Noto_Naskh_Arabic'] text-[100px] leading-tight text-[#397F78] lg:text-[150px]",
                ),
                rx.el.div(class_name="my-6 h-px w-12 bg-[#397F78]/30"),
                rx.el.p(
                    S.copy["greeting_meaning"],
                    class_name="text-xs uppercase tracking-[0.2em] text-[#397F78]",
                ),
                rx.el.h1(
                    S.copy["tagline"],
                    class_name="mt-5 max-w-sm text-3xl leading-snug font-medium tracking-tight text-[#192B3A] lg:text-4xl",
                ),
                rx.el.p(
                    S.copy["right_to_left"],
                    class_name="mt-4 text-sm text-[#68767B]",
                ),
                class_name="hidden flex-col items-start justify-center border-r border-[#DCDDD4] pr-14 md:flex",
            ),
            rx.el.div(
                rx.cond(
                    S.stage != "language",
                    rx.el.button(
                        rx.icon("arrow-left", class_name="size-4"),
                        S.copy["back"],
                        on_click=S.go_back,
                        class_name="mb-7 flex items-center gap-2 text-xs font-medium text-[#68767B] hover:text-[#397F78]",
                    ),
                ),
                rx.match(
                    S.stage,
                    (
                        "language",
                        rx.el.div(
                            rx.el.p(
                                S.copy["language_label"],
                                class_name="mb-4 text-xs font-semibold tracking-[0.15em] text-[#397F78]",
                            ),
                            rx.el.h2(
                                S.copy["language_title"],
                                class_name="text-3xl font-semibold leading-tight tracking-tight text-[#192B3A] lg:text-4xl",
                            ),
                            rx.el.p(
                                S.copy["language_desc"],
                                class_name="mb-8 mt-4 text-sm leading-7 text-[#68767B]",
                            ),
                            language_choices(),
                            rx.el.p(
                                S.copy["change_later"],
                                class_name="mt-4 text-xs leading-6 text-[#68767B]",
                            ),
                        ),
                    ),
                    (
                        "welcome",
                        rx.el.div(
                            rx.el.h2(
                                S.copy["welcome_title"],
                                class_name="text-3xl font-semibold tracking-tight text-[#192B3A]",
                            ),
                            rx.el.p(
                                S.copy["welcome_desc"],
                                class_name="mb-7 mt-4 text-sm leading-7 text-[#68767B]",
                            ),
                            rx.el.div(
                                welcome_choice(
                                    "new_title", "new_desc", "sprout", False
                                ),
                                welcome_choice(
                                    "familiar_title",
                                    "familiar_desc",
                                    "scan-eye",
                                    True,
                                ),
                                class_name="space-y-3",
                            ),
                        ),
                    ),
                    (
                        "nickname",
                        rx.el.div(
                            rx.el.h2(
                                S.copy["nickname_title"],
                                class_name="text-3xl font-semibold tracking-tight text-[#192B3A]",
                            ),
                            rx.el.p(
                                S.copy["nickname_desc"],
                                class_name="mb-7 mt-4 text-sm leading-7 text-[#68767B]",
                            ),
                            nickname_form(),
                            rx.el.p(
                                S.copy["saved_device"],
                                class_name="mt-4 text-xs leading-6 text-[#68767B]",
                            ),
                        ),
                    ),
                    ("check", placement_check()),
                    ("result", result()),
                    rx.el.div(),
                ),
                class_name="w-full self-center py-6 md:pl-12 lg:pl-16",
            ),
            class_name="mx-auto grid w-full max-w-6xl flex-1 grid-cols-1 items-center px-6 py-6 md:grid-cols-2 lg:px-12 lg:py-12",
        ),
        rx.el.footer(
            rx.icon(
                "shield-check", class_name="size-4 shrink-0 text-[#397F78]"
            ),
            S.copy["local_note"],
            class_name="flex items-center justify-center gap-2 px-6 py-7 text-center text-xs leading-5 text-[#68767B]",
        ),
        class_name="flex min-h-dvh flex-col bg-[#F7F5EF] text-[#192B3A]",
    )
