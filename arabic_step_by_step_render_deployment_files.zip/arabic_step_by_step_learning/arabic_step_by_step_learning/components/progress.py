import reflex as rx
from arabic_step_by_step_learning.states.learning_state import LearningState as S, ModuleData
from arabic_step_by_step_learning.components.letters import audio_button


def module_progress(module: ModuleData) -> rx.Component:
    return rx.el.div(
        rx.el.div(
            rx.el.h3(
                module["title"],
                class_name="text-sm font-semibold text-[#192B3A]",
            ),
            rx.el.span(
                f"{module['done']} / {module['total']} · {module['percent']}%",
                class_name="text-xs text-[#397F78]",
            ),
            class_name="mb-3 flex items-center justify-between gap-3",
        ),
        rx.el.progress(
            value=module["done"],
            max=module["total"],
            aria_label=module["title"],
            class_name="h-2 w-full overflow-hidden rounded-full bg-[#E0E2D9] accent-[#397F78] [&::-webkit-progress-bar]:bg-[#E0E2D9] [&::-webkit-progress-value]:bg-[#397F78] [&::-moz-progress-bar]:bg-[#397F78]",
        ),
        class_name="w-full rounded-2xl border border-[#E0E2D9] bg-white/70 p-5",
    )


def badge_card(badge: dict[str, str | bool]) -> rx.Component:
    return rx.el.div(
        rx.icon("award", class_name="size-7 text-[#397F78]"),
        rx.el.h3(
            badge["title"].to(str),
            class_name="mt-3 text-sm font-semibold text-[#192B3A]",
        ),
        rx.el.p(
            badge["hint"].to(str),
            class_name="mt-2 text-xs leading-6 text-[#68767B]",
        ),
        rx.el.span(
            rx.cond(
                badge["earned"].to(bool),
                S.copy["completed"],
                S.copy["not_earned"],
            ),
            class_name="mt-3 block text-xs text-[#397F78]",
        ),
        class_name=rx.cond(
            badge["earned"].to(bool),
            "rounded-2xl border border-[#A9C6BA] bg-[#EAF1ED] p-5",
            "rounded-2xl border border-[#E0E2D9] bg-white/50 p-5 opacity-65",
        ),
    )


def progress_view() -> rx.Component:
    return rx.el.section(
        rx.el.p(
            S.copy["reward_rules"],
            class_name="mb-6 rounded-xl bg-[#EAF1ED] p-4 text-sm leading-7 text-[#397F78]",
        ),
        rx.el.div(
            rx.el.p(
                f"{S.copy['completed']} : {S.completed_total}",
                class_name="text-sm text-[#192B3A]",
            ),
            rx.el.p(
                f"{S.copy['exercises_saved']} : {S.progress_data['exercises'].length()}",
                class_name="text-sm text-[#192B3A]",
            ),
            rx.el.p(
                f"{S.copy['learned_words']} : {S.progress_data['words'].length()}",
                class_name="text-sm text-[#192B3A]",
            ),
            class_name="mb-6 flex flex-wrap gap-5",
        ),
        rx.el.div(
            rx.foreach(S.modules, module_progress),
            class_name="grid w-full gap-4 sm:grid-cols-2",
        ),
        rx.el.h2(
            S.copy["badges"],
            class_name="mb-5 mt-9 text-xl font-semibold text-[#192B3A]",
        ),
        rx.el.div(
            rx.foreach(S.badges, badge_card),
            class_name="grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
        ),
    )


def review_card() -> rx.Component:
    return rx.el.section(
        rx.el.div(
            rx.icon("repeat-2", class_name="size-6 shrink-0 text-[#397F78]"),
            rx.el.div(
                rx.el.h2(
                    S.copy["review_title"],
                    class_name="text-xl font-semibold text-[#192B3A]",
                ),
                rx.el.p(
                    S.copy["review_desc"],
                    class_name="mt-2 text-sm leading-7 text-[#68767B]",
                ),
                rx.el.p(
                    rx.cond(
                        S.review_date_ready,
                        f"{S.copy['review_due']} : {S.review_due_count}",
                        S.copy["review_loading"],
                    ),
                    class_name="mt-3 text-sm font-semibold text-[#397F78]",
                ),
            ),
            class_name="flex items-start gap-4",
        ),
        rx.cond(
            S.review_targets.length() == 0,
            rx.el.p(
                S.copy["review_empty"],
                class_name="mt-4 text-sm leading-7 text-[#68767B]",
            ),
        ),
        rx.el.button(
            S.copy["review_open"],
            rx.icon("arrow-right", class_name="size-4"),
            on_click=S.open_review,
            class_name="mt-5 flex w-fit items-center gap-3 rounded-xl bg-[#397F78] px-5 py-3.5 text-sm font-semibold text-white transition-colors hover:bg-[#2E6862] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#397F78]",
        ),
        class_name="mt-5 w-full rounded-3xl border border-[#D6E3D9] bg-white/70 p-6 sm:p-8",
    )


def review_dialog() -> rx.Component:
    return rx.el.div(
        rx.el.h2(
            S.copy["review_title"],
            id="modal-title",
            class_name="pr-8 text-2xl font-semibold text-[#192B3A]",
        ),
        rx.el.p(
            S.copy["review_desc"],
            class_name="mt-4 text-sm leading-7 text-[#68767B]",
        ),
        rx.cond(
            S.review_pending | (~S.review_date_ready),
            rx.el.p(
                S.copy["review_loading"],
                role="status",
                class_name="mt-6 animate-pulse text-sm text-[#397F78]",
            ),
            rx.cond(
                S.review_item != "",
                rx.el.div(
                    rx.el.p(
                        f"{S.copy['review_progress']} : {S.review_completed} / {S.review_total}",
                        class_name="mt-5 text-sm font-semibold text-[#397F78]",
                    ),
                    rx.el.p(
                        rx.cond(
                            S.review_item.startswith("letters:"),
                            S.copy["review_letter_prompt"],
                            S.copy["review_word_prompt"],
                        ),
                        class_name="mt-5 text-sm text-[#68767B]",
                    ),
                    rx.el.p(
                        S.review_prompt,
                        class_name="mt-2 text-xl font-semibold leading-8 text-[#192B3A]",
                    ),
                    rx.el.div(
                        rx.foreach(
                            S.review_choices,
                            lambda answer: rx.el.button(
                                answer,
                                key=answer,
                                dir="rtl",
                                lang="ar",
                                on_click=S.answer_review(
                                    S.review_token, answer
                                ),
                                disabled=S.review_answer != "",
                                aria_pressed=S.review_answer == answer,
                                class_name=rx.cond(
                                    (S.review_answer != "")
                                    & (answer == S.review_correct_answer),
                                    "min-h-24 rounded-xl border-2 border-[#397F78] bg-[#EAF1ED] p-3 font-['Noto_Naskh_Arabic'] text-4xl leading-relaxed text-[#397F78]",
                                    "min-h-24 rounded-xl border border-[#D6E3D9] bg-[#F7F5EF] p-3 font-['Noto_Naskh_Arabic'] text-4xl leading-relaxed text-[#192B3A] hover:border-[#397F78] focus-visible:outline-2 focus-visible:outline-[#397F78] disabled:opacity-60",
                                ),
                            ),
                        ),
                        class_name="mt-5 grid grid-cols-2 gap-3",
                    ),
                    rx.cond(
                        S.review_answer != "",
                        rx.el.div(
                            rx.el.div(
                                rx.el.p(
                                    S.copy[S.review_feedback],
                                    class_name="text-sm leading-7 text-[#397F78]",
                                ),
                                rx.el.p(
                                    S.review_correct_answer,
                                    dir="rtl",
                                    lang="ar",
                                    class_name="mt-2 font-['Noto_Naskh_Arabic'] text-4xl leading-relaxed text-[#192B3A]",
                                ),
                                rx.el.p(
                                    f"{S.copy['review_next_date']} : {S.review_next_date}",
                                    class_name="mt-2 text-xs text-[#68767B]",
                                ),
                                role="status",
                                aria_live="polite",
                                class_name="mt-4 rounded-xl bg-[#EAF1ED] p-4",
                            ),
                            rx.el.button(
                                S.copy["review_continue"],
                                rx.icon("arrow-right", class_name="size-4"),
                                on_click=S.next_review(S.review_token),
                                class_name="mt-4 flex w-fit items-center gap-2 rounded-xl bg-[#397F78] px-5 py-3 text-sm font-semibold text-white hover:bg-[#2E6862] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#397F78]",
                            ),
                        ),
                    ),
                ),
                rx.el.div(
                    rx.icon(
                        "circle-check", class_name="mb-3 size-10 text-[#397F78]"
                    ),
                    rx.el.p(
                        rx.cond(
                            S.review_targets.length() == 0,
                            S.copy["review_empty"],
                            S.copy["review_caught_up"],
                        ),
                        class_name="text-lg font-semibold leading-8 text-[#397F78]",
                    ),
                    rx.cond(
                        S.review_targets.length() > 0,
                        rx.el.p(
                            S.copy["review_caught_up_detail"],
                            class_name="mt-3 text-sm leading-7 text-[#68767B]",
                        ),
                    ),
                    rx.cond(
                        S.review_total > 0,
                        rx.el.p(
                            f"{S.copy['review_progress']} : {S.review_completed} / {S.review_total}",
                            class_name="mt-3 text-sm text-[#397F78]",
                        ),
                    ),
                    rx.el.button(
                        S.copy["review_finish"],
                        on_click=S.close_modal,
                        class_name="mt-5 rounded-xl bg-[#397F78] px-5 py-3 text-sm font-semibold text-white hover:bg-[#2E6862]",
                    ),
                    class_name="mt-6 rounded-2xl bg-[#EAF1ED] p-5",
                ),
            ),
        ),
    )


def daily_dialog() -> rx.Component:
    return rx.el.div(
        rx.el.h2(
            S.copy["daily_title"],
            id="modal-title",
            class_name="pr-8 text-2xl font-semibold text-[#192B3A]",
        ),
        rx.el.p(
            S.copy["daily_detail"],
            class_name="mt-4 text-sm leading-7 text-[#68767B]",
        ),
        rx.cond(
            S.daily_ready,
            rx.cond(
                S.daily_done,
                rx.el.div(
                    rx.icon(
                        "circle-check", class_name="mb-3 size-10 text-[#397F78]"
                    ),
                    rx.el.p(
                        S.copy["daily_done"],
                        class_name="text-lg font-semibold text-[#397F78]",
                    ),
                    class_name="mt-6 rounded-2xl bg-[#EAF1ED] p-5",
                ),
                rx.el.div(
                    rx.el.p(
                        f"{S.copy['completed']} : {S.daily_index} / 5",
                        class_name="mt-5 text-sm font-semibold text-[#397F78]",
                    ),
                    rx.el.p(
                        S.daily_prompt,
                        class_name="my-5 text-lg leading-8 text-[#192B3A]",
                    ),
                    audio_button(S.daily_audio, "listen"),
                    rx.el.div(
                        rx.foreach(
                            S.daily_choices,
                            lambda answer: rx.el.button(
                                answer,
                                dir="rtl",
                                lang="ar",
                                on_click=S.answer_daily(answer),
                                disabled=S.daily_answer != "",
                                class_name="min-h-20 rounded-xl border border-[#D6E3D9] bg-[#F7F5EF] p-3 font-['Noto_Naskh_Arabic'] text-4xl text-[#397F78] hover:border-[#397F78] disabled:opacity-60",
                            ),
                        ),
                        class_name="mt-5 grid grid-cols-2 gap-3",
                    ),
                    rx.cond(
                        S.daily_feedback != "",
                        rx.el.p(
                            S.copy[S.daily_feedback],
                            role="status",
                            class_name="mt-4 rounded-xl bg-[#EAF1ED] p-4 text-sm text-[#397F78]",
                        ),
                    ),
                    rx.cond(
                        S.daily_answer != "",
                        rx.el.button(
                            S.copy["continue"],
                            rx.icon("arrow-right", class_name="size-4"),
                            on_click=S.next_daily,
                            class_name="mt-4 flex items-center gap-2 rounded-xl bg-[#397F78] px-5 py-3 text-sm font-semibold text-white",
                        ),
                    ),
                ),
            ),
            rx.el.p(
                S.copy["daily_locked"],
                class_name="mt-5 rounded-xl bg-[#EAF1ED] p-4 text-sm leading-7 text-[#397F78]",
            ),
        ),
    )


def personalization_settings() -> rx.Component:
    return rx.el.section(
        rx.el.div(
            rx.el.div(
                rx.el.h2(
                    S.copy["sound"],
                    class_name="text-base font-semibold text-[#192B3A]",
                ),
                rx.el.p(
                    S.copy["sound_hint"],
                    class_name="mt-2 text-xs leading-6 text-[#68767B]",
                ),
            ),
            rx.el.button(
                rx.icon("volume-2", class_name="size-4"),
                rx.cond(
                    S.sound == "on", S.copy["sound_on"], S.copy["sound_off"]
                ),
                on_click=S.toggle_sound,
                role="switch",
                aria_checked=S.sound == "on",
                class_name="flex shrink-0 items-center gap-2 rounded-xl border border-[#D6E3D9] bg-[#EAF1ED] px-4 py-3 text-sm font-semibold text-[#397F78]",
            ),
            class_name="flex flex-wrap items-center justify-between gap-5",
        ),
        rx.el.button(
            rx.icon("rotate-ccw", class_name="size-4"),
            S.copy["reset_progress"],
            on_click=S.request_reset,
            class_name="mt-6 flex items-center gap-2 rounded-xl border border-red-200 bg-white px-4 py-3 text-sm font-semibold text-red-600 hover:bg-red-50",
        ),
        rx.cond(
            S.notice_key == "reset_done",
            rx.el.p(
                S.copy["reset_done"],
                role="status",
                class_name="mt-4 text-sm text-[#397F78]",
            ),
        ),
        class_name="mt-5 rounded-3xl border border-[#E0E2D9] bg-white/70 p-6 sm:p-8",
    )


def reset_dialog() -> rx.Component:
    return rx.el.div(
        rx.el.h2(
            S.copy["reset_title"],
            id="modal-title",
            class_name="pr-8 text-2xl font-semibold text-[#192B3A]",
        ),
        rx.el.p(
            S.copy["reset_detail"],
            class_name="mt-4 text-sm leading-7 text-[#68767B]",
        ),
        rx.el.div(
            rx.el.button(
                S.copy["cancel"],
                on_click=S.close_modal,
                class_name="rounded-xl border border-[#D6E3D9] bg-[#F7F5EF] px-5 py-3 text-sm font-semibold text-[#397F78]",
            ),
            rx.el.button(
                S.copy["reset_progress"],
                on_click=S.confirm_reset,
                class_name="rounded-xl bg-red-600 px-5 py-3 text-sm font-semibold text-white hover:bg-red-700",
            ),
            class_name="mt-6 flex flex-wrap gap-3",
        ),
    )
