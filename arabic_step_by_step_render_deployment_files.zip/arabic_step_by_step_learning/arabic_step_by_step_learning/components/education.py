import reflex as rx
from arabic_step_by_step_learning.states.learning_state import LearningState as S, ModuleData
from arabic_step_by_step_learning.states.education_state import EducationState as E, ActivityChoice
from arabic_step_by_step_learning.states.education_data import LessonData
from arabic_step_by_step_learning.components.letters import audio_button


def education_audio_status() -> rx.Component:
    return rx.el.div(
        rx.el.p(
            S.copy["education_audio_note"],
            class_name="text-xs leading-6 text-[#68767B]",
        ),
        rx.el.p(
            id="letter-audio-status",
            role="status",
            aria_live="polite",
            class_name="mt-2 text-sm text-[#397F78]",
        ),
        class_name="mt-5",
    )


def color_swatch(color: str, label: str) -> rx.Component:
    return rx.el.div(
        rx.el.div(
            class_name=color,
            role="img",
            aria_label=label,
            custom_attrs={"data-color-swatch": "true"},
        ),
        class_name="mx-auto size-24 overflow-hidden rounded-2xl border border-[#BCC5C0] [&>div]:h-full [&>div]:w-full",
    )


def lesson_tile(item: LessonData, index: int) -> rx.Component:
    return rx.el.button(
        rx.el.span(
            rx.cond(item["numeral"] != "", item["numeral"], item["arabic"]),
            dir="rtl",
            lang="ar",
            class_name="block font-['Noto_Naskh_Arabic'] text-2xl leading-relaxed",
        ),
        rx.el.span(
            rx.cond(S.language == "fr", item["fr"], item["en"]),
            class_name="block text-xs",
        ),
        rx.cond(
            (E.module == "grammar")
            & S.progress_data["lessons"].contains(f"grammar:{item['id']}"),
            rx.el.span(
                rx.icon("check", class_name="inline size-3"),
                S.copy["completed"],
                class_name="mt-2 block text-xs text-[#397F78]",
            ),
        ),
        on_click=E.select_lesson(index),
        aria_pressed=E.selected == index,
        key=item["id"],
        class_name=rx.cond(
            E.selected == index,
            "rounded-2xl border-2 border-[#397F78] bg-[#EAF1ED] p-3 text-[#397F78] focus-visible:outline-2 focus-visible:outline-[#397F78]",
            "rounded-2xl border border-[#E0E2D9] bg-white p-3 text-[#192B3A] hover:border-[#397F78] focus-visible:outline-2 focus-visible:outline-[#397F78]",
        ),
    )


def syllable_card(text: str, roman: str, audio: str) -> rx.Component:
    return rx.el.div(
        rx.el.p(
            text,
            dir="rtl",
            lang="ar",
            class_name="font-['Noto_Naskh_Arabic'] text-6xl leading-relaxed text-[#397F78]",
        ),
        rx.el.p(roman, class_name="mb-3 text-lg text-[#192B3A]"),
        audio_button(audio, "listen_sound"),
        class_name="rounded-2xl border border-[#D6E3D9] bg-[#F7F5EF] p-5 text-center",
    )


def lesson_card() -> rx.Component:
    return rx.el.section(
        rx.el.div(
            rx.el.button(
                rx.icon("chevron-left", class_name="size-4"),
                S.copy["lesson_previous"],
                on_click=E.move_lesson(-1),
                disabled=E.selected == 0,
                class_name="flex items-center gap-1 text-xs text-[#397F78] disabled:opacity-30",
            ),
            rx.el.span(
                f"{E.selected + 1} / {E.lessons.length()}",
                class_name="text-xs text-[#68767B]",
            ),
            rx.el.button(
                S.copy["lesson_next"],
                rx.icon("chevron-right", class_name="size-4"),
                on_click=E.move_lesson(1),
                disabled=E.selected == E.lessons.length() - 1,
                class_name="flex items-center gap-1 text-xs text-[#397F78] disabled:opacity-30",
            ),
            class_name="mb-6 flex items-center justify-between gap-3",
        ),
        rx.el.div(
            rx.cond(
                E.current["swatch"] != "",
                color_swatch(
                    E.current["swatch"],
                    rx.cond(
                        S.language == "fr", E.current["fr"], E.current["en"]
                    ),
                ),
            ),
            rx.cond(
                E.current["numeral"] != "",
                rx.el.p(
                    E.current["numeral"],
                    dir="rtl",
                    lang="ar",
                    class_name="font-['Noto_Naskh_Arabic'] text-8xl leading-relaxed text-[#397F78]",
                ),
            ),
            rx.cond(
                E.current["mark"] != "",
                rx.el.p(
                    E.current["mark"],
                    dir="rtl",
                    lang="ar",
                    class_name="font-['Noto_Naskh_Arabic'] text-7xl leading-relaxed text-[#397F78]",
                ),
            ),
            rx.el.h2(
                E.current["arabic"],
                dir="rtl",
                lang="ar",
                class_name="mt-4 font-['Noto_Naskh_Arabic'] text-5xl leading-relaxed text-[#192B3A] sm:text-6xl",
            ),
            rx.el.p(
                E.current["roman"],
                class_name="mt-3 text-xl font-medium text-[#397F78]",
            ),
            rx.el.p(
                rx.cond(S.language == "fr", E.current["fr"], E.current["en"]),
                class_name="mt-2 text-lg text-[#68767B]",
            ),
            rx.el.div(
                audio_button(E.current["arabic"], "listen"), class_name="mt-5"
            ),
            class_name="rounded-2xl bg-[#F7F5EF] p-5 text-center sm:p-8",
        ),
        rx.cond(
            E.module == "harakat",
            rx.el.div(
                rx.el.p(
                    rx.cond(
                        S.language == "fr",
                        E.current["tip_fr"],
                        E.current["tip_en"],
                    ),
                    class_name="my-5 text-sm leading-7 text-[#192B3A]",
                ),
                rx.el.div(
                    syllable_card(
                        E.current["b"],
                        E.current["b_roman"],
                        rx.cond(
                            E.current["id"] == "sukoon", "أَبْ", E.current["b"]
                        ),
                    ),
                    syllable_card(
                        E.current["m"],
                        E.current["m_roman"],
                        rx.cond(
                            E.current["id"] == "sukoon", "أَمْ", E.current["m"]
                        ),
                    ),
                    class_name="grid gap-4 sm:grid-cols-2",
                ),
            ),
        ),
        rx.cond(
            E.module == "grammar",
            rx.el.div(
                rx.el.h3(
                    S.copy["grammar_rule"],
                    class_name="mt-6 text-sm font-semibold text-[#397F78]",
                ),
                rx.el.p(
                    rx.cond(
                        S.language == "fr",
                        E.current["tip_fr"],
                        E.current["tip_en"],
                    ),
                    class_name="mt-3 text-sm leading-7 text-[#192B3A]",
                ),
            ),
        ),
        rx.cond(
            E.module == "colors",
            rx.el.p(
                S.copy["color_note"],
                class_name="mt-5 text-sm leading-7 text-[#68767B]",
            ),
        ),
        rx.cond(
            E.module == "phrases",
            rx.el.p(
                S.copy["phrase_note"],
                class_name="mt-5 text-sm leading-7 text-[#68767B]",
            ),
        ),
        rx.el.div(
            rx.el.button(
                rx.icon("check", class_name="size-4"),
                rx.cond(
                    S.progress_data["lessons"].contains(
                        f"{E.module}:{E.current['id']}"
                    ),
                    S.copy["completed"],
                    S.copy["lesson_complete"],
                ),
                on_click=E.complete_lesson,
                disabled=E.lesson_feedback
                | S.progress_data["lessons"].contains(
                    f"{E.module}:{E.current['id']}"
                ),
                class_name="flex items-center gap-2 rounded-xl bg-[#397F78] px-4 py-3 text-sm font-semibold text-white hover:bg-[#2E6862] disabled:opacity-50",
            ),
            rx.el.button(
                rx.icon("shapes", class_name="size-4"),
                S.copy["practice_now"],
                on_click=S.practise_module,
                class_name="flex items-center gap-2 rounded-xl border border-[#D6E3D9] bg-white px-4 py-3 text-sm font-semibold text-[#397F78] hover:bg-[#EAF1ED]",
            ),
            class_name="mt-6 flex flex-wrap gap-3",
        ),
        rx.cond(
            E.lesson_feedback,
            rx.el.p(
                S.copy["lesson_done"],
                role="status",
                class_name="mt-4 rounded-xl bg-[#EAF1ED] p-4 text-sm leading-7 text-[#397F78]",
            ),
        ),
        education_audio_status(),
        class_name="rounded-3xl border border-[#E0E2D9] bg-white/70 p-5 sm:p-8",
    )


def category_button(category: str) -> rx.Component:
    return rx.el.button(
        S.copy[f"category_{category}"],
        on_click=E.choose_category(category),
        aria_pressed=E.category == category,
        class_name=rx.cond(
            E.category == category,
            "rounded-xl border border-[#397F78] bg-[#EAF1ED] px-4 py-3 text-sm font-semibold text-[#397F78]",
            "rounded-xl border border-[#E0E2D9] bg-white px-4 py-3 text-sm text-[#68767B] hover:border-[#397F78]",
        ),
    )


def category_selector() -> rx.Component:
    return rx.cond(
        E.module == "vocabulary",
        rx.el.div(
            rx.el.p(
                S.copy["category"],
                class_name="mb-3 text-xs font-semibold text-[#397F78]",
            ),
            rx.el.div(
                rx.foreach(E.categories, category_button),
                class_name="flex flex-wrap gap-2",
            ),
            class_name="mb-6",
        ),
    )


def mode_button(mode: str) -> rx.Component:
    return rx.el.button(
        S.copy[mode],
        on_click=E.start_mode(mode),
        aria_pressed=E.mode == mode,
        class_name=rx.cond(
            E.mode == mode,
            "rounded-xl border border-[#397F78] bg-[#EAF1ED] px-4 py-3 text-sm font-semibold text-[#397F78]",
            "rounded-xl border border-[#E0E2D9] bg-white px-4 py-3 text-sm text-[#192B3A] hover:border-[#397F78]",
        ),
    )


def answer_choice(choice: ActivityChoice) -> rx.Component:
    return rx.el.button(
        rx.cond(
            choice["swatch"] != "",
            color_swatch(choice["swatch"], S.copy["choose_answer"]),
            rx.el.span(
                rx.cond(
                    S.language == "fr", choice["text_fr"], choice["text_en"]
                ),
                dir=rx.cond(choice["arabic"], "rtl", "ltr"),
                lang=rx.cond(choice["arabic"], "ar", S.language),
                class_name=rx.cond(
                    choice["arabic"],
                    "font-['Noto_Naskh_Arabic'] text-4xl leading-relaxed",
                    "text-sm leading-7",
                ),
            ),
        ),
        on_click=E.select_answer(choice["id"]),
        disabled=E.answered,
        aria_pressed=E.selected_answer == choice["id"],
        key=choice["id"],
        aria_label=rx.cond(
            choice["swatch"] != "",
            rx.cond(S.language == "fr", "Choix de couleur", "Color choice"),
            rx.cond(S.language == "fr", choice["text_fr"], choice["text_en"]),
        ),
        class_name=rx.cond(
            (E.selected_answer == choice["id"])
            | (E.answered & (E.correct_id == choice["id"])),
            "min-h-28 rounded-2xl border-2 border-[#397F78] bg-[#EAF1ED] p-4 text-[#397F78]",
            "min-h-28 rounded-2xl border border-[#D6E3D9] bg-white p-4 text-[#192B3A] hover:border-[#397F78] disabled:opacity-60",
        ),
    )


def letter_game_tile(tile: ActivityChoice) -> rx.Component:
    return rx.el.button(
        tile["text_en"],
        dir="rtl",
        lang="ar",
        on_click=E.add_tile(tile["id"]),
        disabled=E.answered | E.used_tiles.contains(tile["id"]),
        key=tile["id"],
        class_name="min-h-20 min-w-16 rounded-xl border border-[#D6E3D9] bg-white p-3 font-['Noto_Naskh_Arabic'] text-4xl text-[#192B3A] hover:border-[#397F78] disabled:opacity-25",
    )


def tile_board() -> rx.Component:
    return rx.el.div(
        rx.el.p(
            rx.match(
                E.mode,
                ("ordering", S.copy["ordering_help"]),
                ("sentence_build", S.copy["sentence_build_help"]),
                ("grammar_order", S.copy["grammar_order_tiles"]),
                S.copy["tile_help"],
            ),
            class_name="mb-4 text-sm leading-7 text-[#68767B]",
        ),
        rx.el.p(
            rx.cond(E.built_text != "", E.built_text, "…"),
            dir=rx.cond(E.mode == "ordering", "ltr", "rtl"),
            lang="ar",
            aria_live="polite",
            class_name="mb-5 min-h-24 rounded-2xl bg-[#EAF1ED] p-5 text-center font-['Noto_Naskh_Arabic'] text-5xl leading-relaxed text-[#397F78]",
        ),
        rx.el.div(
            rx.foreach(E.tiles, letter_game_tile),
            dir=rx.cond(E.mode == "ordering", "ltr", "rtl"),
            class_name="flex flex-wrap justify-center gap-3",
        ),
        rx.el.div(
            rx.el.button(
                S.copy["undo_tile"],
                on_click=E.undo_tile,
                disabled=E.answered,
                class_name="rounded-xl border border-[#D6E3D9] bg-white px-4 py-3 text-xs text-[#397F78] disabled:opacity-40",
            ),
            rx.el.button(
                S.copy["clear_tiles"],
                on_click=E.clear_tiles,
                disabled=E.answered,
                class_name="rounded-xl border border-[#D6E3D9] bg-white px-4 py-3 text-xs text-[#397F78] disabled:opacity-40",
            ),
            class_name="mt-4 flex flex-wrap gap-3",
        ),
    )


def activity_prompt() -> rx.Component:
    return rx.el.div(
        rx.cond(
            E.prompt_swatch != "",
            color_swatch(
                E.prompt_swatch,
                rx.cond(
                    S.language == "fr",
                    "Couleur à identifier",
                    "Color to identify",
                ),
            ),
        ),
        rx.cond(
            E.prompt_en != "",
            rx.el.p(
                rx.cond(S.language == "fr", E.prompt_fr, E.prompt_en),
                dir=rx.cond(E.prompt_arabic, "rtl", "ltr"),
                lang=rx.cond(E.prompt_arabic, "ar", S.language),
                class_name=rx.cond(
                    E.prompt_arabic,
                    "font-['Noto_Naskh_Arabic'] text-6xl leading-relaxed text-[#397F78]",
                    "text-xl leading-8 font-medium text-[#192B3A]",
                ),
            ),
        ),
        rx.cond(
            E.object_count >= 0,
            rx.el.div(
                rx.cond(
                    E.object_count == 0,
                    rx.el.p(
                        S.copy["zero_objects"],
                        class_name="text-sm text-[#68767B]",
                    ),
                ),
                rx.el.div(
                    rx.foreach(
                        E.objects,
                        lambda n: rx.icon(
                            "leaf", key=n, class_name="size-9 text-[#397F78]"
                        ),
                    ),
                    class_name="flex flex-wrap justify-center gap-3",
                ),
                class_name="my-5",
            ),
        ),
        rx.cond(
            (E.mode == "vowel_listen")
            | (E.mode == "number_listen")
            | (E.mode == "color_listen")
            | (E.mode == "word_listen")
            | (E.mode == "dialogue"),
            rx.el.div(
                rx.cond(
                    E.mode == "dialogue",
                    rx.el.p(
                        E.target_arabic,
                        dir="rtl",
                        lang="ar",
                        class_name="mb-4 font-['Noto_Naskh_Arabic'] text-5xl leading-relaxed text-[#397F78]",
                    ),
                ),
                audio_button(E.audio, "listen"),
                rx.el.button(
                    S.copy["reveal_audio"],
                    on_click=E.reveal_text,
                    class_name="ml-3 px-3 py-3 text-xs text-[#397F78] underline underline-offset-4",
                ),
                rx.cond(
                    E.reveal,
                    rx.el.div(
                        rx.el.p(
                            E.target_arabic,
                            dir="rtl",
                            lang="ar",
                            class_name="mt-4 font-['Noto_Naskh_Arabic'] text-4xl text-[#397F78]",
                        ),
                        rx.el.p(
                            E.target_roman,
                            class_name="mt-2 text-sm text-[#68767B]",
                        ),
                    ),
                ),
            ),
        ),
        class_name="mb-6 text-center",
    )


def practice_card() -> rx.Component:
    return rx.el.div(
        rx.el.div(
            rx.foreach(E.modes, mode_button),
            class_name="mb-6 flex flex-wrap gap-2",
        ),
        rx.el.section(
            rx.el.div(
                rx.el.h2(
                    S.copy[E.mode],
                    class_name="text-xl font-semibold text-[#192B3A]",
                ),
                rx.el.span(
                    f"{S.copy['round']} {E.round_number}",
                    class_name="text-xs text-[#68767B]",
                ),
                class_name="flex items-center justify-between gap-3",
            ),
            rx.el.p(
                S.copy[
                    rx.cond(
                        E.mode == "ordering",
                        "ordering_help_short",
                        f"{E.mode}_help",
                    )
                ],
                class_name="mt-3 text-sm leading-7 text-[#68767B]",
            ),
            rx.el.p(
                f"{S.copy['session_score']} : {E.score} / {E.attempts}",
                class_name="my-5 rounded-xl bg-[#EAF1ED] p-4 text-sm font-semibold text-[#397F78]",
            ),
            rx.cond(
                (E.mode == "sentence_build") & (E.tiles.length() == 0),
                rx.el.p(
                    S.copy["sentence_empty"],
                    role="status",
                    class_name="rounded-xl bg-[#EAF1ED] p-5 text-sm leading-7 text-[#397F78]",
                ),
            ),
            activity_prompt(),
            rx.cond(
                E.tile_mode,
                rx.cond(E.tiles.length() > 0, tile_board()),
                rx.el.div(
                    rx.foreach(E.choices, answer_choice),
                    class_name="grid grid-cols-2 gap-3 lg:grid-cols-4",
                ),
            ),
            rx.cond(
                E.feedback != "",
                rx.el.div(
                    rx.el.p(
                        S.copy[E.feedback],
                        class_name="text-sm leading-7 text-[#192B3A]",
                    ),
                    rx.cond(
                        E.answered,
                        rx.el.div(
                            rx.el.p(
                                f"{S.copy['answer']} :",
                                class_name="mt-3 text-xs text-[#68767B]",
                            ),
                            rx.cond(
                                (E.mode == "sentence_build")
                                | (E.module == "grammar"),
                                rx.el.p(
                                    E.target_arabic,
                                    dir="rtl",
                                    lang="ar",
                                    class_name="mt-3 font-['Noto_Naskh_Arabic'] text-4xl leading-relaxed text-[#397F78]",
                                ),
                            ),
                            rx.el.p(
                                rx.cond(
                                    S.language == "fr", E.answer_fr, E.answer_en
                                ),
                                class_name="mt-2 text-lg leading-8 text-[#397F78]",
                            ),
                            rx.el.div(
                                audio_button(E.audio, "listen"),
                                class_name="mt-3",
                            ),
                        ),
                    ),
                    role="status",
                    aria_live="polite",
                    class_name="mt-5 rounded-xl bg-[#EAF1ED] p-4",
                ),
            ),
            rx.el.div(
                rx.el.button(
                    rx.icon("check", class_name="size-4"),
                    S.copy["check_answer"],
                    on_click=E.check_answer,
                    disabled=E.answered
                    | ((E.mode == "sentence_build") & (E.tiles.length() == 0)),
                    class_name="flex items-center gap-2 rounded-xl bg-[#397F78] px-4 py-3 text-sm font-semibold text-white hover:bg-[#2E6862] disabled:opacity-40",
                ),
                rx.el.button(
                    S.copy["another"],
                    rx.icon("arrow-right", class_name="size-4"),
                    on_click=E.next_round,
                    disabled=~E.answered,
                    class_name="flex items-center gap-2 rounded-xl border border-[#D6E3D9] bg-white px-4 py-3 text-sm font-semibold text-[#397F78] hover:bg-[#EAF1ED] disabled:opacity-40",
                ),
                rx.el.button(
                    S.copy["restart_game"],
                    on_click=E.start_mode(E.mode),
                    class_name="rounded-xl border border-[#D6E3D9] bg-white px-4 py-3 text-sm text-[#397F78] hover:bg-[#EAF1ED]",
                ),
                class_name="mt-5 flex flex-wrap gap-3",
            ),
            education_audio_status(),
            class_name="rounded-3xl border border-[#E0E2D9] bg-white/70 p-5 sm:p-8",
        ),
    )


def grammar_group(group: str) -> rx.Component:
    return rx.el.section(
        rx.el.h2(
            S.copy[f"grammar_{group}"],
            class_name="mb-4 text-lg font-semibold text-[#192B3A]",
        ),
        rx.el.div(
            rx.foreach(
                E.lessons,
                lambda item, index: rx.cond(
                    item["group"] == group, lesson_tile(item, index)
                ),
            ),
            class_name="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3",
        ),
        class_name="mb-7",
    )


def grammar_overview() -> rx.Component:
    return rx.el.div(
        rx.el.p(
            f"{S.selected_module['done']} / {S.selected_module['total']} · {S.copy['completed']}",
            class_name="mb-6 rounded-xl bg-[#EAF1ED] p-4 text-sm font-semibold text-[#397F78]",
        ),
        rx.foreach(E.grammar_groups, grammar_group),
    )


def education_path() -> rx.Component:
    return rx.el.div(
        rx.el.button(
            rx.icon("arrow-left", class_name="size-4"),
            S.copy["return_path"],
            on_click=S.back_to_path,
            class_name="mb-5 flex items-center gap-2 text-sm font-semibold text-[#397F78]",
        ),
        rx.el.h1(
            S.copy[f"module_{E.module}"],
            class_name="text-3xl font-semibold text-[#192B3A] sm:text-4xl",
        ),
        rx.el.p(
            S.copy["activities_access"],
            class_name="mb-6 mt-3 text-sm leading-7 text-[#68767B]",
        ),
        category_selector(),
        rx.el.div(
            rx.el.button(
                S.copy["lesson_view"],
                on_click=E.set_view("lesson"),
                class_name="rounded-xl border border-[#D6E3D9] bg-white px-4 py-3 text-sm text-[#397F78]",
            ),
            rx.el.button(
                S.copy["exercise_view"],
                on_click=E.set_view("practice"),
                class_name="rounded-xl border border-[#D6E3D9] bg-white px-4 py-3 text-sm text-[#397F78]",
            ),
            class_name="mb-6 flex gap-3",
        ),
        rx.cond(
            E.view == "lesson",
            rx.el.div(
                rx.cond(
                    E.module == "grammar",
                    grammar_overview(),
                    rx.el.div(
                        rx.foreach(E.lessons, lesson_tile),
                        class_name="mb-6 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5",
                    ),
                ),
                lesson_card(),
            ),
            practice_card(),
        ),
    )


def game_module_button(module: ModuleData) -> rx.Component:
    return rx.el.button(
        module["title"],
        on_click=S.choose_game_module(module["id"]),
        aria_pressed=S.game_module == module["id"],
        class_name=rx.cond(
            S.game_module == module["id"],
            "rounded-xl bg-[#192B3A] px-4 py-3 text-sm font-semibold text-[#F7F5EF]",
            "rounded-xl border border-[#E0E2D9] bg-white px-4 py-3 text-sm text-[#68767B] hover:border-[#397F78]",
        ),
    )


def game_module_selector() -> rx.Component:
    return rx.el.div(
        rx.foreach(S.game_modules, game_module_button),
        class_name="mb-7 flex flex-wrap gap-2",
    )


def education_games() -> rx.Component:
    return rx.el.div(
        rx.el.h1(
            S.copy[f"module_{E.module}"],
            class_name="mb-3 text-3xl font-semibold text-[#192B3A]",
        ),
        rx.el.p(
            S.copy["activities_access"],
            class_name="mb-6 text-sm leading-7 text-[#68767B]",
        ),
        category_selector(),
        practice_card(),
        rx.el.button(
            rx.icon("book-open", class_name="size-4"),
            S.copy["lesson_view"],
            on_click=S.open_module(S.game_module),
            class_name="mt-6 flex items-center gap-2 text-sm font-semibold text-[#397F78]",
        ),
    )
