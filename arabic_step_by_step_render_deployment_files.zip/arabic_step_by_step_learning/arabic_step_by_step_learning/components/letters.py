import reflex as rx
from arabic_step_by_step_learning.states.learning_state import LearningState as S
from arabic_step_by_step_learning.states.letters_state import LettersState as L, ChoiceData
from arabic_step_by_step_learning.states.letter_data import LetterData, POSITIONS


GAME_MODES: list[str] = ["find", "listen_game", "match", "memory", "odd"]


def audio_button(text: str, label: str) -> rx.Component:
    return rx.el.div(
        rx.el.button(
            rx.icon("volume-2", class_name="size-4"),
            rx.el.span(
                rx.icon(
                    "loader-circle",
                    class_name="size-3 animate-spin text-[#397F78]",
                ),
                aria_hidden="true",
                custom_attrs={"data-audio-spinner": "true"},
                class_name="hidden",
            ),
            S.copy[label],
            type="button",
            custom_attrs={
                "data-arabic-audio": text,
                "data-loading": rx.cond(
                    S.language == "fr",
                    "Chargement de l’audio…",
                    "Loading audio…",
                ),
                "data-unavailable": S.copy["audio_unavailable"],
                "data-error": S.copy["audio_error"],
                "data-muted": S.copy["audio_muted"],
            },
            class_name="inline-flex w-fit items-center justify-center gap-2 rounded-xl border border-[#D6E3D9] bg-[#EAF1ED] px-4 py-3 text-sm font-semibold text-[#397F78] hover:border-[#397F78] focus-visible:outline-2 focus-visible:outline-[#397F78]",
        ),
        rx.el.p(
            role="status",
            aria_live="polite",
            aria_atomic="true",
            custom_attrs={"data-audio-status": "true"},
            class_name="mt-1 max-w-72 text-xs leading-6 text-red-600 empty:hidden",
        ),
        custom_attrs={"data-audio-control": "true"},
        class_name="inline-flex w-fit flex-col items-center align-top",
    )


def audio_status() -> rx.Component:
    return rx.el.div(
        rx.el.p(
            S.copy["audio_note"], class_name="text-xs leading-6 text-[#68767B]"
        ),
        rx.el.p(
            id="letter-audio-status",
            role="status",
            aria_live="polite",
            class_name="mt-1 text-sm text-[#397F78]",
        ),
        class_name="mt-4",
    )


def letter_tile(letter: LetterData) -> rx.Component:
    return rx.el.button(
        rx.el.span(
            letter["isolated"],
            dir="rtl",
            lang="ar",
            class_name="block font-['Noto_Naskh_Arabic'] text-4xl leading-relaxed",
        ),
        rx.el.span(
            letter["romanization"], class_name="block text-[10px] sm:text-xs"
        ),
        on_click=L.select_letter(letter["id"]),
        aria_pressed=L.selected == letter["id"],
        aria_label=letter["romanization"],
        key=letter["id"],
        class_name=rx.cond(
            L.selected == letter["id"],
            "min-h-24 w-full rounded-2xl border-2 border-[#397F78] bg-[#EAF1ED] p-2 text-[#397F78] focus-visible:outline-2 focus-visible:outline-[#397F78]",
            "min-h-24 w-full rounded-2xl border border-[#E0E2D9] bg-white p-2 text-[#192B3A] hover:border-[#397F78] focus-visible:outline-2 focus-visible:outline-[#397F78]",
        ),
    )


def form_card(position: str) -> rx.Component:
    return rx.el.div(
        rx.el.p(
            S.copy[position], class_name="text-xs font-semibold text-[#68767B]"
        ),
        rx.cond(
            L.current[position].to(str) != "",
            rx.el.p(
                L.current[position].to(str),
                dir="rtl",
                lang="ar",
                class_name="my-3 font-['Noto_Naskh_Arabic'] text-5xl leading-relaxed text-[#397F78]",
            ),
            rx.el.div(
                rx.icon(
                    "minus", class_name="mx-auto my-4 size-6 text-[#84908E]"
                ),
                rx.el.p(
                    S.copy["unavailable"],
                    class_name="text-[10px] text-[#68767B]",
                ),
            ),
        ),
        class_name="min-h-36 rounded-2xl border border-[#D6E3D9] bg-[#F7F5EF] p-3 text-center",
    )


def form_answer(position: str) -> rx.Component:
    return rx.el.button(
        S.copy[position],
        on_click=L.answer_form(position),
        disabled=L.quiz_answer != "",
        class_name=rx.cond(
            (L.quiz_answer != "") & (L.quiz_position == position),
            "rounded-xl border-2 border-[#397F78] bg-[#EAF1ED] px-3 py-3 text-sm font-semibold text-[#397F78]",
            "rounded-xl border border-[#E0E2D9] bg-white px-3 py-3 text-sm text-[#192B3A] hover:border-[#397F78] disabled:opacity-60",
        ),
    )


def form_exercise() -> rx.Component:
    return rx.el.section(
        rx.el.div(
            rx.icon("scan-eye", class_name="size-5 text-[#397F78]"),
            rx.el.h2(
                S.copy["form_quiz"],
                class_name="text-xl font-semibold text-[#192B3A]",
            ),
            class_name="flex items-center gap-3",
        ),
        rx.el.p(
            S.copy["form_quiz_desc"],
            class_name="mt-2 text-sm leading-6 text-[#68767B]",
        ),
        rx.el.p(
            L.quiz_glyph,
            dir="rtl",
            lang="ar",
            class_name="py-5 text-center font-['Noto_Naskh_Arabic'] text-7xl text-[#397F78]",
        ),
        rx.el.div(
            rx.foreach(POSITIONS, form_answer),
            class_name="grid grid-cols-2 gap-3 sm:grid-cols-4",
        ),
        rx.cond(
            L.quiz_answer != "",
            rx.el.div(
                rx.el.p(
                    rx.cond(
                        L.quiz_answer == L.quiz_position,
                        S.copy["well_done"],
                        S.copy["try_again"],
                    ),
                    class_name="text-sm leading-6 text-[#192B3A]",
                ),
                rx.el.p(
                    f"{S.copy['answer']} : {S.copy[L.quiz_position]}",
                    class_name="mt-2 text-sm font-semibold text-[#397F78]",
                ),
                role="status",
                class_name="mt-4 rounded-xl bg-[#EAF1ED] p-4",
            ),
        ),
        rx.el.button(
            S.copy["another"],
            rx.icon("refresh-cw", class_name="size-4"),
            on_click=L.next_quiz,
            class_name="mt-4 flex items-center gap-2 rounded-xl bg-[#397F78] px-4 py-3 text-sm font-semibold text-white hover:bg-[#2E6862]",
        ),
        class_name="rounded-3xl border border-[#E0E2D9] bg-white/70 p-5 sm:p-7",
    )


def trace_mode_button(mode: str) -> rx.Component:
    return rx.el.button(
        S.copy[mode],
        on_click=L.choose_trace(mode),
        aria_pressed=L.trace_mode == mode,
        class_name=rx.cond(
            L.trace_mode == mode,
            "rounded-xl border border-[#397F78] bg-[#EAF1ED] px-3 py-2 text-xs font-semibold text-[#397F78]",
            "rounded-xl border border-[#E0E2D9] bg-white px-3 py-2 text-xs text-[#68767B] hover:border-[#397F78]",
        ),
    )


def tracing() -> rx.Component:
    return rx.el.section(
        rx.el.div(
            rx.icon("pencil", class_name="size-5 text-[#397F78]"),
            rx.el.h2(
                S.copy["trace"],
                class_name="text-xl font-semibold text-[#192B3A]",
            ),
            class_name="flex items-center gap-3",
        ),
        rx.el.p(
            S.copy["trace_help"],
            class_name="mt-3 text-sm leading-7 text-[#68767B]",
        ),
        rx.el.p(
            S.copy["trace_mode"],
            class_name="mb-3 mt-5 text-xs font-semibold text-[#192B3A]",
        ),
        rx.el.div(
            rx.foreach(L.trace_options, trace_mode_button),
            class_name="mb-4 flex flex-wrap gap-2",
        ),
        rx.el.div(
            rx.el.p(
                S.copy["start_marker"],
                class_name="mb-1 text-xs font-semibold text-[#397F78]",
            ),
            rx.el.canvas(
                id="letter-trace",
                width="720",
                height="340",
                aria_label=S.copy["trace"],
                custom_attrs={
                    "data-reference": L.trace_text,
                    "data-language": S.language,
                    "data-loading": S.copy["trace_loading"],
                    "data-ready": S.copy["trace_ready"],
                    "data-error": S.copy["trace_error"],
                    "data-good": S.copy["trace_good"],
                    "data-retry": S.copy["trace_retry"],
                },
                class_name="aspect-[720/340] w-full touch-none select-none rounded-2xl border border-[#D6E3D9] bg-[#F7F5EF]",
            ),
            class_name="w-full",
        ),
        rx.el.div(
            rx.el.span(S.copy["coverage"], class_name="text-xs text-[#68767B]"),
            rx.el.span(
                "0%",
                id="trace-coverage",
                class_name="text-sm font-semibold text-[#397F78]",
            ),
            class_name="mt-3 flex items-center justify-between",
        ),
        rx.el.p(
            id="trace-status",
            role="status",
            aria_live="polite",
            class_name="mt-3 min-h-12 text-sm leading-6 text-[#192B3A]",
        ),
        rx.el.div(
            rx.el.button(
                rx.icon("check", class_name="size-4"),
                S.copy["check_trace"],
                custom_attrs={"data-trace-action": "check"},
                on_click=rx.call_script(
                    "window.arabicLetterTools?.validate() || {}",
                    callback=L.validate_trace,
                ),
                class_name="flex items-center gap-2 rounded-xl bg-[#397F78] px-4 py-3 text-sm font-semibold text-white hover:bg-[#2E6862]",
            ),
            rx.el.button(
                rx.icon("rotate-ccw", class_name="size-4"),
                S.copy["reset_trace"],
                custom_attrs={"data-trace-action": "reset"},
                class_name="flex items-center gap-2 rounded-xl border border-[#D6E3D9] bg-white px-4 py-3 text-sm font-semibold text-[#397F78] hover:bg-[#EAF1ED]",
            ),
            class_name="flex flex-wrap gap-3",
        ),
        rx.el.p(
            S.copy["trace_honest"],
            class_name="mt-4 text-[11px] leading-6 text-[#68767B]",
        ),
        class_name="w-full rounded-3xl border border-[#E0E2D9] bg-white/70 p-5 sm:p-7",
    )


def letter_path() -> rx.Component:
    return rx.el.div(
        rx.el.button(
            rx.icon("arrow-left", class_name="size-4"),
            S.copy["return_path"],
            on_click=S.back_to_path,
            class_name="mb-5 flex items-center gap-2 text-sm font-semibold text-[#397F78] hover:text-[#192B3A]",
        ),
        rx.el.h1(
            rx.cond(
                S.chosen_module == "writing",
                S.copy["module_writing"],
                S.copy["letter_path"],
            ),
            class_name="text-3xl font-semibold tracking-tight text-[#192B3A] sm:text-4xl",
        ),
        rx.el.p(
            S.copy["letter_path_desc"],
            class_name="mb-6 mt-3 text-sm leading-7 text-[#68767B]",
        ),
        rx.el.div(
            rx.foreach(L.letters, letter_tile),
            dir="rtl",
            class_name="mb-7 grid grid-cols-4 gap-2 sm:grid-cols-7 lg:grid-cols-14",
        ),
        rx.el.section(
            rx.el.div(
                rx.el.button(
                    rx.icon("chevron-left", class_name="size-4"),
                    S.copy["previous"],
                    on_click=L.move_letter(-1),
                    disabled=L.selected == 0,
                    class_name="flex items-center gap-1 text-xs text-[#397F78] disabled:opacity-30",
                ),
                rx.el.span(
                    f"{S.copy['letter']} {L.selected + 1} / 28",
                    class_name="text-xs font-semibold text-[#68767B]",
                ),
                rx.el.button(
                    S.copy["next_letter"],
                    rx.icon("chevron-right", class_name="size-4"),
                    on_click=L.move_letter(1),
                    disabled=L.selected == 27,
                    class_name="flex items-center gap-1 text-xs text-[#397F78] disabled:opacity-30",
                ),
                class_name="mb-6 flex items-center justify-between gap-2",
            ),
            rx.el.div(
                rx.el.div(
                    rx.el.p(
                        L.current["isolated"],
                        dir="rtl",
                        lang="ar",
                        class_name="font-['Noto_Naskh_Arabic'] text-[120px] leading-relaxed text-[#397F78]",
                    ),
                    rx.el.p(
                        L.current["name"],
                        dir="rtl",
                        lang="ar",
                        class_name="font-['Noto_Naskh_Arabic'] text-3xl text-[#192B3A]",
                    ),
                    rx.el.h2(
                        L.current["romanization"],
                        class_name="mt-2 text-xl font-semibold text-[#192B3A]",
                    ),
                    rx.el.div(
                        audio_button(L.current["name"], "listen"),
                        audio_button(f"{L.current['glyph']}َ", "listen_sound"),
                        class_name="mt-4 flex flex-wrap justify-center gap-2",
                    ),
                    class_name="rounded-2xl bg-[#F7F5EF] p-5 text-center",
                ),
                rx.el.div(
                    rx.el.p(
                        S.copy["pronunciation"],
                        class_name="text-xs font-semibold uppercase tracking-wider text-[#397F78]",
                    ),
                    rx.el.p(
                        rx.cond(
                            S.language == "fr",
                            L.current["tip_fr"],
                            L.current["tip_en"],
                        ),
                        class_name="mt-3 text-sm leading-7 text-[#192B3A]",
                    ),
                    rx.el.p(
                        S.copy["example_word"],
                        class_name="mt-6 text-xs font-semibold uppercase tracking-wider text-[#397F78]",
                    ),
                    rx.el.p(
                        L.current["word"],
                        dir="rtl",
                        lang="ar",
                        class_name="my-3 text-left font-['Noto_Naskh_Arabic'] text-5xl leading-relaxed text-[#192B3A]",
                    ),
                    rx.el.p(
                        rx.cond(
                            S.language == "fr",
                            L.current["word_fr"],
                            L.current["word_en"],
                        ),
                        class_name="mb-4 text-sm text-[#68767B]",
                    ),
                    audio_button(L.current["word"], "listen_word"),
                    audio_status(),
                    class_name="py-4",
                ),
                class_name="grid gap-6 md:grid-cols-[1fr_1.5fr]",
            ),
            rx.el.h2(
                S.copy["forms"],
                class_name="mb-4 mt-7 text-xl font-semibold text-[#192B3A]",
            ),
            rx.el.div(
                rx.foreach(POSITIONS, form_card),
                class_name="grid grid-cols-2 gap-3 sm:grid-cols-4",
            ),
            rx.el.p(
                rx.cond(
                    L.current["joins"],
                    S.copy["joins_both"],
                    S.copy["joins_right"],
                ),
                class_name="mt-4 rounded-xl bg-[#EAF1ED] p-4 text-sm leading-6 text-[#397F78]",
            ),
            rx.el.button(
                rx.icon("check", class_name="size-4"),
                rx.cond(
                    S.progress_data["lessons"].contains(
                        f"letters:{L.selected}"
                    ),
                    S.copy["completed"],
                    S.copy["lesson_complete"],
                ),
                on_click=L.complete_lesson,
                disabled=S.progress_data["lessons"].contains(
                    f"letters:{L.selected}"
                ),
                class_name="mt-5 flex items-center gap-2 rounded-xl bg-[#397F78] px-5 py-3 text-sm font-semibold text-white disabled:opacity-50",
            ),
            rx.el.p(
                S.copy["form_note"],
                class_name="mt-3 text-xs leading-6 text-[#68767B]",
            ),
            class_name=rx.cond(
                S.chosen_module == "writing",
                "hidden",
                "mb-6 rounded-3xl border border-[#E0E2D9] bg-white/70 p-5 sm:p-8",
            ),
        ),
        rx.cond(
            S.chosen_module == "writing",
            rx.el.div(tracing(), class_name="mt-6"),
            form_exercise(),
        ),
        rx.cond(
            S.chosen_module != "writing",
            rx.el.div(tracing(), class_name="mt-6"),
        ),
        rx.el.button(
            rx.icon("shapes", class_name="size-5"),
            S.copy["play_letters"],
            on_click=S.choose_game_module("letters"),
            class_name="mt-6 flex w-fit items-center gap-3 rounded-xl bg-[#192B3A] px-5 py-4 text-sm font-semibold text-[#F7F5EF] hover:bg-[#397F78]",
        ),
    )


def game_mode(mode: str) -> rx.Component:
    return rx.el.button(
        S.copy[mode],
        on_click=L.start_game(mode),
        aria_pressed=L.game == mode,
        class_name=rx.cond(
            L.game == mode,
            "rounded-xl border border-[#397F78] bg-[#EAF1ED] px-4 py-3 text-sm font-semibold text-[#397F78]",
            "rounded-xl border border-[#E0E2D9] bg-white px-4 py-3 text-sm text-[#192B3A] hover:border-[#397F78]",
        ),
    )


def game_choice(card: ChoiceData) -> rx.Component:
    return rx.el.button(
        card["glyph"],
        dir="rtl",
        lang="ar",
        on_click=L.answer_game(card["id"]),
        disabled=L.answered,
        aria_label=card["glyph"],
        class_name=rx.cond(
            L.answered & (card["id"] == L.correct_choice),
            "min-h-32 rounded-2xl border-2 border-[#397F78] bg-[#EAF1ED] font-['Noto_Naskh_Arabic'] text-6xl text-[#397F78]",
            "min-h-32 rounded-2xl border border-[#D6E3D9] bg-white font-['Noto_Naskh_Arabic'] text-6xl text-[#192B3A] hover:border-[#397F78] disabled:opacity-60",
        ),
        key=card["id"],
    )


def memory_card(card: ChoiceData) -> rx.Component:
    return rx.el.button(
        rx.cond(
            L.flipped.contains(card["id"]) | L.matched.contains(card["id"]),
            rx.el.span(
                card["glyph"],
                dir="rtl",
                lang="ar",
                class_name="font-['Noto_Naskh_Arabic'] text-5xl",
            ),
            rx.icon("flower-2", class_name="size-7"),
        ),
        on_click=L.flip_card(card["id"]),
        disabled=L.matched.contains(card["id"]),
        aria_label=rx.cond(
            L.flipped.contains(card["id"]) | L.matched.contains(card["id"]),
            card["glyph"],
            S.copy["hidden_card"],
        ),
        class_name=rx.cond(
            L.matched.contains(card["id"]),
            "flex min-h-28 items-center justify-center rounded-2xl border-2 border-[#397F78] bg-[#EAF1ED] text-[#397F78]",
            "flex min-h-28 items-center justify-center rounded-2xl border border-[#D6E3D9] bg-[#F7F5EF] text-[#397F78] hover:border-[#397F78]",
        ),
        key=card["id"],
    )


def game_prompt() -> rx.Component:
    return rx.match(
        L.game,
        (
            "find",
            rx.el.div(
                rx.el.p(
                    L.target_letter["romanization"],
                    class_name="text-3xl font-semibold text-[#192B3A]",
                ),
                rx.el.p(
                    L.target_letter["name"],
                    dir="rtl",
                    lang="ar",
                    class_name="mt-3 font-['Noto_Naskh_Arabic'] text-4xl text-[#397F78]",
                ),
            ),
        ),
        (
            "listen_game",
            rx.el.div(
                audio_button(L.target_letter["name"], "listen"),
                rx.el.button(
                    S.copy["reveal_name"],
                    on_click=L.reveal_name,
                    class_name="ml-3 rounded-xl px-3 py-3 text-xs text-[#397F78] underline underline-offset-4",
                ),
                rx.cond(
                    L.reveal | L.answered,
                    rx.el.p(
                        L.target_letter["romanization"],
                        class_name="mt-4 text-xl font-semibold text-[#192B3A]",
                    ),
                ),
            ),
        ),
        (
            "match",
            rx.el.p(
                L.prompt_glyph,
                dir="rtl",
                lang="ar",
                class_name="font-['Noto_Naskh_Arabic'] text-8xl text-[#397F78]",
            ),
        ),
        rx.el.div(),
    )


def letter_games() -> rx.Component:
    return rx.el.div(
        rx.el.h1(
            S.copy["play_letters"],
            class_name="text-3xl font-semibold tracking-tight text-[#192B3A] sm:text-4xl",
        ),
        rx.el.p(
            S.copy["letter_games_desc"],
            class_name="mt-3 text-sm leading-7 text-[#68767B]",
        ),
        rx.el.p(
            S.copy["choose_game"],
            class_name="mb-3 mt-6 text-xs font-semibold text-[#397F78]",
        ),
        rx.el.div(
            rx.foreach(GAME_MODES, game_mode),
            class_name="mb-6 flex flex-wrap gap-2",
        ),
        rx.el.section(
            rx.el.div(
                rx.el.h2(
                    S.copy[L.game],
                    class_name="text-xl font-semibold text-[#192B3A]",
                ),
                rx.el.span(
                    f"{S.copy['round']} {L.round_number}",
                    class_name="text-xs text-[#68767B]",
                ),
                class_name="flex items-center justify-between gap-3",
            ),
            rx.el.p(
                S.copy[f"{L.game}_help"],
                class_name="mt-3 text-sm leading-7 text-[#68767B]",
            ),
            rx.el.div(
                rx.el.span(
                    f"{S.copy['score']} : {L.score}",
                    class_name="text-sm font-semibold text-[#397F78]",
                ),
                rx.el.span(
                    f"{S.copy['attempts']} : {L.attempts}",
                    class_name="text-sm text-[#68767B]",
                ),
                rx.cond(
                    L.game == "memory",
                    rx.el.span(
                        f"{S.copy['pairs']} : {L.matched.length() // 2} / 4",
                        class_name="text-sm text-[#397F78]",
                    ),
                ),
                class_name="my-5 flex flex-wrap gap-5 rounded-xl bg-[#EAF1ED] p-4",
            ),
            rx.cond(
                L.game == "memory",
                rx.el.div(
                    rx.foreach(L.memory_cards, memory_card),
                    class_name="grid grid-cols-4 gap-2 sm:gap-4",
                ),
                rx.el.div(
                    rx.el.div(
                        game_prompt(), class_name="mb-6 min-h-20 text-center"
                    ),
                    rx.el.div(
                        rx.foreach(L.choices, game_choice),
                        class_name="grid grid-cols-2 gap-3 sm:grid-cols-4",
                    ),
                ),
            ),
            rx.cond(
                L.feedback != "",
                rx.el.div(
                    rx.el.p(
                        S.copy[L.feedback],
                        class_name="text-sm leading-6 text-[#192B3A]",
                    ),
                    rx.cond(
                        L.answered,
                        rx.el.p(
                            S.copy["answer"],
                            " : ",
                            rx.cond(
                                L.game == "odd",
                                L.choices[L.correct_choice]["glyph"],
                                L.target_letter["isolated"],
                            ),
                            " · ",
                            rx.cond(
                                L.game == "odd",
                                L.letters[
                                    L.choices[L.correct_choice]["letter_id"]
                                ]["romanization"],
                                L.target_letter["romanization"],
                            ),
                            class_name="mt-2 text-sm font-semibold text-[#397F78]",
                        ),
                    ),
                    role="status",
                    class_name="mt-5 rounded-xl bg-[#EAF1ED] p-4",
                ),
            ),
            rx.el.div(
                rx.el.button(
                    rx.cond(
                        L.game == "memory",
                        S.copy["new_board"],
                        S.copy["another"],
                    ),
                    rx.icon("arrow-right", class_name="size-4"),
                    on_click=L.next_round,
                    disabled=~(L.answered | L.memory_complete),
                    class_name="flex items-center gap-2 rounded-xl bg-[#397F78] px-4 py-3 text-sm font-semibold text-white hover:bg-[#2E6862] disabled:opacity-40",
                ),
                rx.el.button(
                    S.copy["restart_game"],
                    rx.icon("refresh-cw", class_name="size-4"),
                    on_click=L.start_game(L.game),
                    class_name="flex items-center gap-2 rounded-xl border border-[#D6E3D9] bg-white px-4 py-3 text-sm text-[#397F78] hover:bg-[#EAF1ED]",
                ),
                class_name="mt-5 flex flex-wrap gap-3",
            ),
            audio_status(),
            class_name="rounded-3xl border border-[#E0E2D9] bg-white/70 p-5 sm:p-8",
        ),
        rx.el.button(
            rx.icon("book-open", class_name="size-4"),
            S.copy["explore_letters"],
            on_click=S.open_module("letters"),
            class_name="mt-6 flex items-center gap-2 text-sm font-semibold text-[#397F78] hover:text-[#192B3A]",
        ),
        on_mount=L.ensure_game,
    )
