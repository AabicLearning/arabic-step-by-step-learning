import reflex as rx

from arabic_step_by_step_learning.states.learning_state import LearningState as S


def installation_settings() -> rx.Component:
    return rx.el.section(
        rx.el.div(
            rx.icon("smartphone", class_name="size-5 shrink-0 text-[#397F78]"),
            rx.el.h2(
                rx.cond(
                    S.language == "fr",
                    "Installer l’application",
                    "Install the app",
                ),
                id="pwa-settings-title",
                class_name="text-base font-semibold text-[#192B3A]",
            ),
            class_name="mb-5 flex items-center gap-3",
        ),
        rx.el.p(
            rx.cond(
                S.language == "fr",
                "Gardez Arabic Step by Step sur votre écran d’accueil. Préparez séparément les leçons et audios ci-dessous pour apprendre sans connexion dans le lecteur hors ligne.",
                "Keep Arabic Step by Step on your home screen. Prepare lessons and audio below separately to learn without a connection in the standalone offline player.",
            ),
            class_name="text-sm leading-7 text-[#68767B]",
        ),
        rx.el.div(
            rx.el.div(
                rx.icon(
                    "download", class_name="mt-1 size-4 shrink-0 text-[#397F78]"
                ),
                rx.el.p(
                    rx.el.strong(
                        "Android · ", class_name="font-semibold text-[#192B3A]"
                    ),
                    rx.cond(
                        S.language == "fr",
                        "Utilisez le bouton Installer lorsqu’il est proposé, ou le menu du navigateur > Installer l’application / Ajouter à l’écran d’accueil. L’invitation dépend du navigateur.",
                        "Use the Install button when offered, or your browser menu > Install app / Add to Home screen. The prompt depends on your browser.",
                    ),
                    class_name="text-xs leading-6 text-[#68767B]",
                ),
                class_name="flex items-start gap-3",
            ),
            rx.el.div(
                rx.icon(
                    "share", class_name="mt-1 size-4 shrink-0 text-[#397F78]"
                ),
                rx.el.p(
                    rx.el.strong(
                        "iPhone · ", class_name="font-semibold text-[#192B3A]"
                    ),
                    rx.cond(
                        S.language == "fr",
                        "Dans Safari, ouvrez Partager > Sur l’écran d’accueil > Ajouter. Aucun bouton ne peut ouvrir automatiquement cette installation. Selon votre version d’iOS, d’autres navigateurs proposent aussi cette option.",
                        "In Safari, open Share > Add to Home Screen > Add. There is no automatic iPhone install prompt. Other browsers may offer this too, depending on your iOS version.",
                    ),
                    class_name="text-xs leading-6 text-[#68767B]",
                ),
                class_name="flex items-start gap-3",
            ),
            class_name="mt-5 flex flex-col gap-4",
        ),
        rx.el.div(
            rx.el.p(
                rx.cond(
                    S.language == "fr",
                    "Vérification de ce navigateur…",
                    "Checking this browser…",
                ),
                custom_attrs={"data-pwa-capability": ""},
                class_name="text-xs leading-6 text-[#397F78]",
            ),
            rx.el.p(
                rx.cond(
                    S.language == "fr",
                    "Les leçons et audios hors ligne ne sont pas encore vérifiés.",
                    "Offline lessons and audio have not been verified yet.",
                ),
                custom_attrs={"data-pwa-shell": ""},
                class_name="mt-2 text-xs leading-6 text-[#68767B]",
            ),
            rx.el.p(
                rx.cond(
                    S.language == "fr",
                    "Préparation des leçons et audios…",
                    "Preparing lessons and audio…",
                ),
                custom_attrs={"data-pwa-download-status": ""},
                class_name="mt-2 text-xs leading-6 text-[#397F78]",
            ),
            rx.el.p(
                rx.cond(
                    S.language == "fr",
                    "L’installation dépend de votre navigateur.",
                    "Installation availability depends on your browser.",
                ),
                custom_attrs={"data-pwa-install-status": ""},
                class_name="mt-2 text-xs leading-6 text-[#68767B]",
            ),
            role="status",
            aria_live="polite",
            aria_atomic=True,
            class_name="mt-5 rounded-2xl border border-[#D6E3D9] bg-[#EAF1ED] p-4",
        ),
        rx.el.div(
            rx.el.button(
                rx.cond(
                    S.language == "fr",
                    "Installer Arabic Step by Step",
                    "Install Arabic Step by Step",
                ),
                type="button",
                hidden=True,
                custom_attrs={"data-pwa-action": "install"},
                class_name="min-h-12 w-fit rounded-xl bg-[#397F78] px-5 py-3 text-sm font-semibold text-white transition-colors hover:bg-[#2E6862] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#397F78] disabled:opacity-60 [&[hidden]]:hidden",
            ),
            rx.el.button(
                rx.cond(
                    S.language == "fr",
                    "Vérifier le téléchargement hors ligne",
                    "Verify offline download",
                ),
                type="button",
                custom_attrs={"data-pwa-action": "check"},
                class_name="min-h-12 w-fit rounded-xl border border-[#D6E3D9] bg-[#F7F5EF] px-4 py-3 text-sm font-semibold text-[#397F78] transition-colors hover:bg-[#EAF1ED] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#397F78] disabled:opacity-60",
            ),
            rx.el.button(
                rx.cond(
                    S.language == "fr",
                    "Télécharger / Réessayer les leçons et audios",
                    "Download / Retry lessons and audio",
                ),
                type="button",
                custom_attrs={"data-pwa-action": "download"},
                class_name="min-h-12 w-fit rounded-xl bg-[#397F78] px-5 py-3 text-sm font-semibold text-white hover:bg-[#2E6862] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#397F78] disabled:opacity-60",
            ),
            rx.el.a(
                rx.cond(
                    S.language == "fr",
                    "Ouvrir les leçons hors ligne ↗",
                    "Open offline lessons ↗",
                ),
                href="/offline.html",
                class_name="flex min-h-12 w-fit items-center rounded-xl border border-[#D6E3D9] bg-[#F7F5EF] px-4 py-3 text-sm font-semibold text-[#397F78] hover:bg-[#EAF1ED] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#397F78]",
            ),
            class_name="mt-5 flex flex-wrap gap-3",
        ),
        rx.el.p(
            rx.cond(
                S.language == "fr",
                "Le lecteur hors ligne fonctionne sans serveur, avec les mêmes progrès locaux. Ses prérequis restent distincts de l’accès libre aux modules en ligne. Attendez la vérification complète avant de déconnecter. Un téléchargement partiel permet seulement les éléments déjà enregistrés ; le stockage du navigateur peut être effacé. Les tracés hors ligne sont un entraînement personnel sans validation.",
                "The offline player works without a server, with the same local progress. Its prerequisites remain separate from the open-access online modules. Wait for full verification before disconnecting. Partial downloads provide only saved assets; browsers may clear storage. Offline writing is self-practice without validation.",
            ),
            class_name="mt-5 text-xs leading-6 text-[#68767B]",
        ),
        rx.el.noscript(
            rx.cond(
                S.language == "fr",
                "Activez JavaScript pour vérifier la page hors ligne. Sur iPhone, utilisez Partager > Sur l’écran d’accueil.",
                "Enable JavaScript to check the offline shell. On iPhone, use Share > Add to Home Screen.",
            ),
        ),
        lang=rx.cond(S.language == "fr", "fr", "en"),
        aria_labelledby="pwa-settings-title",
        custom_attrs={"data-pwa-card": ""},
        class_name="mt-5 rounded-3xl border border-[#E0E2D9] bg-white/70 p-6 sm:p-8",
    )
