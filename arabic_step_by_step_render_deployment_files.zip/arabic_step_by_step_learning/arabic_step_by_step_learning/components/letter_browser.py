import reflex as rx


BROWSER_SCRIPT = r"""
(() => {
  if (window.arabicLetterTools) { window.arabicLetterTools.refresh(); return; }
  let generation = 0, activeKey = '', trace = null;
  let activeAudio = null, audioTimer = null, audioSession = null;
  const setLoading = (session, loading) => {
    session.button.querySelector('[data-audio-spinner]')?.classList.toggle('hidden', !loading);
    if (loading) session.button.setAttribute('aria-busy', 'true');
    else session.button.removeAttribute('aria-busy');
    if (session.out) {
      session.out.classList.toggle('text-red-600', !loading);
      session.out.classList.toggle('text-[#397F78]', loading);
      session.out.textContent = loading ? session.button.getAttribute('data-loading') || '' : '';
    }
  };
  const stopAudio = () => {
    clearTimeout(audioTimer); audioTimer = null;
    const clip = activeAudio, session = audioSession;
    activeAudio = null; audioSession = null;
    if (session) setLoading(session, false);
    if (clip) {
      clip.onerror = clip.onplaying = clip.onwaiting = clip.onended = null;
      clip.pause(); clip.removeAttribute('src'); clip.load();
    }
  };
  const audioFilename = text => {
    text = text.normalize('NFC');
    let hash = 0x811c9dc5;
    for (let i = 0; i < text.length; i++) hash = Math.imul(hash ^ text.charCodeAt(i), 0x01000193) >>> 0;
    return hash.toString(16).padStart(8, '0') + '.mp3';
  };
  window.addEventListener('storage', e => {
    if (e.key === 'arabic_steps_sound' && e.newValue === 'off') stopAudio();
  });
  window.addEventListener('pagehide', stopAudio);
  const messages = (el, key) => el?.getAttribute('data-' + key) || '';
  const refresh = () => {
    if (audioSession && (!audioSession.button.isConnected ||
        audioSession.button.getAttribute('data-arabic-audio') !== audioSession.text)) stopAudio();
    const canvas = document.getElementById('letter-trace');
    if (!canvas) { activeKey = ''; trace = null; return; }
    const key = canvas.getAttribute('data-reference') + '|' + canvas.getAttribute('data-language');
    if (trace?.canvas === canvas && activeKey === key) return;
    activeKey = key;
    const token = ++generation;
    const status = document.getElementById('trace-status');
    if (status) status.textContent = messages(canvas, 'loading');
    const text = canvas.getAttribute('data-reference');
    document.fonts.load('180px "Noto Naskh Arabic"', text).then(() => {
      if (token !== generation || !canvas.isConnected) return;
      const w = 720, h = 340;
      canvas.width = w; canvas.height = h;
      const ctx = canvas.getContext('2d');
      const mask = document.createElement('canvas'); mask.width = w; mask.height = h;
      const m = mask.getContext('2d');
      m.direction = 'rtl'; m.textAlign = 'center'; m.textBaseline = 'middle';
      let font = 195;
      m.font = font + 'px "Noto Naskh Arabic"';
      while (m.measureText(text).width > 620 && font > 55) {
        font -= 5; m.font = font + 'px "Noto Naskh Arabic"';
      }
      m.fillText(text, w / 2, h / 2);
      const pixels = m.getImageData(0, 0, w, h).data;
      const points = [];
      for (let y = 24; y < h - 24; y += 7) for (let x = 24; x < w - 24; x += 7) {
        if (pixels[(y * w + x) * 4 + 3] > 100) points.push({x, y});
      }
      if (!points.length) throw new Error('Empty writing guide');
      const right = Math.max(...points.map(p => p.x));
      const start = points.filter(p => p.x >= right - 14).sort((a,b) => a.y - b.y)[0];
      trace = {canvas, ctx, points, start, hit: new Set(), total: 0, near: 0, length: 0, began: false, down: false, last: null};
      const paint = () => {
        ctx.clearRect(0, 0, w, h);
        ctx.fillStyle = '#F7F5EF'; ctx.fillRect(0, 0, w, h);
        ctx.strokeStyle = '#D6E3D9'; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(20, 245); ctx.lineTo(700, 245); ctx.stroke();
        ctx.fillStyle = '#9BBDB4';
        points.forEach(p => { ctx.beginPath(); ctx.arc(p.x, p.y, 1.5, 0, Math.PI*2); ctx.fill(); });
        ctx.strokeStyle = '#397F78'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(start.x, start.y, 13, 0, Math.PI*2); ctx.stroke();
        ctx.fillStyle = '#397F78'; ctx.font = '24px sans-serif'; ctx.textAlign = 'center';
        ctx.fillText('←', Math.min(680, start.x + 35), Math.max(24, start.y - 12));
      };
      trace.paint = paint; paint();
      if (status) status.textContent = messages(canvas, 'ready');
      const coverage = document.getElementById('trace-coverage');
      if (coverage) coverage.textContent = '0%';
      const position = e => {
        const r = canvas.getBoundingClientRect();
        return {x: (e.clientX-r.left)*w/r.width, y: (e.clientY-r.top)*h/r.height};
      };
      const sample = p => {
        let near = false;
        points.forEach((q,i) => { if (Math.hypot(p.x-q.x,p.y-q.y) <= 13) { trace.hit.add(i); near = true; } });
        trace.total++; if (near) trace.near++;
        if (Math.hypot(p.x-start.x,p.y-start.y) < 30) trace.began = true;
      };
      canvas.onpointerdown = e => {
        if (trace?.canvas !== canvas) return;
        e.preventDefault(); canvas.setPointerCapture(e.pointerId);
        trace.down = true; trace.last = position(e); sample(trace.last);
        ctx.fillStyle = '#397F78'; ctx.beginPath(); ctx.arc(trace.last.x,trace.last.y,4,0,Math.PI*2); ctx.fill();
      };
      canvas.onpointermove = e => {
        if (!trace?.down || trace.canvas !== canvas) return;
        e.preventDefault();
        const p = position(e), prev = trace.last;
        const distance = Math.hypot(p.x-prev.x,p.y-prev.y);
        trace.length += distance;
        const count = Math.max(1, Math.ceil(distance / 4));
        for (let i=1;i<=count;i++) sample({x:prev.x+(p.x-prev.x)*i/count,y:prev.y+(p.y-prev.y)*i/count});
        ctx.strokeStyle = '#397F78'; ctx.lineWidth = 7; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
        ctx.beginPath(); ctx.moveTo(prev.x,prev.y); ctx.lineTo(p.x,p.y); ctx.stroke(); trace.last = p;
        if (coverage) coverage.textContent = Math.round(100*trace.hit.size/points.length) + '%';
      };
      canvas.onpointerup = canvas.onpointercancel = () => { if (trace) { trace.down = false; trace.last = null; } };
    }).catch(() => { if (token === generation && status) status.textContent = messages(canvas, 'error'); });
  };
  document.addEventListener('click', e => {
    const audio = e.target instanceof Element ? e.target.closest('[data-arabic-audio]') : null;
    if (audio) {
      const out = audio.closest('[data-audio-control]')?.querySelector('[data-audio-status]');
      const report = key => { if (out && audio.isConnected) out.textContent = messages(audio,key); };
      stopAudio();
      if (out) out.textContent = '';
      try {
        if (localStorage.getItem('arabic_steps_sound') === 'off') { report('muted'); return; }
        const text = audio.getAttribute('data-arabic-audio') || '';
        if (!text) { report('unavailable'); return; }
        const clip = new Audio(`https://translate.google.com/translate_tts?ie=UTF-8&q=${encodeURIComponent(text)}&tl=ar&client=tw-ob`);
        const session = {button: audio, out, text, local: false, attempt: 0};
        activeAudio = clip; audioSession = session;
        const current = () => {
          if (audioSession !== session || activeAudio !== clip) return false;
          if (!audio.isConnected || audio.getAttribute('data-arabic-audio') !== text) {
            stopAudio(); return false;
          }
          if (localStorage.getItem('arabic_steps_sound') === 'off') {
            stopAudio(); report('muted'); return false;
          }
          return true;
        };
        const finish = key => { stopAudio(); report(key); };
        const startAttempt = () => {
          const attempt = ++session.attempt;
          const valid = () => current() && session.attempt === attempt;
          const fail = key => {
            if (!valid()) return;
            clearTimeout(audioTimer); audioTimer = null;
            if (session.local) { finish(key); return; }
            session.local = true;
            clip.onerror = clip.onplaying = clip.onwaiting = clip.onended = null;
            clip.pause();
            clip.src = '/arabic_audio/' + audioFilename(text);
            clip.load();
            startAttempt();
          };
          const waiting = () => {
            if (!valid()) return;
            setLoading(session, true);
            if (audioTimer === null) audioTimer = setTimeout(() => fail('error'), session.local ? 20000 : 8000);
          };
          clip.onerror = () => fail('unavailable');
          clip.onwaiting = waiting;
          clip.onplaying = () => {
            if (!valid()) return;
            clearTimeout(audioTimer); audioTimer = null;
            setLoading(session, false);
          };
          clip.onended = () => { if (valid()) stopAudio(); };
          waiting();
          try {
            const playback = clip.play();
            if (playback?.catch) playback.catch(() => fail('error'));
          } catch (_) { fail('error'); }
        };
        startAttempt();
      } catch (_) { stopAudio(); report('error'); }
    }
    const action = e.target.closest('[data-trace-action]')?.getAttribute('data-trace-action');
    if (action && trace) {
      const status = document.getElementById('trace-status');
      if (action === 'reset') {
        trace.hit.clear(); trace.total=0; trace.near=0; trace.length=0; trace.began=false; trace.down=false; trace.paint();
        document.getElementById('trace-coverage').textContent='0%';
        status.textContent=messages(trace.canvas,'ready');
      } else {
        const ok = trace.hit.size/trace.points.length >= .65 && trace.near/Math.max(1,trace.total) >= .55 && trace.length >= 80 && trace.began;
        status.textContent = messages(trace.canvas,ok ? 'good' : 'retry');
      }
    }
  });
  let scheduled = false;
  const observer = new MutationObserver(() => {
    if (scheduled) return; scheduled = true;
    requestAnimationFrame(() => { scheduled = false; refresh(); });
  });
  observer.observe(document.body,{childList:true,subtree:true,attributes:true,attributeFilter:['data-reference','data-language','data-arabic-audio']});
  const validate = () => {
    if (!trace || !trace.canvas.isConnected) return {};
    const coverage = trace.hit.size / trace.points.length;
    const precision = trace.near / Math.max(1, trace.total);
    const passed = coverage >= .65 && precision >= .55 && trace.length >= 80 && trace.began;
    return {reference: trace.canvas.getAttribute('data-reference'), coverage, precision, length: trace.length, began: trace.began, passed};
  };
  window.arabicLetterTools = {refresh, validate, stopAudio, audioFilename}; refresh();
})();
"""


def browser_tools() -> rx.Component:
    return rx.el.div(
        on_mount=rx.call_script(BROWSER_SCRIPT), class_name="hidden"
    )
