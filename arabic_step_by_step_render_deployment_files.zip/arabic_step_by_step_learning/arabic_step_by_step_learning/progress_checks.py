import reflex as rx
import json
from arabic_step_by_step_learning.states.learning_state import LearningState
from arabic_step_by_step_learning.states.progress_data import lesson_ids
from arabic_step_by_step_learning.states.translations import COPY, MODULES


def check_progress(state: LearningState):
    state.progress_json = "{}"
    assert all(state._available(row[0]) for row in MODULES)
    assert not state._available("unknown")
    assert state.stars == state.completed_total == 0
    assert not state.progress_data["modules"]
    state._record("unknown", "0", lesson=True, exercise="invalid")
    assert state.progress_json == "{}"
    for i in range(3):
        state._record("letters", str(i), lesson=True)
    assert state._available("harakat") and state._available("writing")
    assert state._available("grammar")
    assert state.stars == 15
    state._record("letters", "0", lesson=True)
    assert state.stars == 15
    for i in range(3, 28):
        state._record("letters", str(i), lesson=True)
    assert state.stars == 160
    state._record("letters", "27", lesson=True)
    assert state.stars == 160
    for module in (
        "harakat",
        "grammar",
        "numbers",
        "colors",
        "vocabulary",
        "phrases",
        "writing",
        "games",
    ):
        assert state._available(module)
        for item in lesson_ids(module):
            state._record(module, item, lesson=True)
    assert state.overall_percent == 100
    assert len(state.progress_data["modules"]) == len(MODULES)
    total = sum(len(lesson_ids(row[0])) for row in MODULES)
    assert state.stars == total * 5 + 20 * len(MODULES)
    saved = state.progress_json
    state._record("letters", "1", exercise="form:1:final")
    state._record("letters", "1", exercise="form:1:final")
    assert state.stars == total * 5 + 20 * len(MODULES) + 2
    assert len(state.progress_data["exercises"]) == 1
    assert len(json.loads(state.progress_json)["answers"]) == 2
    state.progress_json = saved
    assert state.overall_percent == 100
    state.progress_json = "{}"


def check_daily(state: LearningState):
    assert COPY["brand"] == ("Arabic Step by Step", "Arabic Step by Step")
    assert COPY["tagline"] == (
        "Learn Arabic. Read it. Write it. Speak it.",
        "Learn Arabic. Read it. Write it. Speak it.",
    )
    for language in ("en", "fr"):
        state.language = language
        state.progress_json = "{}"
        assert state.daily_ready and state.completed_total == 0
        available = (
            "harakat",
            "writing",
            "numbers",
            "colors",
            "vocabulary",
            "phrases",
            "games",
        )
        assert all(state._available(module) for module in available)
        LearningState.set_browser_date.fn(state, "2026-06-01")
        for index in range(5):
            assert state.daily_index == index and not state.daily_done
            assert len(state.daily_choices) == 4
            assert state.daily_prompt and state.daily_audio
            assert state.daily_correct_answer in state.daily_choices
            prompt_key = (
                "daily_letter"
                if index < 2
                else "daily_sound"
                if index == 2
                else "daily_word"
                if index == 3
                else "daily_number"
            )
            assert state.daily_prompt.startswith(state.copy[prompt_key])
            wrong = next(
                choice
                for choice in state.daily_choices
                if choice != state.daily_correct_answer
            )
            before = state.progress_json
            LearningState.answer_daily.fn(state, wrong)
            assert (
                state.progress_json == before
                and state.daily_feedback == "daily_retry"
            )
            LearningState.answer_daily.fn(state, state.daily_correct_answer)
            assert state.daily_index == index + 1 and state.stars == index + 1
            before = state.progress_json
            LearningState.answer_daily.fn(state, state.daily_correct_answer)
            assert state.progress_json == before
            LearningState.next_daily.fn(state)
            if index == 1:
                LearningState.set_browser_date.fn(state, "2026-06-01")
                assert state.daily_index == 2
        assert state.daily_done and state.streak == 1
        assert len(state.progress_data["daily"]) == 5
        assert len(state.progress_data["exercises"]) == 5
        assert len(state.progress_data["words"]) == 1
        assert state.completed_total == 0 and state.overall_percent == 0
        assert all(not state._available(module) for module in locked)
        saved = state.progress_json
        LearningState.set_browser_date.fn(state, "2026-06-01")
        LearningState.answer_daily.fn(state, state.daily_correct_answer)
        assert state.progress_json == saved
        restored = LearningState(progress_json=saved)
        restored.browser_date = "2026-06-01"
        assert (
            restored.daily_done
            & (restored.daily_index == 5)
            & (restored.stars == 5)
        )
        LearningState.set_browser_date.fn(state, "2026-06-02")
        assert state.daily_index == 0 and not state.daily_done
        for _ in range(5):
            LearningState.answer_daily.fn(state, state.daily_correct_answer)
            LearningState.next_daily.fn(state)
        assert state.daily_done and state.streak == 2 and state.stars == 10
        assert state.progress_data["days"] == ["2026-06-01", "2026-06-02"]
    state.progress_json = "{}"
    data = state.progress_data
    data["days"] = ["2026-06-01", "2026-06-02", "2026-06-03"]
    state._save_progress(data)
    state.browser_date = "2026-06-03"
    assert state.streak == 3
    state.browser_date = "2026-06-04"
    assert state.streak == 3
    state.browser_date = "2026-06-05"
    assert state.streak == 0
    state.progress_json = "{}"
