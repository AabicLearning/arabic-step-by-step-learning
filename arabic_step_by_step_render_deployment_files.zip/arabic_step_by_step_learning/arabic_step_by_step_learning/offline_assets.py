import reflex as rx

import hashlib
import json
from pathlib import Path

from arabic_step_by_step_learning.offline_player import OFFLINE_HTML, OFFLINE_CSS, OFFLINE_SCRIPT
from arabic_step_by_step_learning.states.audio_catalog import audio_filename, source_catalog
from arabic_step_by_step_learning.states.education_data import LESSONS, GAME_MODES, EDUCATION_COPY
from arabic_step_by_step_learning.states.grammar_data import GRAMMAR_GROUPS, GRAMMAR_QUESTIONS
from arabic_step_by_step_learning.states.letter_data import LETTERS, POSITIONS, LETTER_COPY
from arabic_step_by_step_learning.states.phrases_data import DIALOGUES, SENTENCES
from arabic_step_by_step_learning.states.progress_data import lesson_ids, PROGRESS_COPY
from arabic_step_by_step_learning.states.translations import COPY, MODULES
from arabic_step_by_step_learning.states.vocabulary_data import CATEGORIES


WORKER = r""""use strict";
const VERSION=__VERSION__, PREFIX='arabic-step-learning-', CACHE=PREFIX+VERSION;
const SHELL=__SHELL__, AUDIO=__AUDIO__, META=__META__;
const OFFLINE='/offline.html', PATHS=new Set([...SHELL,...AUDIO]);
let downloadTask=null, downloadError='';
function mimeOK(path,mime){return path.endsWith('.mp3')?/audio\/(mpeg|mp3)/i.test(mime):path.endsWith('.json')?/application\/json/i.test(mime):path.endsWith('.js')?/(javascript|ecmascript)/i.test(mime):path.endsWith('.css')?/text\/css/i.test(mime):path.endsWith('.png')?/image\/png/i.test(mime):path.endsWith('.jpg')?/image\/jpeg/i.test(mime):path.endsWith('.webmanifest')?/json|manifest/i.test(mime):/text\/html/i.test(mime);}
async function valid(path,response){if(!response||response.status!==200||response.redirected||!mimeOK(path,response.headers.get('content-type')||''))return false;const body=await response.clone().arrayBuffer();if(!body.byteLength)return false;const expected=META[path];if(expected){if(body.byteLength!==expected.size)return false;const hash=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',body)),b=>b.toString(16).padStart(2,'0')).join('');if(hash!==expected.hash)return false;}if(path===OFFLINE&&!new TextDecoder().decode(body).includes('arabic-step-offline-v2'))return false;return true;}
async function fetchAsset(path){const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),25000);try{const response=await fetch(path,{cache:'reload',signal:controller.signal});if(!await valid(path,response))throw Error('Asset unavailable, incomplete or wrong version: '+path);return response;}finally{clearTimeout(timer);}}
async function inventory(){const cache=await caches.open(CACHE);let shell=0,audio=0;for(const path of SHELL){if(await valid(path,await cache.match(path)))shell++;}for(let i=0;i<AUDIO.length;i+=4){const batch=await Promise.all(AUDIO.slice(i,i+4).map(async path=>await valid(path,await cache.match(path))));audio+=batch.filter(Boolean).length;}return {type:'ARABIC_STEP_SHELL_STATUS',version:VERSION,ready:shell===SHELL.length&&audio===AUDIO.length,shellReady:shell===SHELL.length,audio,total:AUDIO.length,downloading:!!downloadTask,error:downloadError};}
async function notify(){const status=await inventory();const clients=await self.clients.matchAll({includeUncontrolled:true,type:'window'});clients.forEach(client=>client.postMessage(status));return status;}
async function prepare(){const cache=await caches.open(CACHE);downloadError='';try{for(const path of SHELL){if(!await valid(path,await cache.match(path)))await cache.put(path,await fetchAsset(path));}for(let i=0;i<AUDIO.length;i+=4){const results=await Promise.allSettled(AUDIO.slice(i,i+4).map(async path=>{if(!await valid(path,await cache.match(path)))await cache.put(path,await fetchAsset(path));}));await notify();const failure=results.find(r=>r.status==='rejected');if(failure)throw failure.reason;}}catch(e){downloadError=e.name==='QuotaExceededError'?'quota':'partial';console.warn('Offline download incomplete',e);}const status=await inventory();if(status.ready){const keys=await caches.keys();await Promise.all(keys.filter(k=>(k.startsWith(PREFIX)||k.startsWith('arabic-step-install-shell-'))&&k!==CACHE).map(k=>caches.delete(k)));}return status;}
self.addEventListener('install',event=>event.waitUntil((async()=>{const cache=await caches.open(CACHE);for(const path of SHELL)await cache.put(path,await fetchAsset(path));await self.skipWaiting();})()));
self.addEventListener('activate',event=>event.waitUntil(self.clients.claim()));
function download(){if(!downloadTask){downloadTask=prepare().catch(e=>{downloadError=e.name==='QuotaExceededError'?'quota':'storage';console.warn('Offline storage unavailable',e);}).finally(async()=>{downloadTask=null;try{await notify();}catch(e){const clients=await self.clients.matchAll({includeUncontrolled:true});clients.forEach(c=>c.postMessage({type:'ARABIC_STEP_SHELL_STATUS',ready:false,downloading:false,error:'storage',audio:0,total:AUDIO.length}));}});}return downloadTask;}
self.addEventListener('message',event=>{const type=event.data?.type;if(!['ARABIC_STEP_SHELL_STATUS','ARABIC_STEP_DOWNLOAD'].includes(type))return;event.waitUntil((async()=>{if(type==='ARABIC_STEP_DOWNLOAD'){const task=download();event.ports[0]?.postMessage(await inventory());await task;}else event.ports[0]?.postMessage(await inventory());})().catch(e=>{console.warn('Cache status failed',e);event.ports[0]?.postMessage({type:'ARABIC_STEP_SHELL_STATUS',ready:false,error:'storage',audio:0,total:AUDIO.length});}));});
async function rangeResponse(response,range){const bytes=await response.arrayBuffer(),length=bytes.byteLength;const match=/^bytes=(\d*)-(\d*)$/.exec(range||'');const fail=()=>new Response(null,{status:416,headers:{'Content-Range':`bytes */${length}`}});if(!match||(!match[1]&&!match[2]))return fail();let start,end;if(!match[1]){const suffix=Number(match[2]);if(suffix<=0)return fail();start=Math.max(0,length-suffix);end=length-1;}else{start=Number(match[1]);end=match[2]?Math.min(Number(match[2]),length-1):length-1;}if(start>=length||start>end)return fail();return new Response(bytes.slice(start,end+1),{status:206,headers:{'Content-Type':'audio/mpeg','Content-Length':String(end-start+1),'Content-Range':`bytes ${start}-${end}/${length}`,'Accept-Ranges':'bytes'}});}
self.addEventListener('fetch',event=>{const r=event.request,u=new URL(r.url);if(r.method!=='GET'||u.origin!==self.location.origin||/^\/(?:_event|_upload|_health|ping|ws)(?:\/|$)/.test(u.pathname))return;
if(r.mode==='navigate'){event.respondWith((async()=>{const cache=await caches.open(CACHE);if(u.pathname===OFFLINE){const saved=await cache.match(OFFLINE);if(saved)return saved;}try{const response=await fetch(r);if(response.ok)return response;throw Error('Navigation unavailable');}catch(e){return await cache.match(OFFLINE)||new Response('Offline lessons not prepared. Reconnect. / Leçons non préparées. Reconnectez-vous.',{status:503,headers:{'Content-Type':'text/plain;charset=utf-8'}});}})());return;}
if(!u.search&&PATHS.has(u.pathname)){event.respondWith((async()=>{const cache=await caches.open(CACHE);let response=await cache.match(u.pathname);if(!response){try{response=await fetchAsset(u.pathname);await cache.put(u.pathname,response.clone());}catch(e){return new Response('Offline asset unavailable',{status:503});}}if(u.pathname.endsWith('.mp3')&&r.headers.has('range'))return rangeResponse(response,r.headers.get('range'));return response;})());}
});
"""


def offline_contents(assets: Path) -> dict[str, str]:
    copy = {
        key: value
        for key, value in {
            **COPY,
            **LETTER_COPY,
            **EDUCATION_COPY,
            **PROGRESS_COPY,
        }.items()
        if not key.startswith("req_")
        and key not in ("locked", "unlock_after", "daily_locked")
    }
    expected = {audio_filename(text) for text in source_catalog()}
    actual = {path.name for path in (assets / "arabic_audio").glob("*.mp3")}
    missing = expected - actual
    if missing:
        raise ValueError(
            f"Offline build missing {len(missing)} required Arabic clips; run audio preparation first."
        )
    audio = [f"/arabic_audio/{name}" for name in sorted(actual)]
    payload = {
        "schema": 1,
        "letters": LETTERS,
        "positions": POSITIONS,
        "lessons": LESSONS,
        "grammar_groups": GRAMMAR_GROUPS,
        "grammar_questions": GRAMMAR_QUESTIONS,
        "categories": CATEGORIES,
        "dialogues": DIALOGUES,
        "sentences": SENTENCES,
        "modes": GAME_MODES,
        "letter_modes": ["find", "match", "form_quiz", "listen_game"],
        "ids": {row[0]: lesson_ids(row[0]) for row in MODULES},
        "modules": [
            {
                "id": row[0],
                "title": copy[row[1]],
                "description": copy[row[2]],
                "arabic": row[3],
                "requirement": ("", ""),
            }
            for row in MODULES
        ],
        "copy": copy,
        "audio": audio,
    }
    metadata = {}
    for url in audio:
        body = (assets / url.lstrip("/")).read_bytes()
        if not body:
            raise ValueError(f"Empty bundled audio: {url}")
        metadata[url] = {
            "size": len(body),
            "hash": hashlib.sha256(body).hexdigest(),
        }
    for name in (
        "arabic-step-user-logo.jpg",
        "app-icon-192.png",
        "app-icon-512.png",
        "apple-touch-icon.png",
    ):
        body = (assets / name).read_bytes()
        metadata[f"/{name}"] = {
            "size": len(body),
            "hash": hashlib.sha256(body).hexdigest(),
        }
    seed = json.dumps(payload, ensure_ascii=False, sort_keys=True)
    version = hashlib.sha256(
        f"{seed}{OFFLINE_HTML}{OFFLINE_CSS}{OFFLINE_SCRIPT}{WORKER}{json.dumps(metadata, sort_keys=True)}".encode()
    ).hexdigest()[:16]
    payload["version"] = version
    contents = {
        "offline.html": OFFLINE_HTML,
        "pwa-offline.css": OFFLINE_CSS,
        "offline-player.js": OFFLINE_SCRIPT,
        "offline-data.json": f"{json.dumps(payload, ensure_ascii=False, sort_keys=True)}\n",
    }
    for name, content in contents.items():
        body = content.encode()
        metadata[f"/{name}"] = {
            "size": len(body),
            "hash": hashlib.sha256(body).hexdigest(),
        }
    shell = [f"/{name}" for name in contents]
    shell.extend(
        [
            "/arabic-step-user-logo.jpg",
            "/manifest.webmanifest",
            "/app-icon-192.png",
            "/app-icon-512.png",
            "/apple-touch-icon.png",
        ]
    )
    for url in shell:
        if url not in metadata and (assets / url.lstrip("/")).is_file():
            body = (assets / url.lstrip("/")).read_bytes()
            metadata[url] = {
                "size": len(body),
                "hash": hashlib.sha256(body).hexdigest(),
            }
    metadata.pop("/manifest.webmanifest", None)
    contents["sw.js"] = (
        WORKER.replace("__VERSION__", json.dumps(version))
        .replace("__SHELL__", json.dumps(shell))
        .replace("__AUDIO__", json.dumps(audio))
        .replace("__META__", json.dumps(metadata, sort_keys=True))
    )
    return contents
