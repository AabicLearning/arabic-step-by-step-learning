(() => {
  "use strict";
  if (window.__arabicStepPwaLoaded) return;
  window.__arabicStepPwaLoaded = true;
  let deferredPrompt = null;
  let registration = null;
  let registering = false;
  let prompting = false;
  let capability = "checking";
  let shell = "checking";
  let installOutcome = "";
  let statusSequence = 0;
  let inventory = {audio: 0, total: 0, ready: false};
  let downloading = false;
  const displayMode = window.matchMedia("(display-mode: standalone)");
  let installed = displayMode.matches || navigator.standalone === true;
  const copy = {
    en: {
      checking: "Checking this browser…",
      supported: "Service workers are supported on this secure origin.",
      insecure: "A secure HTTPS connection is required. Online learning is still available.",
      unsupported: "This browser does not support service workers. Online learning is still available.",
      error: "Offline shell setup failed. Reconnect and try checking again; online lessons are unchanged.",
      ready: "Offline lessons and every bundled audio clip are saved and verified on this device.",
      missing: "Offline download is partial or not yet verified. Connect and use Download / Retry. Browser storage may be cleared or limited.",
      pending: "Preparing standalone offline lessons…",
      installed: "Running as an installed app. Offline downloads are prepared separately below.",
      eligible: "Your browser has offered installation. Use the button below.",
      manual: "No native install prompt is available right now. Use your browser’s install menu if offered.",
      accepted: "Installation accepted. Your browser will finish adding the app.",
      dismissed: "Installation dismissed. You can still use the browser’s install menu later.",
      installError: "The install prompt could not open. Try your browser’s install menu instead.",
      install: "Install Arabic Step by Step", check: "Verify offline download",
      busy: "Opening browser installation…"
    },
    fr: {
      checking: "Vérification de ce navigateur…",
      supported: "Les service workers sont pris en charge sur cette connexion sécurisée.",
      insecure: "Une connexion HTTPS sécurisée est nécessaire. L’apprentissage en ligne reste disponible.",
      unsupported: "Ce navigateur ne prend pas en charge les service workers. L’apprentissage en ligne reste disponible.",
      error: "La préparation de la page hors ligne a échoué. Reconnectez-vous et relancez la vérification ; les leçons en ligne restent inchangées.",
      ready: "Leçons hors ligne et tous les extraits audio enregistrés et vérifiés sur cet appareil.",
      missing: "Téléchargement partiel ou non vérifié. Connectez-vous et utilisez Télécharger / Réessayer. Le stockage peut être limité ou effacé.",
      pending: "Préparation des leçons autonomes hors ligne…",
      installed: "Application ouverte en mode installé. Les téléchargements hors ligne sont préparés séparément ci-dessous.",
      eligible: "Votre navigateur propose l’installation. Utilisez le bouton ci-dessous.",
      manual: "Aucune invitation native à installer pour le moment. Utilisez le menu d’installation du navigateur s’il est proposé.",
      accepted: "Installation acceptée. Votre navigateur terminera l’ajout de l’application.",
      dismissed: "Installation annulée. Vous pourrez utiliser le menu du navigateur plus tard.",
      installError: "Impossible d’ouvrir l’invitation. Essayez le menu d’installation du navigateur.",
      install: "Installer Arabic Step by Step", check: "Vérifier le téléchargement hors ligne",
      busy: "Ouverture de l’installation du navigateur…"
    }
  };

  function setText(element, text) {
    if (element && element.textContent !== text) element.textContent = text;
  }
  function render() {
    document.querySelectorAll("[data-pwa-card]").forEach(card => {
      const t = copy[card.getAttribute("lang") === "fr" ? "fr" : "en"];
      setText(card.querySelector("[data-pwa-capability]"), t[capability]);
      setText(card.querySelector("[data-pwa-shell]"), t[shell]);
      setText(card.querySelector("[data-pwa-install-status]"),
        t[installed ? "installed" : installOutcome || (deferredPrompt ? "eligible" : "manual")]);
      const button = card.querySelector('[data-pwa-action="install"]');
      if (button) {
        button.hidden = !deferredPrompt || installed;
        button.disabled = prompting;
        setText(button, t[prompting ? "busy" : "install"]);
      }
      const progress = card.querySelector('[data-pwa-download-status]');
      const fr = card.getAttribute('lang') === 'fr';
      setText(progress, `${inventory.audio || 0} / ${inventory.total || 0} ${fr ? 'audios vérifiés' : 'audio clips verified'}${downloading ? (fr ? ' · Téléchargement…' : ' · Downloading…') : ''}${inventory.error ? (fr ? ' · Téléchargement incomplet : vérifiez connexion et espace disponible, puis réessayez.' : ' · Incomplete download: check connection and free storage, then retry.') : ''}`);
      const download = card.querySelector('[data-pwa-action="download"]');
      if (download) {
        download.disabled = downloading || capability !== 'supported' || !navigator.onLine;
        setText(download, fr ? 'Télécharger / Réessayer les leçons et audios' : 'Download / Retry lessons and audio');
      }
      const check = card.querySelector('[data-pwa-action="check"]');
      if (check) {
        check.disabled = registering || capability === "unsupported" || capability === "insecure";
        setText(check, t.check);
      }
    });
  }

  async function inspectWorker(worker) {
    const sequence = ++statusSequence;
    if (!worker || worker.state !== "activated") {
      shell = "pending";
      render();
      return;
    }
    try {
      const result = await new Promise((resolve, reject) => {
        const channel = new MessageChannel();
        const timer = setTimeout(() => {channel.port1.close(); reject(new Error("Status timeout"));}, 5000);
        channel.port1.onmessage = event => {
          clearTimeout(timer);
          channel.port1.close();
          resolve(event.data);
        };
        worker.postMessage({type: "ARABIC_STEP_SHELL_STATUS"}, [channel.port2]);
      });
      if (sequence === statusSequence) {
        inventory = result || inventory;
        downloading = result?.downloading === true;
        shell = result?.type === "ARABIC_STEP_SHELL_STATUS" && result.ready === true ? "ready" : "missing";
        if (!result?.ready && !downloading && navigator.onLine && !result?.error) prepareDownload(worker);
      }
    } catch (error) {
      console.warn("Offline shell status could not be verified.", error);
      if (sequence === statusSequence) shell = "missing";
    }
    render();
  }

  async function prepareDownload(worker = registration?.active) {
    if (!worker || downloading || !navigator.onLine) return;
    try { await registration?.update(); } catch (error) { console.warn('Offline update check unavailable', error); }
    downloading = true;
    render();
    try {
      worker.postMessage({type: 'ARABIC_STEP_DOWNLOAD'});
    } catch (error) {
      downloading = false;
      shell = 'missing';
      render();
    }
  }

  function networkBanner() {
    let banner = document.getElementById('arabic-offline-network-banner');
    if (!banner) {
      banner = document.createElement('aside');
      banner.id = 'arabic-offline-network-banner';
      banner.setAttribute('role', 'status');
      banner.className = 'fixed inset-x-0 top-0 z-[100] border-b border-[#D6E3D9] bg-[#EAF1ED] p-4 text-center text-sm text-[#192B3A]';
      const link = document.createElement('a');
      link.href = '/offline.html';
      link.className = 'font-semibold text-[#397F78] underline';
      link.textContent = 'Connection unavailable — Open offline lessons / Connexion indisponible — Ouvrir les leçons hors ligne';
      banner.append(link);
      document.body.append(banner);
    }
    banner.hidden = navigator.onLine;
  }

  function watchWorker(worker) {
    if (!worker) return;
    worker.addEventListener("statechange", () => {
      if (worker.state === "activated") inspectWorker(worker);
      if (worker.state === "redundant" && !registration?.active) {
        shell = "error";
        render();
      }
    });
  }

  async function register() {
    if (registering) return;
    if (!window.isSecureContext) {
      capability = shell = "insecure";
      render();
      return;
    }
    if (!("serviceWorker" in navigator) || !("caches" in window)) {
      capability = shell = "unsupported";
      render();
      return;
    }
    capability = "supported";
    shell = "pending";
    registering = true;
    render();
    try {
      registration = await navigator.serviceWorker.register("/sw.js", {scope: "/", updateViaCache: "none"});
      watchWorker(registration.installing);
      watchWorker(registration.waiting);
      registration.addEventListener("updatefound", () => watchWorker(registration.installing));
      await inspectWorker(registration.active);
    } catch (error) {
      console.warn("Offline shell registration failed.", error);
      shell = "error";
    } finally {
      registering = false;
      render();
    }
  }

  window.addEventListener("beforeinstallprompt", event => {
    event.preventDefault();
    deferredPrompt = event;
    installOutcome = "";
    render();
  });
  window.addEventListener("appinstalled", () => {
    installed = true;
    deferredPrompt = null;
    installOutcome = "";
    render();
  });
  displayMode.addEventListener?.("change", event => {
    installed = event.matches || navigator.standalone === true;
    render();
  });
  document.addEventListener("click", async event => {
    const button = event.target instanceof Element ? event.target.closest("[data-pwa-action]") : null;
    if (!button || button.disabled || !button.closest("[data-pwa-card]")) return;
    if (button.dataset.pwaAction === 'download') {
      prepareDownload();
      return;
    }
    if (button.dataset.pwaAction === "check") {
      await register();
      return;
    }
    if (button.dataset.pwaAction !== "install" || !deferredPrompt || installed || prompting) return;
    const promptEvent = deferredPrompt;
    prompting = true;
    render();
    try {
      await promptEvent.prompt();
      const choice = await promptEvent.userChoice;
      installOutcome = choice.outcome === "accepted" ? "accepted" : "dismissed";
    } catch (error) {
      console.warn("Browser installation was unavailable.", error);
      installOutcome = "installError";
    } finally {
      if (deferredPrompt === promptEvent) deferredPrompt = null;
      prompting = false;
      render();
    }
  });

  function start() {
    const observer = new MutationObserver(records => {
      if (records.some(record => record.type === "attributes" ||
        [...record.addedNodes].some(node => node.nodeType === 1 &&
          (node.matches?.("[data-pwa-card]") || node.querySelector?.("[data-pwa-card]"))))) render();
    });
    observer.observe(document.documentElement, {childList: true, subtree: true,
      attributes: true, attributeFilter: ["lang"]});
    render();
    networkBanner();
    register();
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.addEventListener('message', event => {
        if (event.data?.type !== 'ARABIC_STEP_SHELL_STATUS') return;
        inventory = event.data;
        downloading = event.data.downloading === true;
        shell = event.data.ready ? 'ready' : 'missing';
        render();
      });
      navigator.serviceWorker.addEventListener("controllerchange", () => inspectWorker(navigator.serviceWorker.controller));
    }
    window.addEventListener('offline', networkBanner);
    window.addEventListener("online", () => {networkBanner(); register();});
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start, {once: true});
  else start();
})();
