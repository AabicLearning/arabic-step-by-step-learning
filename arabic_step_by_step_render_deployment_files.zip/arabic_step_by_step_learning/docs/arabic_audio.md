# Arabic pronunciation playback

Before building, install the packages listed in apt-packages.txt: eSpeak NG and ffmpeg. Run `python scripts/generate_arabic_audio.py` from the project root to prepare all clips. The Reflex run/export configuration also prepares missing or changed clips before static assets are copied. There is no synthesis in learner events or device Arabic voice dependency. Playback uses Google Translate MP3 first, with these bundled clips as the fallback. Existing complete assets skip synthesis.

The source-of-truth catalog is `app/states/audio_catalog.py`, derived from actual letter, education, harakat, dialogue and sentence content. Generation writes human-readable UTF-8 source_texts.txt and catalog.txt plus MP3s under assets/arabic_audio/. Daily practice is covered by the same lesson and letter sources. Lone sukoon syllables are synthesized as أَبْ or أَمْ; their original input paths are also catalogued. Sentence audio is synthesized as a whole sentence, not assembled from word clips.

Text is normalized to NFC. Filenames are eight lowercase hexadecimal digits of FNV-1a 32-bit, iterating UTF-16 code units, followed by .mp3. Python uses UTF-16 little-endian units; the browser uses charCodeAt and Math.imul synchronously during the tap. The catalog rejects hash collisions. The browser does not fetch a manifest before calling Audio.play(), preserving the activation gesture. Generation uses eSpeak NG `-v ar -s 135` and ffmpeg libmp3lame, 64 kbps, mono, 22050 Hz, stripping metadata. Use `--force` after upgrading synthesis tools; fixed text and tool versions give reproducible builds.

The actual DOM click constructs an Audio element with the Google Translate MP3 URL and calls play synchronously, without fetch, crossorigin or speech synthesis. The app’s no-referrer meta policy avoids sending a Referer to the endpoint. Remote errors, rejected play promises or an 8-second loading/stall timeout switch the same element to its bundled URL exactly once. The bundled attempt has a 20-second loading/stall timeout; final failure appears below the tapped button. A small spinner, aria-busy and English/French live status are shown during loading/waiting and cleared on playing, ending, failure or cancellation. Superseded clicks, removed/changed controls, sound-off and pagehide release the active clip and timeout. Only one clip plays at a time. There is no autoplay.

## Third-party notice

[eSpeak NG](https://github.com/espeak-ng/espeak-ng) is a GPLv3-or-later build tool. It produces the bundled synthetic speech; it is not a runtime browser dependency. Refer to its upstream COPYING and voice-data notices when distributing the tool itself. ffmpeg/libmp3lame encode the static MP3s; their licensing depends on the installed build. Synthetic speech is a pronunciation aid, not a native-speaker recording or a guarantee of natural intonation, dialect or precise isolated-consonant quality.

## Checks

Run `python scripts/check_arabic_practice.py` after generation to check catalog coverage, NFC/hash vectors, sentence prerequisites and MP3 mono/bitrate/duration via ffprobe. Browser/mobile playback and Reflex event behavior still require testing in the target environment; no device testing is claimed.

### Browser media verification checklist

These are checks to perform, not claims of completed tests. Use a running app and browser developer tools with Preserve log enabled:

- Inspect the document head for `meta name="referrer" content="no-referrer"`. Click Listen in letters and another module; verify the Google translate_tts request contains the encoded Arabic text, `tl=ar` and `client=tw-ob`, has no Referer header, and returns audio/mpeg. Listen for actual playback. The supplied HTTP observation showed 200/audio-mpeg without Referer and 404 with either full or origin Referer; it does not establish browser or Android results.
- Throttle the network: confirm a small teal spinner and localized loading status appear, with aria-busy on the button. On playing, both loading feedback and aria-busy should clear; simulate waiting and check they return until playback resumes.
- Block `https://translate.google.com/*` using browser request blocking. Click again and verify exactly one same-origin `/arabic_audio/<hash>.mp3` fallback request plays. Also test a stalled remote request: fallback should begin after 8 seconds. The bundled files must already be available for offline playback; this change does not install an offline app cache.
- Block both sources, or simulate a rejected media play promise: verify a localized final error, no spinner or aria-busy left behind, and no repeated fallback loop. Stalled local loading should fail after 20 seconds.
- Rapidly click different controls; only the last should play. Old errors, promise rejections and timers must not clear the last button’s status. Navigate away or change the displayed lesson while loading; confirm the old media is stopped. Check normal ended cleanup and replay.
- Turn sound off during playback/loading, including via another tab. Confirm immediate cleanup; subsequent audio clicks show the localized muted message with no media request. Turn sound back on and replay.
- Repeat in French and English and inspect the live status with accessibility tools. Repeat actual playback on a physical Android browser before making any Android-device compatibility claim.
